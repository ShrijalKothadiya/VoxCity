<?php
/**
 * Plugin Name: Local Service Website Generator
 * Description: Generate attractive local-service website content from only a city and service.
 * Version: 2.0.0
 * Author: Local Service Generator
 */

if (!defined('ABSPATH')) {
    exit;
}

class LSWG_Local_Service_Generator {

    private $option_key = 'lswg_generated_website';
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'admin_assets']);
        add_action('wp_enqueue_scripts', [$this, 'frontend_assets']);

        add_action('wp_ajax_lswg_generate', [$this, 'ajax_generate']);
        add_action('wp_ajax_lswg_get_preview', [$this, 'ajax_preview']);
        add_action('wp_ajax_lswg_publish_page', [$this, 'ajax_publish_page']);

        // Register new CRUD ajax callbacks
        add_action('wp_ajax_lswg_save_city', [$this, 'ajax_save_city']);
        add_action('wp_ajax_lswg_delete_city', [$this, 'ajax_delete_city']);
        add_action('wp_ajax_lswg_save_template', [$this, 'ajax_save_template']);
        add_action('wp_ajax_lswg_activate_template', [$this, 'ajax_activate_template']);
        add_action('wp_ajax_lswg_delete_template', [$this, 'ajax_delete_template']);
        add_action('wp_ajax_lswg_save_openai_settings', [$this, 'ajax_save_openai_settings']);
        add_action('wp_ajax_lswg_test_openai_connection', [$this, 'ajax_test_openai_connection']);

        add_filter('template_include', [$this, 'template_override']);
        add_filter('theme_page_templates', [$this, 'register_project_templates'], 10, 4);

        add_shortcode('local_service_website', [$this, 'shortcode']);

        // Initialize defaults if they do not exist
        if (false === get_option('lswg_city_database')) {
            $default_cities = [
                [
                    'id' => '1',
                    'city' => 'Ahmedabad',
                    'address' => '502 Shanti Chambers, C.G. Road, Navrangpura, Ahmedabad - 380009.'
                ],
                [
                    'id' => '2',
                    'city' => 'Vadodara',
                    'address' => '12 Ocean Complex, Alkapuri Road, Vadodara - 390007.'
                ],
                [
                    'id' => '3',
                    'city' => 'Surat',
                    'address' => '401 International Business Center, Piplod, Surat - 395007.'
                ],
                [
                    'id' => '4',
                    'city' => 'Mumbai',
                    'address' => '88 Linking Road, Bandra West, Mumbai - 400050.'
                ],
                [
                    'id' => '5',
                    'city' => 'Delhi',
                    'address' => '15 Connaught Place, New Delhi - 110001.'
                ]
            ];
            update_option('lswg_city_database', $default_cities);
        }

        // Initialize default templates list
        $templates = get_option('lswg_templates', []);
        
        // Ensure default hardcoded fallback template exists
        $has_default = false;
        $has_vispan_custom = false;
        
        foreach ($templates as $t) {
            if ($t['id'] === 'default') {
                $has_default = true;
            }
            if ($t['id'] === 'vispan_custom') {
                $has_vispan_custom = true;
            }
        }

        $vispan_html = <<<HTML
<!-- lswg-light-theme-v6 -->
<div class="website-frame lswg-light-theme-v6">

  <!-- WEBSITE TOPBAR -->
  <div class="site-topbar">
    <div class="container">
      <div class="topbar-contact">
        <span data-icon="phone">+91 84859 86860</span>
        <span data-icon="mail">{{email}}</span>
      </div>
      <div class="topbar-social">Follow us</div>
    </div>
  </div>

  <!-- WEBSITE NAV -->
  <header class="site-nav">
    <div class="container">
      <a href="#" class="site-logo">
        <span class="logo-mark">V</span>
        <strong>Vispan<span class="logo-accent">.</span></strong>
      </a>
      <nav class="site-nav-links">
        <span data-target="home">Home</span>
        <span data-target="why-us">Why Us</span>
        <span data-target="solutions">Solutions</span>
        <span data-target="services">Services</span>
        <span data-target="advantages">Advantages</span>
        <span data-target="case-study">Case Study</span>
        <span data-target="testimonials">Testimonials</span>
        <span data-target="contact">Contact Us</span>
      </nav>
      <a href="#contact-form-section" class="vcpg-dual-btn">
        <span class="vcpg-btn-circle-left"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg></span>
        <span class="vcpg-btn-pill">LET'S TALK</span>
        <span class="vcpg-btn-circle-right"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg></span>
      </a>
    </div>
  </header>

  <!-- HERO -->
  <section class="hero-section" id="home">
    <div class="container hero-grid">
      <div class="hero-copy">
        <p class="eyebrow" style="color:#a9b8e8;">{{city}} {{service}}</p>
        <h1>{{sec1_title}}</h1>
        <p>{{sec1_caption}}</p>
        <a href="#why-us" class="vcpg-dual-btn">
          <span class="vcpg-btn-circle-left"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg></span>
          <span class="vcpg-btn-pill">Learn More</span>
          <span class="vcpg-btn-circle-right"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg></span>
        </a>
      </div>

      <div style="background:rgba(255,255,255,0.85);border:2px solid #02426A;border-radius:30px;padding:40px 30px;color:#000000;box-sizing:border-box;box-shadow:0 10px 30px rgba(0,0,0,0.1); width:100%;">
        <h3 style="margin:0 0 24px;font-size:24px;font-weight:700;text-align:left;color:#02426A;letter-spacing:-0.2px;font-family:'DM Sans',sans-serif;">Request A {{service}} Proposal</h3>
        <form id="hero_proposal" style="display:flex;flex-direction:column;gap:16px;" onsubmit="event.preventDefault(); alert('Proposal request submitted successfully! We will contact you shortly.');">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
            <input name="fullname" placeholder="Full Name*" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;font-family:inherit;" type="text" required>
            <input name="email" placeholder="Email Address*" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;font-family:inherit;" type="email" required>
          </div>
          <div style="display:grid;grid-template-columns:120px 1fr;gap:8px;">
            <div style="position:relative;width:100%;">
              <input name="country_code" id="cc_input_hero_proposal" value="+91 IND" placeholder="+91 IND" style="width:100%;padding:13px 8px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:13px;outline:none;box-sizing:border-box;font-family:inherit;text-align:center;cursor:pointer;" autocomplete="off">
              <div id="cc_dropdown_hero_proposal" style="position:absolute;top:100%;left:0;right:0;max-height:220px;overflow-y:auto;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:12px;z-index:99999;box-shadow:0 10px 25px rgba(0,0,0,0.15);display:none;margin-top:6px;padding:4px;box-sizing:border-box;text-align:left;">
              </div>
            </div>
            <input name="phone" placeholder="Contact No.*" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;font-family:inherit;" type="tel" required>
          </div>
          <div style="position:relative;width:100%;">
            <input type="text" readonly id="service_trigger_hero_proposal" placeholder="Select Service*" value="" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;cursor:pointer;font-family:inherit;background-image:url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2220%22%20height%3D%2220%22%20viewBox%3D%220%200%2020%2020%22%3E%3Cpath%20fill%3D%22%231E293B%22%20d%3D%22M5.293%207.293a1%201%200%20011.414%200L10%2010.586l3.293-3.293a1%201%200%20111.414%201.414l-4%204a1%201%200%2001-1.414%200l-4-4a1%201%200%20010-1.414z%22%2F%3E%3C%2Fsvg%3E');background-repeat:no-repeat;background-position:right 18px center;padding-right:45px;" required>
            <input type="hidden" name="service" id="service_input_hero_proposal" required>
            <div id="service_dropdown_hero_proposal" style="position:absolute;top:100%;left:0;right:0;max-height:200px;overflow-y:auto;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:12px;z-index:99999;box-shadow:0 10px 25px rgba(0,0,0,0.15);display:none;margin-top:6px;padding:4px;box-sizing:border-box;text-align:left;">
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
            <input name="company" placeholder="Company Name*" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;font-family:inherit;" type="text" required>
            <input name="website" placeholder="Website/Landing Page*" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;font-family:inherit;" type="text" required>
          </div>
          <div>
            <div style="position:relative;width:100%;">
              <input type="text" readonly id="budget_trigger_hero_proposal" placeholder="Budget Spent In Last 30 Days?*" value="" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;cursor:pointer;font-family:inherit;background-image:url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2220%22%20height%3D%2220%22%20viewBox%3D%220%200%2020%2020%22%3E%3Cpath%20fill%3D%22%231E293B%22%20d%3D%22M5.293%207.293a1%201%200%20011.414%200L10%2010.586l3.293-3.293a1%201%200%20111.414%201.414l-4%204a1%201%200%2001-1.414%200l-4-4a1%201%200%20010-1.414z%22%2F%3E%3C%2Fsvg%3E');background-repeat:no-repeat;background-position:right 18px center;padding-right:45px;" required>
              <input type="hidden" name="budget" id="budget_input_hero_proposal" required>
              <div id="budget_dropdown_hero_proposal" style="position:absolute;top:100%;left:0;right:0;max-height:200px;overflow-y:auto;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:12px;z-index:99999;box-shadow:0 10px 25px rgba(0,0,0,0.15);display:none;margin-top:6px;padding:4px;box-sizing:border-box;text-align:left;">
              </div>
            </div>
          </div>
          <div>
            <textarea name="details" placeholder="Additional Details/Purpose of Business" style="width:100%;padding:16px 22px;border-radius:18px;border:1px solid #7E7E7E;background:#FFFFFF;color:#1E293B;font-size:14px;box-sizing:border-box;height:100px;resize:vertical;outline:none;font-family:inherit;"></textarea>
          </div>
          <div style="display:flex;flex-direction:column;align-items:flex-start;gap:10px;margin-top:8px;text-align:left;">
            <button type="submit" style="background:#02426A;color:#FFFFFF;border:none;border-radius:50px;padding:14px 34px;font-weight:600;font-size:14px;cursor:pointer;display:inline-block;transition:all 0.2s;font-family:inherit; width: 100%;">Request a Proposal</button>
          </div>
        </form>
      </div>
    </div>
  </section>

  <!-- WHY US -->
  <section class="site-section" id="why-us">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Why {{city}} {{service}} Need Us</p>
        <h2>Why {{city}} {{service}} Need Specialized {{service}} Services</h2>
      </div>
      <p class="why-us-body">
        {{sec1_caption}}
      </p>
      <p class="why-us-body" style="margin-top:14px;">
        {{sec2_text}}
      </p>
    </div>
  </section>

  <!-- SOLUTIONS / SPECIALISTS -->
  <section class="site-section soft" id="solutions">
    <div class="container split-block">
      <div class="copy">
        <p class="eyebrow">Tailored Solutions</p>
        <h2>{{city}} {{service}} Specialists Delivering Tailored Solutions</h2>
        <p>
          {{sec2_text}}
        </p>
        <div class="feature-mini-grid">
          <div class="feature-mini">
            <div class="icon">↑</div>
            <div><h4>Increase appointments</h4><p>Convert online interest into confirmed bookings and a growing client base.</p></div>
          </div>
          <div class="feature-mini">
            <div class="icon">✓</div>
            <div><h4>Build trust and credibility</h4><p>Showcase your expertise, advanced technology, and client-centric approach.</p></div>
          </div>
          <div class="feature-mini">
            <div class="icon">◎</div>
            <div><h4>Enhance client engagement</h4><p>Foster strong relationships by providing valuable information and interacting with your audience online.</p></div>
          </div>
          <div class="feature-mini">
            <div class="icon">▲</div>
            <div><h4>Boost online visibility</h4><p>Improve your search engine ranking and ensure your business appears at the top of local searches.</p></div>
          </div>
        </div>
      </div>
      <div class="media-frame"><img src="{{image_2}}" alt="Tailored Solutions"></div>
    </div>
  </section>

  <!-- SERVICES -->
  <section class="site-section" id="services">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">What We Offer</p>
        <h2>Specialized {{service}} Services in {{city}}</h2>
        <p>A targeted spectrum of {{service}} services designed to enhance case acquisition, client engagement, and online authority for {{city}}'s professionals.</p>
      </div>
      <div class="service-grid">
        {{sec3_services}}
      </div>
    </div>
  </section>

  <!-- ADVANTAGES -->
  <section class="site-section soft" id="advantages">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Our Edge</p>
        <h2>Distinct Advantages of Partnering with Vispan Solutions</h2>
        <p>Attorneys in {{city}} benefit from Vispan Solutions' focused methodology combining data analytics, local insight, and {{service}}-specific marketing expertise.</p>
      </div>
      
      <div class="advantages-tabs-container">
          <div class="tab-strip advantages-tabs-nav">
            <span class="tab-pill advantage-tab-btn active" data-tab="tab-1">{{tab_1_title}}</span>
            <span class="tab-pill advantage-tab-btn" data-tab="tab-2">{{tab_2_title}}</span>
            <span class="tab-pill advantage-tab-btn" data-tab="tab-3">{{tab_3_title}}</span>
            <span class="tab-pill advantage-tab-btn" data-tab="tab-4">{{tab_4_title}}</span>
          </div>
          <div class="advantages-tabs-content">
            <div class="advantage-panel advantage-tab-panel active" id="tab-1">
              {{tab_1_desc}}
            </div>
            <div class="advantage-panel advantage-tab-panel" id="tab-2">
              {{tab_2_desc}}
            </div>
            <div class="advantage-panel advantage-tab-panel" id="tab-3">
              {{tab_3_desc}}
            </div>
            <div class="advantage-panel advantage-tab-panel" id="tab-4">
              {{tab_4_desc}}
            </div>
          </div>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="site-section" id="get-started">
    <div class="container cta-strip">
      <div>
        <p class="eyebrow">Ready to get started?</p>
        <h2>Ready to get started?</h2>
        <p>
          {{sec5_cta_text}}
        </p>
        <a href="#contact-form-section" class="vcpg-dual-btn">
          <span class="vcpg-btn-circle-left"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg></span>
          <span class="vcpg-btn-pill">LET'S TALK</span>
          <span class="vcpg-btn-circle-right"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg></span>
        </a>
      </div>
      <div class="media-frame"><img src="{{image_3}}" alt="Ready to get started"></div>
    </div>
  </section>

  <!-- CASE STUDY -->
  <section class="site-section soft" id="case-study">
    <div class="container case-study">
      <div class="media-frame" style="aspect-ratio:1/1;"><img src="{{image_1}}" alt="Case Study"></div>
      <div>
        <p class="eyebrow">Case Study</p>
        <h2>{{case_study_title}}</h2>
        <h4>The Challenge</h4>
        <p>{{case_study_challenge}}</p>
        <h4>What We Did</h4>
        <p>{{case_study_solution}}</p>
        <h4>The Result</h4>
        <p>{{case_study_results}}</p>
      </div>
    </div>
  </section>

  <!-- LOGOS -->
  <section class="site-section" style="padding:44px 0;">
    <div class="container logo-strip">
      <span>ClickFunnels</span><span>Twitter</span><span>SnapChat</span><span>WooCommerce</span><span>Mailchimp</span><span>WordPress</span>
    </div>
  </section>

  <!-- TESTIMONIALS -->
  <section class="site-section soft" id="testimonials">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow">Testimonials</p>
        <h2>What Clients Say</h2>
      </div>
      <div class="testimonial-card">
        {{testimonials_slider}}
      </div>
    </div>
  </section>

  <!-- CERTIFICATIONS -->
  <section class="site-section">
    <div class="container">
      <div class="cert-grid">
        <div class="cert-item"><span class="dot"></span>Google Partner</div>
        <div class="cert-item"><span class="dot"></span>Google Analytics</div>
        <div class="cert-item"><span class="dot"></span>Google Ads Video Certification</div>
        <div class="cert-item"><span class="dot"></span>Google Ads Search Certification</div>
        <div class="cert-item"><span class="dot"></span>Google Ads Measurement Certification</div>
        <div class="cert-item"><span class="dot"></span>Google Ads Display Certification</div>
      </div>
    </div>
  </section>

  <!-- FOOTER LEAD FORM BAND -->
  <section class="site-section footer-form-band">
    <div class="container">
      <div class="section-head">
        <p class="eyebrow" style="color:#a9b8e8;">Get In Touch</p>
        <h2>Request A {{service}} Proposal</h2>
      </div>
      <div style="background:rgba(255,255,255,0.85);border:2px solid #02426A;border-radius:30px;padding:40px 30px;color:#000000;box-sizing:border-box;box-shadow:0 10px 30px rgba(0,0,0,0.1); width:100%; max-width: 600px; margin: 0 auto;">
        <form id="footer_proposal" style="display:flex;flex-direction:column;gap:16px;" onsubmit="event.preventDefault(); alert('Proposal request submitted successfully!');">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
            <input name="fullname" placeholder="Full Name*" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;font-family:inherit;" type="text" required>
            <input name="email" placeholder="Email Address*" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;font-family:inherit;" type="email" required>
          </div>
          <div style="display:grid;grid-template-columns:120px 1fr;gap:8px;">
            <div style="position:relative;width:100%;">
              <input name="country_code" id="cc_input_footer_proposal" value="+91 IND" placeholder="+91 IND" style="width:100%;padding:13px 8px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:13px;outline:none;box-sizing:border-box;font-family:inherit;text-align:center;cursor:pointer;" autocomplete="off">
              <div id="cc_dropdown_footer_proposal" style="position:absolute;top:100%;left:0;right:0;max-height:220px;overflow-y:auto;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:12px;z-index:99999;box-shadow:0 10px 25px rgba(0,0,0,0.15);display:none;margin-top:6px;padding:4px;box-sizing:border-box;text-align:left;">
              </div>
            </div>
            <input name="phone" placeholder="Contact No.*" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;font-family:inherit;" type="tel" required>
          </div>
          <div style="position:relative;width:100%;">
            <input type="text" readonly id="service_trigger_footer_proposal" placeholder="Select Service*" value="" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;cursor:pointer;font-family:inherit;background-image:url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2220%22%20height%3D%2220%22%20viewBox%3D%220%200%2020%2020%22%3E%3Cpath%20fill%3D%22%231E293B%22%20d%3D%22M5.293%207.293a1%201%200%20011.414%200L10%2010.586l3.293-3.293a1%201%200%20111.414%201.414l-4%204a1%201%200%2001-1.414%200l-4-4a1%201%200%20010-1.414z%22%2F%3E%3C%2Fsvg%3E');background-repeat:no-repeat;background-position:right 18px center;padding-right:45px;" required>
            <input type="hidden" name="service" id="service_input_footer_proposal" required>
            <div id="service_dropdown_footer_proposal" style="position:absolute;top:100%;left:0;right:0;max-height:200px;overflow-y:auto;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:12px;z-index:99999;box-shadow:0 10px 25px rgba(0,0,0,0.15);display:none;margin-top:6px;padding:4px;box-sizing:border-box;text-align:left;">
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
            <input name="company" placeholder="Company Name*" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;font-family:inherit;" type="text" required>
            <input name="website" placeholder="Website/Landing Page*" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;font-family:inherit;" type="text" required>
          </div>
          <div>
            <div style="position:relative;width:100%;">
              <input type="text" readonly id="budget_trigger_footer_proposal" placeholder="Budget Spent In Last 30 Days?*" value="" style="width:100%;padding:13px 22px;border-radius:50px;border:1px solid #7E7E7E;background:#F3F4F6;color:#1E293B;font-size:14px;box-sizing:border-box;outline:none;cursor:pointer;font-family:inherit;background-image:url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2220%22%20height%3D%2220%22%20viewBox%3D%220%200%2020%2020%22%3E%3Cpath%20fill%3D%22%231E293B%22%20d%3D%22M5.293%207.293a1%201%200%20011.414%200L10%2010.586l3.293-3.293a1%201%200%20111.414%201.414l-4%204a1%201%200%2001-1.414%200l-4-4a1%201%200%20010-1.414z%22%2F%3E%3C%2Fsvg%3E');background-repeat:no-repeat;background-position:right 18px center;padding-right:45px;" required>
              <input type="hidden" name="budget" id="budget_input_footer_proposal" required>
              <div id="budget_dropdown_footer_proposal" style="position:absolute;top:100%;left:0;right:0;max-height:200px;overflow-y:auto;background:#FFFFFF;border:1px solid #CBD5E1;border-radius:12px;z-index:99999;box-shadow:0 10px 25px rgba(0,0,0,0.15);display:none;margin-top:6px;padding:4px;box-sizing:border-box;text-align:left;">
              </div>
            </div>
          </div>
          <div>
            <textarea name="details" placeholder="Additional Details/Purpose of Business" style="width:100%;padding:16px 22px;border-radius:18px;border:1px solid #7E7E7E;background:#FFFFFF;color:#1E293B;font-size:14px;box-sizing:border-box;height:100px;resize:vertical;outline:none;font-family:inherit;"></textarea>
          </div>
          <div style="display:flex;flex-direction:column;align-items:flex-start;gap:10px;margin-top:8px;text-align:left;">
            <button type="submit" style="background:#02426A;color:#FFFFFF;border:none;border-radius:50px;padding:14px 34px;font-weight:600;font-size:14px;cursor:pointer;display:inline-block;transition:all 0.2s;font-family:inherit; width: 100%;">Request a Proposal</button>
          </div>
        </form>
      </div>
    </div>
  </section>

  <!-- SITE FOOTER -->
  <footer class="site-footer">
    <div class="container footer-grid">
      <div class="footer-brand">
        <a href="#" class="site-logo"><span class="logo-mark">V</span><strong>Vispan<span class="logo-accent">.</span></strong></a>
        <p>Free to reach out if you want to collaborate with us on projects or just to say hi!</p>
        <div class="social-row">
          <span>f</span><span>in</span><span>ig</span><span>x</span><span>yt</span>
        </div>
      </div>
      <div>
        <h5>Services</h5>
        <ul>
          <li>Digital Marketing</li>
          <li>Google Ads Management</li>
          <li>Branding &amp; Design</li>
          <li>Search Engine Optimization</li>
          <li>Web Development</li>
          <li>Social Media Management</li>
        </ul>
      </div>
      <div>
        <h5>Quick Links</h5>
        <ul>
          <li>Home</li>
          <li>About Us</li>
          <li>Blog</li>
          <li>Contact Us</li>
        </ul>
      </div>
      <div>
        <h5>Reach Us</h5>
        <ul>
          <li>{{address}}</li>
          <li>+91 84859 86860</li>
          <li>{{email}}</li>
        </ul>
      </div>
    </div>
    <div class="container footer-bottom">
      <span>© 2026 Vispan Solutions. All rights reserved.</span>
      <span>Privacy Policy · Terms of Service</span>
    </div>
  </footer>

</div>

<script>
(function() {
    var countries = [{"c":"+91","n":"India","i":"IND"},{"c":"+1","n":"United States","i":"USA"},{"c":"+44","n":"United Kingdom","i":"GBR"},{"c":"+61","n":"Australia","i":"AUS"},{"c":"+971","n":"United Arab Emirates","i":"ARE"},{"c":"+65","n":"Singapore","i":"SGP"},{"c":"+1","n":"Canada","i":"CAN"},{"c":"+93","n":"Afghanistan","i":"AFG"},{"c":"+355","n":"Albania","i":"ALB"},{"c":"+213","n":"Algeria","i":"DZA"},{"c":"+376","n":"Andorra","i":"AND"},{"c":"+244","n":"Angola","i":"AGO"},{"c":"+54","n":"Argentina","i":"ARG"},{"c":"+374","n":"Armenia","i":"ARM"},{"c":"+43","n":"Austria","i":"AUT"},{"c":"+994","n":"Azerbaijan","i":"AZE"},{"c":"+1","n":"Bahamas","i":"BHS"},{"c":"+973","n":"Bahrain","i":"BHR"},{"c":"+880","n":"Bangladesh","i":"BGD"},{"c":"+375","n":"Belarus","i":"BLR"},{"c":"+32","n":"Belgium","i":"BEL"},{"c":"+501","n":"Belize","i":"BLZ"},{"c":"+229","n":"Benin","i":"BEN"},{"c":"+975","n":"Bhutan","i":"BTN"},{"c":"+591","n":"Bolivia","i":"BOL"},{"c":"+387","n":"Bosnia and Herzegovina","i":"BIH"},{"c":"+267","n":"Botswana","i":"BWA"},{"c":"+55","n":"Brazil","i":"BRA"},{"c":"+673","n":"Brunei","i":"BRN"},{"c":"+359","n":"Bulgaria","i":"BGR"},{"c":"+226","n":"Burkina Faso","i":"BFA"},{"c":"+257","n":"Burundi","i":"BDI"},{"c":"+855","n":"Cambodia","i":"KHM"},{"c":"+237","n":"Cameroon","i":"CMR"},{"c":"+238","n":"Cape Verde","i":"CPV"},{"c":"+236","n":"Central African Republic","i":"CAF"},{"c":"+235","n":"Chad","i":"TCD"},{"c":"+56","n":"Chile","i":"CHL"},{"c":"+86","n":"China","i":"CHN"},{"c":"+57","n":"Colombia","i":"COL"},{"c":"+269","n":"Comoros","i":"COM"},{"c":"+242","n":"Congo","i":"COG"},{"c":"+243","n":"Congo (DRC)","i":"COD"},{"c":"+506","n":"Costa Rica","i":"CRI"},{"c":"+385","n":"Croatia","i":"HRV"},{"c":"+53","n":"Cuba","i":"CUB"},{"c":"+357","n":"Cyprus","i":"CYP"},{"c":"+420","n":"Czech Republic","i":"CZE"},{"c":"+45","n":"Denmark","i":"DNK"},{"c":"+253","n":"Djibouti","i":"DJI"},{"c":"+1","n":"Dominica","i":"DMA"},{"c":"+1","n":"Dominican Republic","i":"DOM"},{"c":"+593","n":"Ecuador","i":"ECU"},{"c":"+20","n":"Egypt","i":"EGY"},{"c":"+503","n":"El Salvador","i":"SLV"},{"c":"+240","n":"Equatorial Guinea","i":"GNQ"},{"c":"+291","n":"Eritrea","i":"ERI"},{"c":"+372","n":"Estonia","i":"EST"},{"c":"+268","n":"Eswatini","i":"SWZ"},{"c":"+251","n":"Ethiopia","i":"ETH"},{"c":"+679","n":"Fiji","i":"FJI"},{"c":"+358","n":"Finland","i":"FIN"},{"c":"+33","n":"France","i":"FRA"},{"c":"+241","n":"Gabon","i":"GAB"},{"c":"+220","n":"Gambia","i":"GMB"},{"c":"+995","n":"Georgia","i":"GEO"},{"c":"+49","n":"Germany","i":"DEU"},{"c":"+233","n":"Ghana","i":"GHA"},{"c":"+30","n":"Greece","i":"GRC"},{"c":"+1","n":"Grenada","i":"GRD"},{"c":"+502","n":"Guatemala","i":"GTM"},{"c":"+224","n":"Guinea","i":"GIN"},{"c":"+245","n":"Guinea-Bissau","i":"GNB"},{"c":"+509","n":"Haiti","i":"HTI"},{"c":"+504","n":"Honduras","i":"HND"},{"c":"+852","n":"Hong Kong","i":"HKG"},{"c":"+36","n":"Hungary","i":"HUN"},{"c":"+354","n":"Iceland","i":"ISL"},{"c":"+62","n":"Indonesia","i":"IDN"},{"c":"+98","n":"Iran","i":"IRN"},{"c":"+964","n":"Iraq","i":"IRQ"},{"c":"+353","n":"Ireland","i":"IRL"},{"c":"+972","n":"Israel","i":"ISR"},{"c":"+39","n":"Italy","i":"ITA"},{"c":"+1","n":"Jamaica","i":"JAM"},{"c":"+81","n":"Japan","i":"JPN"},{"c":"+962","n":"Jordan","i":"JOR"},{"c":"+7","n":"Kazakhstan","i":"KAZ"},{"c":"+254","n":"Kenya","i":"KEN"},{"c":"+686","n":"Kiribati","i":"KIR"},{"c":"+965","n":"Kuwait","i":"KWT"},{"c":"+996","n":"Kyrgyzstan","i":"KGZ"},{"c":"+856","n":"Laos","i":"LAO"},{"c":"+371","n":"Latvia","i":"LVA"},{"c":"+961","n":"Lebanon","i":"LBN"},{"c":"+266","n":"Lesotho","i":"LSO"},{"c":"+231","n":"Liberia","i":"LBR"},{"c":"+218","n":"Libya","i":"LBY"},{"c":"+423","n":"Liechtenstein","i":"LIE"},{"c":"+370","n":"Lithuania","i":"LTU"},{"c":"+352","n":"Luxembourg","i":"LUX"},{"c":"+853","n":"Macau","i":"MAC"},{"c":"+261","n":"Madagascar","i":"MDG"},{"c":"+265","n":"Malawi","i":"MWI"},{"c":"+60","n":"Malaysia","i":"MYS"},{"c":"+960","n":"Maldives","i":"MDV"},{"c":"+223","n":"Mali","i":"MLI"},{"c":"+356","n":"Malta","i":"MLT"},{"c":"+692","n":"Marshall Islands","i":"MHL"},{"c":"+222","n":"Mauritania","i":"MRT"},{"c":"+230","n":"Mauritius","i":"MUS"},{"c":"+52","n":"Mexico","i":"MEX"},{"c":"+691","n":"Micronesia","i":"FSM"},{"c":"+373","n":"Moldova","i":"MDA"},{"c":"+377","n":"Monaco","i":"MCO"},{"c":"+976","n":"Mongolia","i":"MNG"},{"c":"+382","n":"Montenegro","i":"MNE"},{"c":"+212","n":"Morocco","i":"MAR"},{"c":"+258","n":"Mozambique","i":"MOZ"},{"c":"+95","n":"Myanmar","i":"MMR"},{"c":"+264","n":"Namibia","i":"NAM"},{"c":"+674","n":"Nauru","i":"NRU"},{"c":"+977","n":"Nepal","i":"NPL"},{"c":"+31","n":"Netherlands","i":"NLD"},{"c":"+64","n":"New Zealand","i":"NZL"},{"c":"+505","n":"Nicaragua","i":"NIC"},{"c":"+227","n":"Niger","i":"NER"},{"c":"+234","n":"Nigeria","i":"NGA"},{"c":"+850","n":"North Korea","i":"PRK"},{"c":"+82","n":"South Korea","i":"KOR"},{"c":"+389","n":"North Macedonia","i":"MKD"},{"c":"+47","n":"Norway","i":"NOR"},{"c":"+968","n":"Oman","i":"OMN"},{"c":"+92","n":"Pakistan","i":"PAK"},{"c":"+680","n":"Palau","i":"PLW"},{"c":"+970","n":"Palestine","i":"PSE"},{"c":"+507","n":"Panama","i":"PAN"},{"c":"+675","n":"Papua New Guinea","i":"PNG"},{"c":"+595","n":"Paraguay","i":"PRY"},{"c":"+51","n":"Peru","i":"PER"},{"c":"+63","n":"Philippines","i":"PHL"},{"c":"+48","n":"Poland","i":"POL"},{"c":"+351","n":"Portugal","i":"PRT"},{"c":"+974","n":"Qatar","i":"QAT"},{"c":"+40","n":"Romania","i":"ROU"},{"c":"+7","n":"Russia","i":"RUS"},{"c":"+250","n":"Rwanda","i":"RWA"},{"c":"+1","n":"Saint Kitts and Nevis","i":"KNA"},{"c":"+1","n":"Saint Lucia","i":"LCA"},{"c":"+1","n":"Saint Vincent","i":"VCT"},{"c":"+685","n":"Samoa","i":"WSM"},{"c":"+378","n":"San Marino","i":"SMR"},{"c":"+239","n":"Sao Tome and Principe","i":"STP"},{"c":"+966","n":"Saudi Arabia","i":"SAU"},{"c":"+221","n":"Senegal","i":"SEN"},{"c":"+381","n":"Serbia","i":"SRB"},{"c":"+248","n":"Seychelles","i":"SYC"},{"c":"+232","n":"Sierra Leone","i":"SLE"},{"c":"+421","n":"Slovakia","i":"SVK"},{"c":"+386","n":"Slovenia","i":"SVN"},{"c":"+677","n":"Solomon Islands","i":"SLB"},{"c":"+252","n":"Somalia","i":"SOM"},{"c":"+27","n":"South Africa","i":"ZAF"},{"c":"+82","n":"South Korea","i":"KOR"},{"c":"+211","n":"South Sudan","i":"SSD"},{"c":"+34","n":"Spain","i":"ESP"},{"c":"+94","n":"Sri Lanka","i":"LKA"},{"c":"+249","n":"Sudan","i":"SDN"},{"c":"+597","n":"Suriname","i":"SUR"},{"c":"+46","n":"Sweden","i":"SWE"},{"c":"+41","n":"Switzerland","i":"CHE"},{"c":"+963","n":"Syria","i":"SYR"},{"c":"+886","n":"Taiwan","i":"TWN"},{"c":"+992","n":"Tajikistan","i":"TJK"},{"c":"+255","n":"Tanzania","i":"TZA"},{"c":"+66","n":"Thailand","i":"THA"},{"c":"+670","n":"Timor-Leste","i":"TLS"},{"c":"+228","n":"Togo","i":"TGO"},{"c":"+676","n":"Tonga","i":"TON"},{"c":"+1","n":"Trinidad and Tobago","i":"TTO"},{"c":"+216","n":"Tunisia","i":"TUN"},{"c":"+90","n":"Turkey","i":"TUR"},{"c":"+993","n":"Turkmenistan","i":"TKM"},{"c":"+688","n":"Tuvalu","i":"TUV"},{"c":"+256","n":"Uganda","i":"UGA"},{"c":"+380","n":"Ukraine","i":"UKR"},{"c":"+598","n":"Uruguay","i":"URY"},{"c":"+998","n":"Uzbekistan","i":"UZB"},{"c":"+678","n":"Vanuatu","i":"VUT"},{"c":"+379","n":"Vatican City","i":"VAT"},{"c":"+58","n":"Venezuela","i":"VEN"},{"c":"+84","n":"Vietnam","i":"VNM"},{"c":"+967","n":"Yemen","i":"YEM"},{"c":"+260","n":"Zambia","i":"ZMB"},{"c":"+263","n":"Zimbabwe","i":"ZWE"}];

    function setupDropdown(inputId, dropdownId) {
        var input = document.getElementById(inputId);
        var dropdown = document.getElementById(dropdownId);
        if (!input || !dropdown) return;
        
        function renderList(filter) {
            dropdown.innerHTML = "";
            var filtered = countries.filter(function(c) {
                var searchStr = (c.c + " " + c.i + " " + c.n).toLowerCase();
                return !filter || searchStr.indexOf(filter.toLowerCase()) !== -1;
            });
            
            if (filtered.length === 0) {
                var empty = document.createElement("div");
                empty.textContent = "No matches";
                empty.style.padding = "10px 14px";
                empty.style.fontSize = "13px";
                empty.style.color = "#94A3B8";
                empty.style.textAlign = "center";
                dropdown.appendChild(empty);
                return;
            }
            
            filtered.forEach(function(c) {
                var item = document.createElement("div");
                item.textContent = c.n + " (" + c.c + " " + c.i + ")";
                item.style.padding = "10px 14px";
                item.style.cursor = "pointer";
                item.style.fontSize = "13px";
                item.style.color = "#1E293B";
                item.style.borderRadius = "8px";
                item.style.transition = "background 0.15s, color 0.15s";
                
                item.addEventListener("mouseenter", function() {
                    item.style.background = "#F1F5F9";
                    item.style.color = "#0F172A";
                });
                item.addEventListener("mouseleave", function() {
                    item.style.background = "transparent";
                    item.style.color = "#1E293B";
                });
                item.addEventListener("click", function(e) {
                    input.value = c.c + " " + c.i;
                    dropdown.style.display = "none";
                    e.stopPropagation();
                });
                dropdown.appendChild(item);
            });
        }
        
        input.addEventListener("focus", function() {
            dropdown.style.display = "block";
            input.dataset.prev = input.value;
            input.value = "";
            renderList("");
        });
        
        input.addEventListener("input", function() {
            dropdown.style.display = "block";
            renderList(input.value);
        });
        
        input.addEventListener("blur", function() {
            setTimeout(function() {
                if (input.value === "") {
                    input.value = input.dataset.prev || "+91 IND";
                }
                dropdown.style.display = "none";
            }, 200);
        });
    }

    setupDropdown("cc_input_hero_proposal", "cc_dropdown_hero_proposal");
    setupDropdown("cc_input_footer_proposal", "cc_dropdown_footer_proposal");

    // Service Dropdowns
    function setupSelectDropdown(triggerId, inputId, dropdownId, options) {
        var trigger = document.getElementById(triggerId);
        var input = document.getElementById(inputId);
        var dropdown = document.getElementById(dropdownId);
        if (!trigger || !input || !dropdown) return;
        
        function renderOptions() {
            dropdown.innerHTML = "";
            options.forEach(function(o) {
                var item = document.createElement("div");
                item.textContent = o.n;
                item.style.padding = "10px 14px";
                item.style.cursor = "pointer";
                item.style.fontSize = "13px";
                item.style.color = "#1E293B";
                item.style.borderRadius = "8px";
                item.style.transition = "background 0.15s, color 0.15s";
                
                item.addEventListener("mouseenter", function() {
                    item.style.background = "#F1F5F9";
                    item.style.color = "#0F172A";
                });
                item.addEventListener("mouseleave", function() {
                    item.style.background = "transparent";
                    item.style.color = "#1E293B";
                });
                item.addEventListener("click", function(e) {
                    trigger.value = o.n;
                    input.value = o.v;
                    dropdown.style.display = "none";
                    e.stopPropagation();
                });
                dropdown.appendChild(item);
            });
        }
        
        trigger.addEventListener("click", function(e) {
            var isDisplayed = dropdown.style.display === "block";
            dropdown.style.display = isDisplayed ? "none" : "block";
            if (!isDisplayed) {
                renderOptions();
            }
            e.stopPropagation();
        });
        
        document.addEventListener("click", function(e) {
            if (e.target !== trigger && !dropdown.contains(e.target)) {
                dropdown.style.display = "none";
            }
        });
    }

    var services = [
        { v: "consulting", n: "{{service}} Consulting" },
        { v: "implementation", n: "{{service}} Implementation" },
        { v: "maintenance", n: "{{service}} Maintenance" },
        { v: "other", n: "Other Services" }
    ];
    setupSelectDropdown("service_trigger_hero_proposal", "service_input_hero_proposal", "service_dropdown_hero_proposal", services);
    setupSelectDropdown("service_trigger_footer_proposal", "service_input_footer_proposal", "service_dropdown_footer_proposal", services);

    var budgets = [
        { v: "under1k", n: "Under $1,000" },
        { v: "1k-5k", n: "$1,000 - $5,000" },
        { v: "5k-10k", n: "$5,000 - $10,000" },
        { v: "10k+", n: "$10,000+" }
    ];
    setupSelectDropdown("budget_trigger_hero_proposal", "budget_input_hero_proposal", "budget_dropdown_hero_proposal", budgets);
    setupSelectDropdown("budget_trigger_footer_proposal", "budget_input_footer_proposal", "budget_dropdown_footer_proposal", budgets);
})();
</script>
HTML;

        $updated = false;
        if (!$has_default) {
            $templates[] = [
                'id' => 'default',
                'name' => 'Premium Landing Page (Vispan Style - Fallback)',
                'html' => '',
                'active' => empty($templates) ? true : false
            ];
            $updated = true;
        }

        if (!$has_vispan_custom) {
            $templates[] = [
                'id' => 'vispan_custom',
                'name' => 'Vispan Premium HTML Custom Template',
                'html' => $vispan_html,
                'active' => true
            ];
            $updated = true;

            // Make default inactive
            foreach ($templates as &$t) {
                if ($t['id'] === 'default') {
                    $t['active'] = false;
                }
            }
        } else {
            // Update existing custom template if it's outdated
            foreach ($templates as &$t) {
                if ($t['id'] === 'vispan_custom') {
                    if (strpos($t['html'], 'lswg-light-theme-v6') === false) {
                        $t['html'] = $vispan_html;
                        $t['active'] = true;
                        $updated = true;
                    }
                }
            }
        }

        if ($updated) {
            update_option('lswg_templates', $templates);
        }
    }

    /* ---------------------------------------------------------
     * ADMIN MENU
     * --------------------------------------------------------- */

    public function admin_menu() {
        add_menu_page(
            'City Page Generator',
            'City Page Generator',
            'manage_options',
            'local-service-generator',
            [$this, 'admin_page'],
            'dashicons-layout',
            3
        );

        add_submenu_page(
            'local-service-generator',
            'City Page Generator',
            'City Page Generator',
            'manage_options',
            'local-service-generator',
            [$this, 'admin_page']
        );

        add_submenu_page(
            'local-service-generator',
            'CSV Bulk Import',
            'CSV Bulk Import',
            'manage_options',
            'lswg-csv-bulk-import',
            [$this, 'csv_bulk_import_page']
        );

        add_submenu_page(
            'local-service-generator',
            'City Database',
            'City Database',
            'manage_options',
            'lswg-city-database',
            [$this, 'city_database_page']
        );

        add_submenu_page(
            'local-service-generator',
            'Templates',
            'Templates',
            'manage_options',
            'lswg-templates',
            [$this, 'templates_page']
        );

        add_submenu_page(
            'local-service-generator',
            'OpenAI Status',
            'OpenAI Status',
            'manage_options',
            'lswg-openai-status',
            [$this, 'openai_status_page']
        );

        add_submenu_page(
            'local-service-generator',
            'Keywords',
            'Keywords',
            'manage_options',
            'lswg-keywords',
            [$this, 'keywords_page']
        );
    }

    /* ---------------------------------------------------------
     * CSS / JS ASSETS
     * --------------------------------------------------------- */

    public function frontend_assets() {
        wp_enqueue_style(
            'lswg-google-font',
            'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap',
            [],
            null
        );

        wp_enqueue_style(
            'lswg-frontend-style',
            plugin_dir_url(__FILE__) . 'assets/css/landing-page.css',
            [],
            filemtime(plugin_dir_path(__FILE__) . 'assets/css/landing-page.css')
        );

        wp_enqueue_script(
            'lswg-frontend-script',
            plugin_dir_url(__FILE__) . 'assets/js/landing-page.js',
            [],
            filemtime(plugin_dir_path(__FILE__) . 'assets/js/landing-page.js'),
            true
        );
    }

    public function admin_assets($hook) {

        if (strpos($hook, 'local-service-generator') === false && strpos($hook, 'lswg-') === false) {
            return;
        }

        wp_enqueue_style(
            'lswg-google-font',
            'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap',
            [],
            null
        );

        wp_enqueue_style(
            'lswg-frontend-style',
            plugin_dir_url(__FILE__) . 'assets/css/landing-page.css',
            [],
            filemtime(plugin_dir_path(__FILE__) . 'assets/css/landing-page.css')
        );

        wp_enqueue_script(
            'lswg-frontend-script',
            plugin_dir_url(__FILE__) . 'assets/js/landing-page.js',
            [],
            filemtime(plugin_dir_path(__FILE__) . 'assets/js/landing-page.js'),
            true
        );

        wp_register_style('lswg-admin-style', false);
        wp_enqueue_style('lswg-admin-style');

        wp_add_inline_style('lswg-admin-style', $this->admin_css());

        wp_register_script('lswg-admin-script', false, ['jquery'], null, true);
        wp_enqueue_script('lswg-admin-script');

        wp_localize_script(
            'lswg-admin-script',
            'LSWG',
            [
                'ajax'  => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('lswg_nonce')
            ]
        );

        wp_add_inline_script('lswg-admin-script', $this->admin_js());
    }

    /* ---------------------------------------------------------
     * ADMIN PAGE
     * --------------------------------------------------------- */

    public function admin_page() {

        $saved = get_option($this->option_key, []);

        $city = !empty($saved['city']) ? esc_attr($saved['city']) : '';
        $service = !empty($saved['service']) ? esc_attr($saved['service']) : '';
        $keywords = !empty($saved['keywords']) ? esc_attr($saved['keywords']) : '';

        ?>

        <div class="lswg-app">

            <!-- TOP BAR -->
            <header class="lswg-topbar">

                <div class="lswg-brand">

                    <div class="lswg-logo">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>

                    <div>
                        <strong>City Service Page Generator</strong>
                    </div>

                </div>

                <div class="lswg-top-actions">

                    <span class="lswg-status">
                        <i></i>
                        WordPress Plugin
                    </span>

                    <button class="lswg-preview-btn" id="lswg-scroll-preview">
                        Preview Page
                        <span>↗</span>
                    </button>

                </div>

            </header>

            <main class="lswg-main">

                <!-- BUILDER -->
                <section class="lswg-builder-wrap">

                    <div class="lswg-builder-card">

                        <div class="lswg-builder-heading">

                            <div>
                                <span class="section-number">01</span>

                                <div>
                                    <h2>Tell us about your business</h2>
                                    <p>
                                        Only two details are required to generate your landing page.
                                    </p>
                                </div>
                            </div>

                            <div class="secure-badge">
                                <span>✓</span>
                                Automatic
                            </div>

                        </div>


                        <div class="lswg-form-grid">

                            <!-- CITY -->
                            <div class="lswg-field">

                                <label>
                                    <span class="field-icon">⌖</span>
                                    CITY
                                </label>

                                <div class="lswg-input-wrap">

                                    <input
                                        type="text"
                                        id="lswg-city"
                                        value="<?php echo $city; ?>"
                                        placeholder="e.g. Rajkot"
                                    >

                                    <span class="input-check">✓</span>

                                </div>

                                <small>
                                    Enter the city where your service operates.
                                </small>

                            </div>


                            <!-- SERVICE -->
                            <div class="lswg-field">

                                <label>
                                    <span class="field-icon">✦</span>
                                    SERVICE
                                </label>

                                <div class="lswg-input-wrap">

                                    <input
                                        type="text"
                                        id="lswg-service"
                                        value="<?php echo $service; ?>"
                                        placeholder="e.g. Tailor"
                                    >

                                    <span class="input-check">✓</span>

                                </div>

                                <small>
                                    Example: Mechanic, Electrician, Plumber, Dentist.
                                </small>

                            </div>
                        </div>
                        <!-- GENERATE BUTTON -->
                        <button id="lswg-generate" class="lswg-generate">

                            <span class="generate-icon">✦</span>

                            <span class="generate-text">
                                Generate Page
                            </span>

                            <span class="generate-arrow">→</span>

                        </button>


                        <!-- LOADING -->
                        <div id="lswg-loading" class="lswg-loading">

                            <div class="loading-head">

                                <div class="loading-spinner"></div>

                                <div>
                                    <strong>Creating your landing page...</strong>
                                    <span id="lswg-loading-text">
                                        Preparing local information
                                    </span>
                                </div>

                            </div>

                            <div class="loading-progress">
                                <span></span>
                            </div>

                        </div>

                    </div>

                </section>


                <!-- RESULT -->
                <section id="lswg-result" class="lswg-result">

                    <div class="result-heading">

                        <div>
                            <span class="section-number">02</span>

                            <div>
                                <h2>Your landing page is ready</h2>
                                <p>
                                    Your generated landing page is ready! You can publish it as a standalone page below or use the shortcode.
                                </p>
                            </div>
                        </div>

                        <div style="display:flex; align-items:center; gap:10px;">
                            <div class="ready-badge">
                                <span>✓</span>
                                Generated
                            </div>
                            <div id="lswg-source-badge" class="secure-badge" style="background:#f1f5f9; color:#475569; border:1px solid #cbd5e1; border-radius:15px; padding:6px 14px; font-size:11px; font-weight:700; display: none;">
                                Local Engine Fallback
                            </div>
                        </div>

                    </div>


                    <!-- SHORTCODE -->
                    <div class="lswg-shortcode">

                        <div>
                            <span class="code-label">SHORTCODE</span>

                            <code>[local_service_website]</code>
                        </div>

                        <button id="lswg-copy">
                            Copy
                        </button>

                    </div>


                    <!-- PUBLISHED PAGE LINK -->
                    <div class="lswg-publish-section" style="margin: 20px 0; padding: 20px; border-radius: 12px; border: 1px solid #e6e4ed; background: #fff; display: flex; flex-direction: column; gap: 15px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
                            <div>
                                <h3 style="margin:0; font-size:16px; font-family: 'Plus Jakarta Sans', sans-serif; font-weight: 800;">Publish as WordPress Page</h3>
                                <p style="margin:5px 0 0; font-size:12px; color:#8c8f9c;">Generate a standalone, search-friendly page in your WordPress site.</p>
                            </div>
                            <button id="lswg-publish-btn" class="lswg-preview-btn" style="background:#6c38ff; color:#fff; border-color:#6c38ff; font-weight:700;">
                                ✦ Publish Page
                            </button>
                        </div>
                        <div id="lswg-publish-loading" style="display:none; align-items:center; gap:10px;">
                            <div class="loading-spinner" style="width:20px; height:20px; border-width: 2px;"></div>
                            <span style="font-size:13px; font-weight:600;">Publishing your page...</span>
                        </div>
                        <div id="lswg-publish-result" style="display:none; align-items:center; gap:10px; background:#e8f9f0; padding:12px 18px; border-radius:8px; border:1px solid #31c875;">
                            <span style="color:#2fbe75; font-weight:800; font-size:16px;">✓</span>
                            <span style="font-size:13px; font-weight:600; color:#1e4d30;">Page Published Successfully!</span>
                            <a href="#" id="lswg-published-url" target="_blank" style="margin-left:auto; font-size:13px; font-weight:700; color:#1e4d30; text-decoration:underline;">View Page &rarr;</a>
                        </div>
                    </div>


                    <!-- WEBSITE PREVIEW -->
                    <div class="lswg-preview-container" id="lswg-preview">

                        <?php echo $this->render_preview($saved); ?>

                    </div>

                </section>

            </main>


            <!-- FOOTER -->
            <footer class="lswg-footer">

                <div>
                    <strong>LocalFlow</strong>
                    <span>Professional local website generation for WordPress.</span>
                </div>

                <div>
                    Shortcode:
                    <code>[local_service_website]</code>
                </div>

            </footer>

        </div>

        <?php
    }

    /* ---------------------------------------------------------
     * CSV BULK IMPORT PAGE
     * --------------------------------------------------------- */
    public function csv_bulk_import_page() {
        ?>
        <div class="lswg-app">
            <!-- TOP BAR -->
            <header class="lswg-topbar">
                <div class="lswg-brand">
                    <div class="lswg-logo">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div>
                        <strong>City Page Generator</strong>
                        <small>CSV Bulk Import</small>
                    </div>
                </div>
                <div class="lswg-top-actions">
                    <span class="lswg-status">
                        <i></i>
                        Bulk Import Mode
                    </span>
                </div>
            </header>

            <main class="lswg-main">
                <section class="lswg-builder-wrap">
                    <div class="lswg-builder-card">
                        <div class="lswg-builder-heading">
                            <div>
                                <span class="section-number">01</span>
                                <div>
                                    <h2>Upload CSV File</h2>
                                    <p>Upload a comma-separated file (.csv) with your list of cities and services to generate multiple pages in bulk.</p>
                                </div>
                            </div>
                        </div>

                        <!-- DRAG & DROP ZONE -->
                        <div class="lswg-csv-upload-zone" id="lswg-csv-dropzone">
                            <span class="upload-icon">📁</span>
                            <h3>Drag & Drop CSV file here</h3>
                            <p>or click to browse from your computer</p>
                            
                            <!-- Explicit button as requested by user -->
                            <button type="button" class="lswg-preview-btn" id="lswg-csv-select-btn" style="margin-top: 15px; background: #6c38ff; color: #fff; border-color: #6c38ff; font-weight: 700; position: relative; z-index: 10;">Choose CSV File</button>
                            
                            <input type="file" id="lswg-csv-file-input" accept=".csv" style="display:none;">
                            <a href="#" id="lswg-download-template" class="lswg-template-link" style="margin-top: 15px; display: inline-block; color: #6c38ff; font-weight: 600; text-decoration: none;">Download Sample CSV Template</a>
                        </div>

                        <!-- FILE DETAILS & PREVIEW (Hidden by default) -->
                        <div id="lswg-csv-preview-card" style="display:none; margin-top:25px; border-top:1px solid #e6e4ed; padding-top:25px;">
                            <div class="lswg-file-info" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                                <div>
                                    <strong id="lswg-file-name" style="font-size:16px;">file.csv</strong>
                                    <span id="lswg-file-size" style="color:#8c8f9c; font-size:12px; margin-left:10px;">(0 KB)</span>
                                </div>
                                <span id="lswg-row-count" class="secure-badge" style="background:#eef2ff; color:#4f46e5; border:1px solid #c7d2fe; border-radius:15px; padding:3px 12px; font-size:11px; font-weight:600;">0 rows detected</span>
                            </div>

                            <div class="lswg-preview-table-wrap" style="overflow-x:auto; margin-bottom:20px; border:1px solid #e6e4ed; border-radius:8px;">
                                <table id="lswg-csv-preview-table" style="width:100%; border-collapse:collapse; text-align:left; font-size:13px;">
                                    <thead>
                                        <tr style="background:#f8fafc; border-bottom:1px solid #e6e4ed;">
                                            <th style="padding:12px 15px; font-weight:600; color:#475569; border-bottom:1px solid #e6e4ed;">City</th>
                                            <th style="padding:12px 15px; font-weight:600; color:#475569; border-bottom:1px solid #e6e4ed;">Service</th>
                                            <th style="padding:12px 15px; font-weight:600; color:#475569; border-bottom:1px solid #e6e4ed;">Keywords (Optional)</th>
                                        </tr>
                                    </thead>
                                    <tbody style="background:#fff;">
                                        <!-- Rows dynamically added -->
                                    </tbody>
                                </table>
                            </div>

                            <button id="lswg-start-bulk" class="lswg-generate" style="width:100%; justify-content:center;">
                                <span class="generate-icon">⚡</span>
                                <span class="generate-text">Start Bulk Generation</span>
                            </button>
                        </div>

                        <!-- BULK PROGRESS (Hidden by default) -->
                        <div id="lswg-bulk-progress-card" style="display:none; margin-top:25px; border-top:1px solid #e6e4ed; padding-top:25px;">
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                                <strong style="font-size:15px;">Processing Pages...</strong>
                                <span id="lswg-progress-percent" style="font-weight:700; color:#6c38ff;">0%</span>
                            </div>
                            
                            <div class="loading-progress" style="height:10px; background:#e6e4ed; border-radius:5px; overflow:hidden; margin-bottom:20px;">
                                <span id="lswg-progress-bar" style="display:block; height:100%; width:0%; background:#6c38ff; transition:width 0.2s;"></span>
                            </div>

                            <div style="display:grid; grid-template-columns: repeat(3, 1fr); gap:15px; margin-bottom:20px;">
                                <div style="background:#f8fafc; border:1px solid #e6e4ed; border-radius:8px; padding:12px; text-align:center;">
                                    <span style="font-size:11px; color:#8c8f9c; display:block; text-transform:uppercase; font-weight:700; letter-spacing:0.5px;">Success</span>
                                    <strong id="lswg-stat-success" style="font-size:20px; color:#31c875; display:block; margin-top:5px;">0</strong>
                                </div>
                                <div style="background:#f8fafc; border:1px solid #e6e4ed; border-radius:8px; padding:12px; text-align:center;">
                                    <span style="font-size:11px; color:#8c8f9c; display:block; text-transform:uppercase; font-weight:700; letter-spacing:0.5px;">Failed</span>
                                    <strong id="lswg-stat-failed" style="font-size:20px; color:#ef4444; display:block; margin-top:5px;">0</strong>
                                </div>
                                <div style="background:#f8fafc; border:1px solid #e6e4ed; border-radius:8px; padding:12px; text-align:center;">
                                    <span style="font-size:11px; color:#8c8f9c; display:block; text-transform:uppercase; font-weight:700; letter-spacing:0.5px;">Remaining</span>
                                    <strong id="lswg-stat-remaining" style="font-size:20px; color:#6b7280; display:block; margin-top:5px;">0</strong>
                                </div>
                            </div>

                            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                                <strong style="font-size:13px; color:#475569;">Activity Log</strong>
                                <button id="lswg-cancel-bulk" style="background:none; border:none; color:#ef4444; font-size:12px; font-weight:600; cursor:pointer;">Cancel Operation</button>
                            </div>
                            
                            <div id="lswg-bulk-log" style="background:#0f172a; color:#f1f5f9; border-radius:8px; padding:15px; font-family:monospace; font-size:12px; height:180px; overflow-y:auto; line-height:1.6; border: 1px solid #1e293b; text-align:left;">
                                <!-- Log lines dynamically added -->
                            </div>
                        </div>

                        <!-- GENERATED LIST (Hidden by default) -->
                        <div id="lswg-csv-results-card" style="display:none; margin-top:25px; border-top:1px solid #e6e4ed; padding-top:25px;">
                            <h3 style="font-size:15px; margin-bottom:15px; font-family:'Plus Jakarta Sans',sans-serif; font-weight:800;">Successfully Generated Pages</h3>
                            <div style="max-height: 250px; overflow-y: auto; border:1px solid #e6e4ed; border-radius:8px;">
                                <table id="lswg-csv-results-table" style="width:100%; border-collapse:collapse; text-align:left; font-size:13px;">
                                    <thead>
                                        <tr style="background:#f8fafc; border-bottom:1px solid #e6e4ed;">
                                            <th style="padding:10px 15px; font-weight:600; color:#475569;">Page Title</th>
                                            <th style="padding:10px 15px; font-weight:600; color:#475569; text-align:right;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody style="background:#fff;">
                                        <!-- Results dynamically added -->
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </section>
            </main>

            <footer class="lswg-footer">
                <div>
                    <strong>LocalFlow</strong>
                    <span>Professional local website generation for WordPress.</span>
                </div>
            </footer>
        </div>
        <?php
    }

    /* ---------------------------------------------------------
     * CITY DATABASE PAGE
     * --------------------------------------------------------- */
    public function city_database_page() {
        $cities = get_option('lswg_city_database', []);
        ?>
        <div class="lswg-app">
            <header class="lswg-topbar">
                <div class="lswg-brand">
                    <div class="lswg-logo"><span></span><span></span><span></span></div>
                    <div>
                        <strong>City Page Generator</strong>
                        <small>City Database</small>
                    </div>
                </div>
                <div class="lswg-top-actions">
                    <button id="lswg-add-city-btn" class="lswg-preview-btn" style="background:#6c38ff; color:#fff; border-color:#6c38ff; font-weight:700;">
                        + Add New City
                    </button>
                </div>
            </header>

            <main class="lswg-main">
                <section class="lswg-builder-wrap">
                    <div class="lswg-builder-card">
                        
                        <!-- ADD/EDIT CITY PANEL (Hidden by default) -->
                        <div id="lswg-city-form-panel" style="display:none; background:#f8fafc; border:1px solid #e6e4ed; border-radius:12px; padding:20px; margin-bottom:25px; text-align:left;">
                            <h3 id="lswg-city-form-title" style="margin-top:0; font-family:'Plus Jakarta Sans',sans-serif; font-weight:800; font-size:16px;">Add New City</h3>
                            <input type="hidden" id="lswg-city-id" value="">
                            
                            <div style="display:grid; grid-template-columns: 1fr 2fr; gap:15px; margin-top:15px;">
                                <div class="lswg-field">
                                    <label style="font-weight:600; display:block; margin-bottom:6px; font-size:12px; color:#475569;">City Name</label>
                                    <input type="text" id="lswg-city-name" class="spg-input" style="width:100%; border: 1px solid #e6e4ed; border-radius: 8px; padding: 10px 14px;" placeholder="e.g. Rajkot">
                                </div>
                                <div class="lswg-field">
                                    <label style="font-weight:600; display:block; margin-bottom:6px; font-size:12px; color:#475569;">Local Address</label>
                                    <input type="text" id="lswg-city-address" class="spg-input" style="width:100%; border: 1px solid #e6e4ed; border-radius: 8px; padding: 10px 14px;" placeholder="e.g. 314 Complex, Vijay Plot...">
                                </div>
                            </div>
                            
                            <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:20px;">
                                <button id="lswg-cancel-city-btn" class="lswg-preview-btn" style="border-color:#e6e4ed; color:#475569;">Cancel</button>
                                <button id="lswg-save-city-btn" class="lswg-preview-btn" style="background:#6c38ff; color:#fff; border-color:#6c38ff; font-weight:700;">Save City</button>
                            </div>
                        </div>

                        <div class="lswg-builder-heading">
                            <div>
                                <span class="section-number">⌖</span>
                                <div>
                                    <h2>Configured Cities & Locations</h2>
                                    <p>Manage the list of cities and their custom local addresses used for page generation.</p>
                                </div>
                            </div>
                        </div>

                        <div class="lswg-preview-table-wrap" style="overflow-x:auto; margin-top:20px; border:1px solid #e6e4ed; border-radius:8px;">
                            <table style="width:100%; border-collapse:collapse; text-align:left; font-size:13px;">
                                <thead>
                                    <tr style="background:#f8fafc; border-bottom:1px solid #e6e4ed;">
                                        <th style="padding:12px 15px; font-weight:600; color:#475569; width:20%;">City Name</th>
                                        <th style="padding:12px 15px; font-weight:600; color:#475569;">Configured Local Address</th>
                                        <th style="padding:12px 15px; font-weight:600; color:#475569; text-align:center; width:20%;">Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="lswg-city-table-body" style="background:#fff;">
                                    <?php if (!empty($cities)) : ?>
                                        <?php foreach ($cities as $item) : ?>
                                            <tr style="border-bottom:1px solid #f0edf5;" data-id="<?php echo esc_attr($item['id']); ?>" data-city="<?php echo esc_attr($item['city']); ?>" data-address="<?php echo esc_attr($item['address']); ?>">
                                                <td style="padding:12px 15px; font-weight:600;"><?php echo esc_html($item['city']); ?></td>
                                                <td style="padding:12px 15px; color:#555;"><?php echo esc_html($item['address']); ?></td>
                                                <td style="padding:12px 15px; text-align:center;">
                                                    <button class="lswg-edit-city-btn" style="background:none; border:none; color:#6c38ff; font-weight:700; cursor:pointer; margin-right:10px;">Edit</button>
                                                    <button class="lswg-delete-city-btn" style="background:none; border:none; color:#ef4444; font-weight:700; cursor:pointer;">Delete</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else : ?>
                                        <tr>
                                            <td colspan="3" style="padding:20px; text-align:center; color:#8c8f9c;">No cities configured. Click "Add New City" to add one.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
            </main>

            <footer class="lswg-footer">
                <div>
                    <strong>LocalFlow</strong>
                    <span>Professional local website generation for WordPress.</span>
                </div>
            </footer>
        </div>
        <?php
    }

    /* ---------------------------------------------------------
     * TEMPLATES PAGE
     * --------------------------------------------------------- */
    public function templates_page() {
        $templates = get_option('lswg_templates', []);
        ?>
        <div class="lswg-app">
            <header class="lswg-topbar">
                <div class="lswg-brand">
                    <div class="lswg-logo"><span></span><span></span><span></span></div>
                    <div>
                        <strong>City Page Generator</strong>
                        <small>Templates</small>
                    </div>
                </div>
                <div class="lswg-top-actions" style="display:flex; gap:10px; align-items:center;">
                    <label class="lswg-preview-btn" style="background:#0f1124; color:#fff; border:1px solid #0f1124; font-weight:700; cursor:pointer; display:inline-flex; align-items:center; gap:6px; margin:0; padding:10px 18px; border-radius:8px; font-size:12px;">
                        <span>📥 Import JSON</span>
                        <input type="file" id="lswg-import-json-input" accept=".json" style="display:none;">
                    </label>
                    <button id="lswg-add-template-btn" class="lswg-preview-btn" style="background:#6c38ff; color:#fff; border-color:#6c38ff; font-weight:700;">
                        + Add Custom Template
                    </button>
                </div>
            </header>

            <main class="lswg-main">
                <section class="lswg-builder-wrap">
                    <div class="lswg-builder-card">

                        <!-- ADD/EDIT TEMPLATE PANEL (Hidden by default) -->
                        <div id="lswg-template-form-panel" style="display:none; background:#f8fafc; border:1px solid #e6e4ed; border-radius:12px; padding:20px; margin-bottom:25px; text-align:left;">
                            <h3 id="lswg-template-form-title" style="margin-top:0; font-family:'Plus Jakarta Sans',sans-serif; font-weight:800; font-size:16px;">Add Custom Template</h3>
                            <input type="hidden" id="lswg-template-id" value="">
                            
                            <div class="lswg-field" style="margin-top:15px;">
                                <label style="font-weight:600; display:block; margin-bottom:6px; font-size:12px; color:#475569;">Template Name</label>
                                <input type="text" id="lswg-template-name" class="spg-input" style="width:100%; border:1px solid #e6e4ed; border-radius:8px; padding:10px 14px;" placeholder="e.g. Modern Minimalist Layout">
                            </div>
                            <div class="lswg-field" style="margin-top:15px;">
                                <label style="font-weight:600; display:block; margin-bottom:6px; font-size:12px; color:#475569;">Template HTML Code</label>
                                <textarea id="lswg-template-html" class="spg-input" style="width:100%; height:250px; font-family:monospace; font-size:13px; border:1px solid #e6e4ed; border-radius:8px; padding:10px 14px;" placeholder="Use HTML tags and placeholders:
{{service}} - Service Name
{{city}} - City Name
{{business_name}} - Business Name
{{address}} - Custom Address
{{sec1_title}} - Main Title
{{sec1_caption}} - Main Caption
{{sec2_title}} - Description Title
{{sec2_text}} - Description Text
{{image_1}}, {{image_2}}, {{image_3}} - Dynamic Images URLs
{{email}} - Contact Email Address"></textarea>
                            </div>
                            
                            <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:20px;">
                                <button id="lswg-cancel-template-btn" class="lswg-preview-btn" style="border-color:#e6e4ed; color:#475569;">Cancel</button>
                                <button id="lswg-save-template-btn" class="lswg-preview-btn" style="background:#6c38ff; color:#fff; border-color:#6c38ff; font-weight:700;">Save Template</button>
                            </div>
                        </div>

                        <div class="lswg-builder-heading">
                            <div>
                                <span class="section-number">🎨</span>
                                <div>
                                    <h2>Layout Templates</h2>
                                    <p>Select or add templates utilized to structure the generated service landing pages.</p>
                                </div>
                            </div>
                        </div>

                        <div id="lswg-templates-grid" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:20px; margin-top:20px;">
                            <?php foreach ($templates as $t) : 
                                $is_active = !empty($t['active']);
                                $is_default = ($t['id'] === 'default');
                            ?>
                                <div class="lswg-template-item" data-id="<?php echo esc_attr($t['id']); ?>" data-name="<?php echo esc_attr($t['name']); ?>" style="border: <?php echo $is_active ? '2px solid #6c38ff' : '1px solid #e6e4ed'; ?>; border-radius: 12px; background: #fff; overflow: hidden; display: flex; flex-direction: column; box-shadow: <?php echo $is_active ? '0 10px 30px rgba(108,56,255,0.06)' : 'none'; ?>;">
                                    <!-- Embedded hidden html container to avoid quote nesting issues in custom template loading -->
                                    <textarea class="lswg-raw-html" style="display:none;"><?php echo esc_textarea($t['html']); ?></textarea>
                                    
                                    <div style="height: 140px; background: <?php echo $is_default ? 'linear-gradient(135deg, #a78bfa, #6c38ff)' : 'linear-gradient(135deg, #f472b6, #e11d48)'; ?>; display: flex; align-items: center; justify-content: center; color: #fff; font-size: 32px; font-weight: 800; font-family:'Plus Jakarta Sans',sans-serif;">
                                        <?php echo $is_default ? '✦ Vispan' : '✦ Custom'; ?>
                                    </div>
                                    <div style="padding: 20px; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between;">
                                        <div style="text-align:left;">
                                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                                                <strong style="font-size: 15px; font-family:'Plus Jakarta Sans',sans-serif;"><?php echo esc_html($t['name']); ?></strong>
                                                <?php if ($is_active) : ?>
                                                    <span style="background: #e8f9f0; color: #2fbe75; font-size: 10px; padding: 2px 8px; border-radius: 10px; font-weight: 700;">ACTIVE</span>
                                                <?php endif; ?>
                                            </div>
                                            <p style="color: #6b7280; font-size: 12px; line-height: 1.5; margin: 0 0 15px 0;">
                                                <?php echo $is_default ? 'Featuring fully responsive layouts, hero sliders, feature cards, location lists, dynamic stock images, and client testimonials.' : 'Manually created custom HTML layout utilizing dynamic placeholders.'; ?>
                                            </p>
                                        </div>
                                        <div style="display:flex; gap:10px;">
                                            <?php if (!$is_active) : ?>
                                                <button class="lswg-activate-template-btn lswg-preview-btn" style="flex-grow:1; background:#6c38ff; color:#fff; border-color:#6c38ff; font-weight:700;">Activate</button>
                                            <?php else : ?>
                                                <button class="lswg-preview-btn" style="flex-grow:1; border-color:#e6e4ed; color:#8c8f9c; cursor:default;" disabled>Active Layout</button>
                                            <?php endif; ?>
                                            
                                            <?php if (!$is_default) : ?>
                                                <button class="lswg-edit-template-btn lswg-preview-btn" style="border-color:#e6e4ed; color:#4f46e5; font-weight:700;">Edit</button>
                                                <button class="lswg-delete-template-btn lswg-preview-btn" style="border-color:#e6e4ed; color:#ef4444; font-weight:700;">Delete</button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </section>
            </main>

            <footer class="lswg-footer">
                <div>
                    <strong>LocalFlow</strong>
                    <span>Professional local website generation for WordPress.</span>
                </div>
            </footer>
        </div>
        <?php
    }

    /* ---------------------------------------------------------
     * OPENAI STATUS PAGE
     * --------------------------------------------------------- */
    public function openai_status_page() {
        $api_key = get_option('lswg_openai_key', '');
        $has_key = !empty($api_key);
        ?>
        <div class="lswg-app">
            <header class="lswg-topbar">
                <div class="lswg-brand">
                    <div class="lswg-logo">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div>
                        <strong>City Page Generator</strong>
                        <small>OpenAI Status</small>
                    </div>
                </div>
                <div class="lswg-top-actions">
                    <span id="lswg-header-status" class="lswg-status" style="<?php echo $has_key ? 'background:#e8f9f0; color:#2fbe75; border-color:#c2f0d5;' : 'background:#f1f5f9; color:#475569; border-color:#cbd5e1;'; ?>">
                        <i style="background:<?php echo $has_key ? '#2fbe75' : '#64748b'; ?>;"></i>
                        <span id="lswg-status-text"><?php echo $has_key ? 'Engine Operational' : 'Mock Mode Active'; ?></span>
                    </span>
                </div>
            </header>

            <main class="lswg-main">
                <section class="lswg-builder-wrap">
                    <div class="lswg-builder-card">
                        <div class="lswg-builder-heading">
                            <div>
                                <span class="section-number">✦</span>
                                <div>
                                    <h2>Natural Language Engine</h2>
                                    <p>Monitor API connection status and configuration for generating content.</p>
                                </div>
                            </div>
                        </div>

                        <div style="margin-top:20px; display:grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap:20px;">
                            <div style="background: #fff; border: 1px solid #e6e4ed; border-radius: 12px; padding: 25px; text-align: left;">
                                <h3 style="font-family:'Plus Jakarta Sans',sans-serif; margin-top:0; font-size:16px;">API Key Configuration</h3>
                                <div class="lswg-field" style="margin-top: 15px;">
                                    <label>OpenAI API Key</label>
                                    <div class="lswg-input-wrap">
                                        <input type="password" id="lswg-openai-key-input" class="spg-input" value="<?php echo esc_attr($api_key); ?>" style="width: 100%; border: 1px solid #e6e4ed; border-radius: 8px; padding: 10px 14px;" placeholder="sk-proj-...">
                                    </div>
                                    <small id="lswg-openai-mode-desc" style="display:block; margin-top:8px; color:#8c8f9c;">
                                        <?php echo $has_key ? 'Live OpenAI Mode is active. API charges apply to your account.' : 'Local NLP Engine v2.0 (Mock mode) is active. No external API fees apply.'; ?>
                                    </small>
                                </div>
                                <button id="lswg-save-openai-settings-btn" class="lswg-generate" style="margin-top: 20px; width:100%; justify-content:center; background:#4f46e5; border-color:#4f46e5;">Save Settings</button>
                            </div>

                            <div style="background: #fff; border: 1px solid #e6e4ed; border-radius: 12px; padding: 25px; display:flex; flex-direction:column; justify-content:space-between; text-align: left;">
                                <div>
                                    <h3 style="font-family:'Plus Jakarta Sans',sans-serif; margin-top:0; font-size:16px;">System Health</h3>
                                    <ul style="padding:0; margin:15px 0 0 0; list-style:none; font-size:13px; line-height:2;">
                                        <li style="display:flex; justify-content:space-between;">
                                            <span style="color:#6b7280;">Connection Status:</span>
                                            <strong id="lswg-diag-status" style="color:<?php echo $has_key ? '#2fbe75' : '#475569'; ?>;"><?php echo $has_key ? 'Healthy (Live)' : 'Mock Mode (Local)'; ?></strong>
                                        </li>
                                        <li style="display:flex; justify-content:space-between;">
                                            <span style="color:#6b7280;">Average Latency:</span>
                                            <strong id="lswg-diag-latency"><?php echo $has_key ? '-- ms' : '12 ms'; ?></strong>
                                        </li>
                                        <li style="display:flex; justify-content:space-between;">
                                            <span style="color:#6b7280;">Model Endpoint:</span>
                                            <code id="lswg-diag-model"><?php echo $has_key ? 'gpt-4o-mini (Live)' : 'gpt-4o-mini (Fallback)'; ?></code>
                                        </li>
                                    </ul>
                                </div>
                                <button id="lswg-test-openai-connection-btn" class="lswg-preview-btn" style="width:100%; border-color:#e6e4ed; color:#475569; margin-top:20px;">Run Connection Diagnostics</button>
                            </div>
                        </div>
                    </div>
                </section>
            </main>

            <footer class="lswg-footer">
                <div>
                    <strong>LocalFlow</strong>
                    <span>Professional local website generation for WordPress.</span>
                </div>
            </footer>
        </div>
        <?php
    }

    /* ---------------------------------------------------------
     * KEYWORDS PAGE
     * --------------------------------------------------------- */
    public function keywords_page() {
        ?>
        <div class="lswg-app">
            <header class="lswg-topbar">
                <div class="lswg-brand">
                    <div class="lswg-logo">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div>
                        <strong>City Page Generator</strong>
                        <small>Keywords</small>
                    </div>
                </div>
                <div class="lswg-top-actions">
                    <span class="lswg-status">
                        <i></i>
                        SEO Active
                    </span>
                </div>
            </header>

            <main class="lswg-main">
                <section class="lswg-builder-wrap">
                    <div class="lswg-builder-card">
                        <div class="lswg-builder-heading">
                            <div>
                                <span class="section-number">⭐</span>
                                <div>
                                    <h2>Target SEO Keywords</h2>
                                    <p>The primary high-intent search terms embedded in service page structures to capture organic local Google search traffic.</p>
                                </div>
                            </div>
                        </div>

                        <div class="lswg-preview-table-wrap" style="overflow-x:auto; margin-top:20px; border:1px solid #e6e4ed; border-radius:8px;">
                            <table style="width:100%; border-collapse:collapse; text-align:left; font-size:13px;">
                                <thead>
                                    <tr style="background:#f8fafc; border-bottom:1px solid #e6e4ed;">
                                        <th style="padding:12px 15px; font-weight:600; color:#475569; width:25%;">Service Category</th>
                                        <th style="padding:12px 15px; font-weight:600; color:#475569;">Target High-Intent Keyphrase Patterns</th>
                                    </tr>
                                </thead>
                                <tbody style="background:#fff;">
                                    <tr style="border-bottom:1px solid #f0edf5;">
                                        <td style="padding:12px 15px; font-weight:600;">🔧 Plumber</td>
                                        <td style="padding:12px 15px; color:#555; line-height:1.5;">best plumber in [City], emergency plumbing [City], local leak repair, drain cleaning near me in [City]</td>
                                    </tr>
                                    <tr style="border-bottom:1px solid #f0edf5;">
                                        <td style="padding:12px 15px; font-weight:600;">⚡ Electrician</td>
                                        <td style="padding:12px 15px; color:#555; line-height:1.5;">best electrician in [City], certified electrical repair [City], residential rewiring [City], emergency electrician near me</td>
                                    </tr>
                                    <tr style="border-bottom:1px solid #f0edf5;">
                                        <td style="padding:12px 15px; font-weight:600;">🧵 Tailor</td>
                                        <td style="padding:12px 15px; color:#555; line-height:1.5;">best tailor in [City], clothing alterations [City], custom suit adjustments, custom clothing shop near me</td>
                                    </tr>
                                    <tr style="border-bottom:1px solid #f0edf5;">
                                        <td style="padding:12px 15px; font-weight:600;">🦷 Dentist</td>
                                        <td style="padding:12px 15px; color:#555; line-height:1.5;">best dentist in [City], pain-free dental clinic [City], cosmetic teeth whitening, teeth cleaner near me in [City]</td>
                                    </tr>
                                    <tr style="border-bottom:1px solid #f0edf5;">
                                        <td style="padding:12px 15px; font-weight:600;">🧹 Cleaning / Maid</td>
                                        <td style="padding:12px 15px; color:#555; line-height:1.5;">best cleaning services in [City], house cleaners near me [City], deep home cleaning [City], maid service</td>
                                    </tr>
                                    <tr style="border-bottom:1px solid #f0edf5;">
                                        <td style="padding:12px 15px; font-weight:600;">📈 Marketing / SEO</td>
                                        <td style="padding:12px 15px; color:#555; line-height:1.5;">best digital marketing agency in [City], local SEO services [City], Google ads management, rank page 1 in [City]</td>
                                    </tr>
                                    <tr>
                                        <td style="padding:12px 15px; font-weight:600;">🚗 Mechanic / Auto</td>
                                        <td style="padding:12px 15px; color:#555; line-height:1.5;">best mechanic in [City], local auto repair shop [City], engine fault scan, brake replacement workshop near me</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
            </main>

            <footer class="lswg-footer">
                <div>
                    <strong>LocalFlow</strong>
                    <span>Professional local website generation for WordPress.</span>
                </div>
            </footer>
        </div>
        <?php
    }

    /* ---------------------------------------------------------
     * TEMPLATE OVERRIDE
     * --------------------------------------------------------- */

    public function template_override($template) {
        if (is_page()) {
            $page_id = get_the_ID();
            $selected_template = get_post_meta($page_id, '_wp_page_template', true);
            if (get_post_meta($page_id, '_is_lswg_generated', true) || $selected_template === 'templates/landing-page-template.php' || basename($selected_template) === 'landing-page-template.php') {
                $custom_template = plugin_dir_path(__FILE__) . 'templates/landing-page-template.php';
                if (file_exists($custom_template)) {
                    return $custom_template;
                }
            }
        }
        return $template;
    }

    public function register_project_templates($post_templates, $theme, $post, $post_type) {
        if ('page' === $post_type) {
            $post_templates['templates/landing-page-template.php'] = 'LSWG Generated Landing Page';
        }
        return $post_templates;
    }

    /* ---------------------------------------------------------
     * AJAX CITY CRUD HOOKS
     * --------------------------------------------------------- */
    public function ajax_save_city() {
        check_ajax_referer('lswg_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }

        $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';
        $city = isset($_POST['city']) ? sanitize_text_field(wp_unslash($_POST['city'])) : '';
        $address = isset($_POST['address']) ? sanitize_textarea_field(wp_unslash($_POST['address'])) : '';

        if (!$city || !$address) {
            wp_send_json_error(['message' => 'Please enter both city name and address.']);
        }

        $cities = get_option('lswg_city_database', []);

        if (!empty($id)) {
            $found = false;
            foreach ($cities as &$item) {
                if ($item['id'] === $id) {
                    $item['city'] = $city;
                    $item['address'] = $address;
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $cities[] = [
                    'id' => $id,
                    'city' => $city,
                    'address' => $address
                ];
            }
        } else {
            $new_id = uniqid();
            $cities[] = [
                'id' => $new_id,
                'city' => $city,
                'address' => $address
            ];
        }

        update_option('lswg_city_database', $cities);
        wp_send_json_success(['message' => 'City saved successfully!']);
    }

    public function ajax_delete_city() {
        check_ajax_referer('lswg_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }

        $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';

        if (empty($id)) {
            wp_send_json_error(['message' => 'Invalid City ID.']);
        }

        $cities = get_option('lswg_city_database', []);
        $new_cities = [];

        foreach ($cities as $item) {
            if ($item['id'] !== $id) {
                $new_cities[] = $item;
            }
        }

        update_option('lswg_city_database', $new_cities);
        wp_send_json_success(['message' => 'City deleted successfully!']);
    }

    /* ---------------------------------------------------------
     * AJAX TEMPLATE CRUD HOOKS
     * --------------------------------------------------------- */
    public function ajax_save_template() {
        check_ajax_referer('lswg_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }

        $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';
        $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        $html = isset($_POST['html']) ? wp_unslash($_POST['html']) : '';

        if (!$name) {
            wp_send_json_error(['message' => 'Please enter template name.']);
        }

        $templates = get_option('lswg_templates', []);

        if (!empty($id)) {
            foreach ($templates as &$item) {
                if ($item['id'] === $id) {
                    $item['name'] = $name;
                    $item['html'] = $html;
                    break;
                }
            }
        } else {
            $new_id = uniqid();
            $templates[] = [
                'id' => $new_id,
                'name' => $name,
                'html' => $html,
                'active' => false
            ];
        }

        update_option('lswg_templates', $templates);
        wp_send_json_success(['message' => 'Template saved successfully!']);
    }

    public function ajax_activate_template() {
        check_ajax_referer('lswg_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }

        $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';

        if (empty($id)) {
            wp_send_json_error(['message' => 'Invalid template ID.']);
        }

        $templates = get_option('lswg_templates', []);

        foreach ($templates as &$item) {
            $item['active'] = ($item['id'] === $id);
        }

        update_option('lswg_templates', $templates);
        wp_send_json_success(['message' => 'Template activated successfully!']);
    }

    public function ajax_delete_template() {
        check_ajax_referer('lswg_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }

        $id = isset($_POST['id']) ? sanitize_text_field(wp_unslash($_POST['id'])) : '';

        if (empty($id) || $id === 'default') {
            wp_send_json_error(['message' => 'Cannot delete default template.']);
        }

        $templates = get_option('lswg_templates', []);
        $new_templates = [];
        $was_active = false;

        foreach ($templates as $item) {
            if ($item['id'] !== $id) {
                $new_templates[] = $item;
            } else {
                $was_active = !empty($item['active']);
            }
        }

        if ($was_active && !empty($new_templates)) {
            foreach ($new_templates as &$item) {
                if ($item['id'] === 'default') {
                    $item['active'] = true;
                    break;
                }
            }
        }

        update_option('lswg_templates', $new_templates);
        wp_send_json_success(['message' => 'Template deleted successfully!']);
    }

    /* ---------------------------------------------------------
     * AJAX OPENAI KEY CRUD HOOKS
     * --------------------------------------------------------- */
    public function ajax_save_openai_settings() {
        check_ajax_referer('lswg_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }

        $api_key = isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '';

        update_option('lswg_openai_key', $api_key);
        wp_send_json_success(['message' => 'Settings saved successfully!']);
    }

    public function ajax_test_openai_connection() {
        check_ajax_referer('lswg_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied.']);
        }

        $api_key = isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '';
        if (empty($api_key)) {
            $api_key = get_option('lswg_openai_key', '');
        }

        if (empty($api_key)) {
            wp_send_json_error(['message' => 'No OpenAI API Key provided.']);
        }

        $start_time = microtime(true);

        $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode([
                'model' => 'gpt-4o-mini',
                'messages' => [['role' => 'user', 'content' => 'Say test']],
                'max_tokens' => 5
            ]),
            'timeout' => 8
        ]);

        $end_time = microtime(true);
        $latency = round(($end_time - $start_time) * 1000);

        if (is_wp_error($response)) {
            wp_send_json_error([
                'message' => 'API Connection failed: ' . $response->get_error_message()
            ]);
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if ($code !== 200) {
            $error_msg = isset($data['error']['message']) ? $data['error']['message'] : 'HTTP Code ' . $code;
            wp_send_json_error([
                'message' => 'API Error: ' . $error_msg
            ]);
        }

        wp_send_json_success([
            'message' => 'API Connection Operational!',
            'latency' => $latency,
            'model' => 'gpt-4o-mini'
        ]);
    }

    /* ---------------------------------------------------------
     * AJAX PUBLISH PAGE
     * --------------------------------------------------------- */

    public function ajax_publish_page() {
        check_ajax_referer('lswg_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error([
                'message' => 'Permission denied.'
            ]);
        }

        $city = isset($_POST['city']) ? sanitize_text_field(wp_unslash($_POST['city'])) : '';
        $service = isset($_POST['service']) ? sanitize_text_field(wp_unslash($_POST['service'])) : '';
        $keywords = isset($_POST['keywords']) ? sanitize_text_field(wp_unslash($_POST['keywords'])) : '';

        if (!$city || !$service) {
            wp_send_json_error([
                'message' => 'Please enter both city and service.'
            ]);
        }

        $data = $this->collect_local_data($city, $service);
        $data['city'] = $city;
        $data['service'] = $service;
        $data['keywords'] = $keywords;
        $data['business_name'] = 'Professional ' . ucwords($service) . ' in ' . $city;

        $title = "Best " . ucwords($service) . " in " . ucwords($city);
        $slug = sanitize_title("best-" . $service . "-in-" . $city);
        $existing_page = get_page_by_path($slug, OBJECT, 'page');

        $html_content = $this->render_preview($data);
        $post_content = "<!-- wp:html -->\n" . $html_content . "\n<!-- /wp:html -->";

        $post_data = [
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => $post_content,
        ];

        if ($existing_page) {
            $post_data['ID'] = $existing_page->ID;
            $page_id = wp_update_post($post_data);
        } else {
            $page_id = wp_insert_post($post_data);
        }

        if (is_wp_error($page_id) || !$page_id) {
            wp_send_json_error([
                'message' => 'Failed to publish page.'
            ]);
        }
        
        update_post_meta($page_id, '_is_lswg_generated', '1');
        update_post_meta($page_id, '_lswg_data', $data);
        update_post_meta($page_id, '_lswg_used_openai', !empty($data['used_openai']) ? '1' : '0');

        wp_send_json_success([
            'url' => get_permalink($page_id),
            'used_openai' => !empty($data['used_openai'])
        ]);
    }

    /* ---------------------------------------------------------
     * GENERATE
     * --------------------------------------------------------- */

    public function ajax_generate() {

        check_ajax_referer('lswg_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error([
                'message' => 'Permission denied.'
            ]);
        }

        $city = isset($_POST['city'])
            ? sanitize_text_field(wp_unslash($_POST['city']))
            : '';

        $service = isset($_POST['service'])
            ? sanitize_text_field(wp_unslash($_POST['service']))
            : '';

        $keywords = isset($_POST['keywords'])
            ? sanitize_text_field(wp_unslash($_POST['keywords']))
            : '';

        if (!$city || !$service) {
            wp_send_json_error([
                'message' => 'Please enter both city and service.'
            ]);
        }

        /*
         * Collect public information.
         */
        $data = $this->collect_local_data($city, $service);

        $website = $data;
        $website['city']          = $city;
        $website['service']       = $service;
        $website['keywords']      = $keywords;
        $website['business_name'] = 'Professional ' . ucwords($service) . ' in ' . $city;
        $website['generated']     = current_time('mysql');

        update_option($this->option_key, $website);

        wp_send_json_success([
            'html' => $this->render_preview($website),
            'used_openai' => !empty($website['used_openai'])
        ]);
    }

    /* ---------------------------------------------------------
     * COLLECT INFORMATION
     * --------------------------------------------------------- */

    public function collect_local_data($city, $service) {
        $city = ucwords($city);
        $service = ucwords($service);
        
        $rng = new LSWG_Seeded_Random($city . '-' . $service);

        // Dynamic address mapping matching user's selected city from City Database option
        $address = "314 Complex, 15/20-Vijay Plot, Gondal Road, " . $city . " - 360002.";
        $cities_db = get_option('lswg_city_database', []);
        foreach ($cities_db as $item) {
            if (stripos($city, $item['city']) !== false || stripos($item['city'], $city) !== false) {
                $address = $item['address'];
                break;
            }
        }

        // Retrieve dynamic local fallback templates
        $fallback_data = $this->get_fallback_content($service, $city, $rng);
        $client_type   = $fallback_data['client_type'];
        $sec1_title    = $fallback_data['sec1_title'];
        $sec1_caption  = $fallback_data['sec1_caption'];
        $sec2_text     = $fallback_data['sec2_text'];
        $sec2_benefits = array_slice($rng->shuffle($fallback_data['sec2_benefits']), 0, 4);
        $sec4_features = array_slice($rng->shuffle($fallback_data['sec4_features']), 0, 4);
        $sec5_cta_text = $fallback_data['sec5_cta_text'];

        // Default Case Study, Advantages, and Tailored Solutions
        $case_study_title = "Case Study: Helping a Local " . $service . " Client in " . $city . " Improve Local Search Visibility";
        $case_study_challenge = "The client struggled with low local search visibility, weak traffic, and poor lead conversion rates.";
        $case_study_solution = "We designed a custom landing page optimized for " . $city . ", deployed localized content, and established robust conversion tracking.";
        $case_study_results = "Organic visibility grew by 142% and monthly localized customer leads jumped by 85% within 90 days.";

        $tailored_solutions = [
            ['title' => 'Tailored Strategies', 'desc' => 'Custom campaigns built specifically for your local client profile.'],
            ['title' => 'Data-Driven Results', 'desc' => 'Decisions backed by precise local traffic and click analytics.'],
            ['title' => 'Dedicated Support', 'desc' => 'A direct account manager to answer questions and adjust details.'],
            ['title' => 'Proven Track Record', 'desc' => 'Years of experience scaling local service provider conversions.']
        ];

        $tab_1_title = "Tailored Solutions";
        $tab_1_desc = "We build customized SEO campaigns and high-converting pages designed specifically for your local audience, service type, and competitive landscape.";
        $tab_2_title = "Proven Track Record";
        $tab_2_desc = "Our history of successful campaigns for service providers proves we focus on tangible business growth: more phone calls, bookings, and revenue.";
        $tab_3_title = "Dedicated Support";
        $tab_3_desc = "You will partner with a dedicated specialist who knows your project details inside out. We provide transparent reports and responsive communication.";
        $tab_4_title = "Data-Driven Results";
        $tab_4_desc = "We continually refine your landing pages based on actual user tracking data, ensuring you get the absolute highest conversion rate at the lowest cost.";

        // Section 2: Online Presence/Benefits (6-10 words title, 70-80 words text)
        $sec2_title = "Creating a Strong Online Presence for " . $service . " in " . $city;

        // Check if OpenAI Key is configured
        $api_key = get_option('lswg_openai_key', '');
        $used_openai = false;

        if (!empty($api_key)) {
            $prompt = "You are a local SEO content writer. Generate high-converting, fully customized landing page content for a local service: '{$service}' in the city: '{$city}'.
            
            CRITICAL REQUIREMENT: To make the page highly relevant, you MUST naturally and organically include at least 1 or 2 real prominent landmarks, major street names, or well-known neighborhood names corresponding to '{$city}' (e.g. C.G. Road, SG Highway, or Navrangpura for Ahmedabad; Alkapuri or Gotri for Vadodara; Piplod, Ghod Dod Road, or Adajan for Surat; Yagnik Road, Kalawad Road, or Gondal Road for Rajkot; Bandra, Andheri, or Colaba for Mumbai; Connaught Place or Karol Bagh for Delhi, etc.) in the 'sec1_caption' or 'sec2_text'.

            Ensure the text has highly creative, original phrasing and absolute variety to avoid search engine duplicate content penalties when generating for similar services in different cities. Avoid robotic templates.
            
            Respond with ONLY a valid raw JSON object matching this schema:
            {
              \"sec1_title\": \"Main heading, must include service and city name, optimized for search engines (e.g., Best Plumber in Rajkot: 24/7 Repairs)\",
              \"sec1_caption\": \"A detailed intro paragraph of 70-80 words introducing the service, licensing, community trust, local landmark references, and upfront quotes.\",
              \"sec2_title\": \"A heading for why local expertise matters for {$service} in {$city} (e.g., Creating a Strong Online Presence for Plumber in Rajkot)\",
              \"sec2_text\": \"A body paragraph of 70-80 words explaining why hiring a local professional {$service} in {$city} is crucial, referencing local streets/neighborhoods.\",
              \"sec2_benefits\": [
                {\"icon\": \"\uD83D\uDD27\", \"title\": \"Benefit 1 title (e.g. Certified Experts)\", \"desc\": \"Benefit 1 description\"},
                {\"icon\": \"\u2B50\", \"title\": \"Benefit 2 title\", \"desc\": \"Benefit 2 description\"},
                {\"icon\": \"\uD83D\uDCB3\", \"title\": \"Benefit 3 title\", \"desc\": \"Benefit 3 description\"},
                {\"icon\": \"\u23F1\", \"title\": \"Benefit 4 title\", \"desc\": \"Benefit 4 description\"}
              ],
              \"sec4_features\": [
                \"Feature highlight 1 (e.g., 100% Satisfaction Guarantee)\",
                \"Feature highlight 2\",
                \"Feature highlight 3\",
                \"Feature highlight 4\"
              ],
              \"sec5_cta_text\": \"High-converting CTA body text of 20-30 words prompting user to call or request a callback.\",
              \"case_study_title\": \"Engaging case study title for {$service} in {$city} (e.g. Case Study: Helping an Atlanta Attorney Client Improve Search Visibility)\",
              \"case_study_challenge\": \"1-sentence challenge faced by the client\",
              \"case_study_solution\": \"1-sentence solution we implemented\",
              \"case_study_results\": \"1-sentence results with numeric proof\",
              \"tailored_solutions\": [
                {\"title\": \"Tailored Strategies\", \"desc\": \"1-sentence description\"},
                {\"title\": \"Data-Driven Results\", \"desc\": \"1-sentence description\"},
                {\"title\": \"Dedicated Support\", \"desc\": \"1-sentence description\"},
                {\"title\": \"Proven Track Record\", \"desc\": \"1-sentence description\"}
              ],
              \"tab_1_title\": \"Title for tab 1 (e.g. Custom Campaigns)\",
              \"tab_1_desc\": \"1-sentence explanation of tab 1 advantages\",
              \"tab_2_title\": \"Title for tab 2\",
              \"tab_2_desc\": \"1-sentence explanation of tab 2 advantages\",
              \"tab_3_title\": \"Title for tab 3\",
              \"tab_3_desc\": \"1-sentence explanation of tab 3 advantages\",
              \"tab_4_title\": \"Title for tab 4\",
              \"tab_4_desc\": \"1-sentence explanation of tab 4 advantages\"
            }";

            $response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
                'headers' => [
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type' => 'application/json'
                ],
                'body' => json_encode([
                    'model' => 'gpt-4o-mini',
                    'messages' => [
                        ['role' => 'system', 'content' => 'You only output valid raw JSON.'],
                        ['role' => 'user', 'content' => $prompt]
                    ],
                    'response_format' => ['type' => 'json_object'],
                    'max_tokens' => 800,
                    'temperature' => 0.85
                ]),
                'timeout' => 15
            ]);

            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                $body = wp_remote_retrieve_body($response);
                $json_data = json_decode($body, true);
                
                if (!empty($json_data['choices'][0]['message']['content'])) {
                    $content_json = json_decode($json_data['choices'][0]['message']['content'], true);
                    if ($content_json) {
                        $sec1_title = !empty($content_json['sec1_title']) ? sanitize_text_field($content_json['sec1_title']) : $sec1_title;
                        $sec1_caption = !empty($content_json['sec1_caption']) ? sanitize_textarea_field($content_json['sec1_caption']) : $sec1_caption;
                        $sec2_title = !empty($content_json['sec2_title']) ? sanitize_text_field($content_json['sec2_title']) : $sec2_title;
                        $sec2_text = !empty($content_json['sec2_text']) ? sanitize_textarea_field($content_json['sec2_text']) : $sec2_text;
                        
                        if (!empty($content_json['sec2_benefits']) && is_array($content_json['sec2_benefits'])) {
                            $sec2_benefits = [];
                            foreach ($content_json['sec2_benefits'] as $b) {
                                $sec2_benefits[] = [
                                    'icon' => !empty($b['icon']) ? sanitize_text_field($b['icon']) : '✦',
                                    'title' => !empty($b['title']) ? sanitize_text_field($b['title']) : '',
                                    'desc' => !empty($b['desc']) ? sanitize_text_field($b['desc']) : ''
                                ];
                            }
                        }
                        
                        if (!empty($content_json['sec4_features']) && is_array($content_json['sec4_features'])) {
                            $sec4_features = array_map('sanitize_text_field', $content_json['sec4_features']);
                        }
                        
                        $sec5_cta_text = !empty($content_json['sec5_cta_text']) ? sanitize_textarea_field($content_json['sec5_cta_text']) : $sec5_cta_text;
                        
                        // Parse new fields
                        $case_study_title = !empty($content_json['case_study_title']) ? sanitize_text_field($content_json['case_study_title']) : $case_study_title;
                        $case_study_challenge = !empty($content_json['case_study_challenge']) ? sanitize_textarea_field($content_json['case_study_challenge']) : $case_study_challenge;
                        $case_study_solution = !empty($content_json['case_study_solution']) ? sanitize_textarea_field($content_json['case_study_solution']) : $case_study_solution;
                        $case_study_results = !empty($content_json['case_study_results']) ? sanitize_textarea_field($content_json['case_study_results']) : $case_study_results;
                        
                        if (!empty($content_json['tailored_solutions']) && is_array($content_json['tailored_solutions'])) {
                            $tailored_solutions = [];
                            foreach ($content_json['tailored_solutions'] as $ts) {
                                $tailored_solutions[] = [
                                    'title' => !empty($ts['title']) ? sanitize_text_field($ts['title']) : '',
                                    'desc' => !empty($ts['desc']) ? sanitize_text_field($ts['desc']) : ''
                                ];
                            }
                        }
                        
                        $tab_1_title = !empty($content_json['tab_1_title']) ? sanitize_text_field($content_json['tab_1_title']) : $tab_1_title;
                        $tab_1_desc = !empty($content_json['tab_1_desc']) ? sanitize_textarea_field($content_json['tab_1_desc']) : $tab_1_desc;
                        $tab_2_title = !empty($content_json['tab_2_title']) ? sanitize_text_field($content_json['tab_2_title']) : $tab_2_title;
                        $tab_2_desc = !empty($content_json['tab_2_desc']) ? sanitize_textarea_field($content_json['tab_2_desc']) : $tab_2_desc;
                        $tab_3_title = !empty($content_json['tab_3_title']) ? sanitize_text_field($content_json['tab_3_title']) : $tab_3_title;
                        $tab_3_desc = !empty($content_json['tab_3_desc']) ? sanitize_textarea_field($content_json['tab_3_desc']) : $tab_3_desc;
                        $tab_4_title = !empty($content_json['tab_4_title']) ? sanitize_text_field($content_json['tab_4_title']) : $tab_4_title;
                        $tab_4_desc = !empty($content_json['tab_4_desc']) ? sanitize_textarea_field($content_json['tab_4_desc']) : $tab_4_desc;
                        
                        $used_openai = true;
                    }
                }
            }
        }

        // Section 3: Services list of 6 sub-services
        $sec3_title = "Services of " . $service . " for " . $client_type . " in " . $city;
        $sub_services_data = $rng->shuffle($this->get_sub_services($service));

        // Section 4: Why Choose Us
        $sec4_title = "Why Choose Us as Your " . $service . " Partner?";

        // Section 5: CTA
        $sec5_cta_title = "Ready to get started?";

        // Realistic stock photos
        $realistic = $this->get_realistic_images($service, $city);
        $shuffled_imgs = $rng->shuffle($realistic);
        while (count($shuffled_imgs) < 3) {
            $shuffled_imgs = array_merge($shuffled_imgs, $shuffled_imgs);
        }
        $images = [$shuffled_imgs[0], $shuffled_imgs[1], $shuffled_imgs[2]];

        // Suburbs/Locations
        $locations = [
            $city, "North " . $city, "South " . $city, "East " . $city, "West " . $city, 
            $city . " Heights", $city . " Valley", $city . " Plaza", $city . " District", 
            $city . " Suburbs", "Central " . $city, "Downtown " . $city, $city . " Gardens", 
            $city . " Park", $city . " Hills", $city . " Ridge", $city . " Lakes", 
            $city . " Springs", $city . " Junction", $city . " View"
        ];

        // Dynamic Portfolio mockup images matching selected service type
        $portfolio_mockups = $rng->shuffle($this->get_realistic_portfolio($service));

        // Testimonials
        $authors_1 = ['Sarah Jenkins', 'Aarav Patel', 'Neha Sharma', 'John Doe', 'Priya Shah', 'Rohan Mehta'];
        $authors_2 = ['Michael Chang', 'Rajesh Mehta', 'David Smith', 'Vikram Singh', 'Anya Patel', 'Devendra Patel'];
        $authors_3 = ['Emma Watson', 'Priya Patel', 'Siddharth Rao', 'Lisa Anderson', 'Karan Johar', 'Sunita Rao'];
        
        $testimonials = [
            [
                'quote' => "Outstanding experience! The team solved our {$service} issue here in {$city} exactly as requested. Their pricing was completely transparent. Highly recommended!",
                'author' => $rng->pick($authors_1) . ", Local Client"
            ],
            [
                'quote' => "Very professional {$service} team in {$city}. They showed up on time, used high-quality tools, and cleaned up everything afterward. Fantastic service!",
                'author' => $rng->pick($authors_2) . ", Property Manager"
            ],
            [
                'quote' => "Unbelievable response time for our emergency {$service} repair request in {$city}. They resolved our issue in less than an hour. Truly life savers!",
                'author' => $rng->pick($authors_3) . ", Business Owner"
            ]
        ];
        $testimonials = $rng->shuffle($testimonials);

        return [
            'sec1_title'        => $sec1_title,
            'sec1_caption'      => $sec1_caption,
            'sec2_title'        => $sec2_title,
            'sec2_text'         => $sec2_text,
            'sec2_benefits'     => $sec2_benefits,
            'sec3_title'        => $sec3_title,
            'sec3_services'     => $sub_services_data,
            'sec4_title'        => $sec4_title,
            'sec4_features'     => $sec4_features,
            'sec5_cta_title'    => $sec5_cta_title,
            'sec5_cta_text'     => $sec5_cta_text,
            'images'            => $images,
            'locations'         => $locations,
            'portfolio'         => $portfolio_mockups,
            'testimonials'      => $testimonials,
            'address'           => $address,
            'used_openai'       => $used_openai,

            // New fields
            'case_study_title' => $case_study_title,
            'case_study_challenge' => $case_study_challenge,
            'case_study_solution' => $case_study_solution,
            'case_study_results' => $case_study_results,
            'tailored_solutions' => $tailored_solutions,
            'tab_1_title' => $tab_1_title,
            'tab_1_desc' => $tab_1_desc,
            'tab_2_title' => $tab_2_title,
            'tab_2_desc' => $tab_2_desc,
            'tab_3_title' => $tab_3_title,
            'tab_3_desc' => $tab_3_desc,
            'tab_4_title' => $tab_4_title,
            'tab_4_desc' => $tab_4_desc
        ];
    }

    private function get_fallback_content($service, $city, $rng) {
        $city_cap = ucwords($city);
        $service_cap = ucwords($service);
        $service_lower = strtolower($service);

        // Define dynamic sentence variations based on service category
        $is_plumber = (stripos($service, 'plumber') !== false || stripos($service, 'leak') !== false || stripos($service, 'drain') !== false);
        $is_electrician = (stripos($service, 'electr') !== false || stripos($service, 'wire') !== false);
        $is_tailor = (stripos($service, 'tailor') !== false || stripos($service, 'sew') !== false || stripos($service, 'cloth') !== false);
        $is_dentist = (stripos($service, 'dentist') !== false || stripos($service, 'dental') !== false || stripos($service, 'doctor') !== false);
        $is_cleaning = (stripos($service, 'clean') !== false || stripos($service, 'maid') !== false);
        $is_marketing = (stripos($service, 'marketing') !== false || stripos($service, 'seo') !== false || stripos($service, 'agency') !== false || stripos($service, 'brand') !== false);
        $is_mechanic = (stripos($service, 'mechanic') !== false || stripos($service, 'auto') !== false || stripos($service, 'car') !== false);

        if ($is_plumber) {
            $client_type = "Homeowners and Properties";
            
            // Hero Title Variation
            $t1 = $rng->pick(["Best", "Top-Rated", "Reliable", "Expert", "Premium"]);
            $t2 = $rng->pick(["Plumber", "Plumbing Services", "Plumbing Experts", "Emergency Plumbers"]);
            $t3 = "in " . $city_cap;
            $t4 = $rng->pick([": 24/7 Leak & Drain Repairs", ": Emergency Plumbing & Repairs", ": Fast Leak Detection & Fixes", ": Residential & Commercial Experts"]);
            $sec1_title = "{$t1} {$t2} {$t3}{$t4}";

            // Hero Intro Caption (4 sentence pools)
            $cap1 = $rng->pick([
                "Struggling with a plumbing emergency or need the best plumber in {$city_cap} immediately?",
                "Looking for a highly professional and trustworthy plumber in {$city_cap} for your home or office?",
                "For the most dependable plumbing repairs and local leak detection in {$city_cap}, trust our expert crew.",
                "When plumbing issues strike your property in {$city_cap}, you need a reliable local specialist who responds fast."
            ]);
            $cap2 = $rng->pick([
                "Our certified team of local plumbing specialists in {$city_cap} is ready to deliver top-rated residential and commercial repairs.",
                "We provide comprehensive 24/7 leak repairs, water heater fixes, and certified block drain clearing across the local community.",
                "Our master plumbers offer same-day installations, professional faucet repair, and complete sewer line inspection.",
                "We serve local homeowners and commercial premises with high-grade tools, copper piping, and compliant safety standards."
            ]);
            $cap3 = $rng->pick([
                "We specialize in emergency plumber near me in {$city_cap}, ensuring rapid dispatch for burst pipes and hot water system issues.",
                "Whether you have a minor faucet drip or need emergency drain pipe replacement, count on us for rapid support.",
                "Our safety-certified technicians handle emergency leak detection, toilet installs, and major pipe upgrades.",
                "From preventative maintenance audits to sudden clogging issues, our dispatcher is available 24 hours a day."
            ]);
            $cap4 = $rng->pick([
                "Partner with the leading local plumbing services for upfront flat-rate pricing, certified diagnostics, and guaranteed work today!",
                "We offer transparent fixed estimates with zero hidden fees, fast response times, and premium-grade replacement parts.",
                "Enjoy punctual scheduling, flat-rate pricing, and a 100% satisfaction warranty on all plumbing services.",
                "Call {$city_cap}'s premier plumbing experts today for a free upfront quote and same-day priority service."
            ]);
            $sec1_caption = "{$cap1} {$cap2} {$cap3} {$cap4}";

            // Description Body (3 sentence pools)
            $body1 = $rng->pick([
                "Getting affordable plumbing repair in {$city_cap} is now easier than ever.",
                "Our local plumbing team handles residential and commercial projects of all sizes in {$city_cap}.",
                "We are proud to serve homes and businesses across {$city_cap} with high-quality plumbing support.",
                "Our plumbing service covers all neighborhoods in {$city_cap}, bringing master technicians to your doorstep."
            ]);
            $body2 = $rng->pick([
                "We specialize in hot water system upgrades, toilet replacements, and thermal camera leak inspections.",
                "Our local plumbers use high-grade copper lines, durable valves, and premium fixtures to deliver leak-proof results.",
                "We handle everything from minor faucet adjustments to complex sewer replacements and water pressure corrections.",
                "Our technicians utilize state-of-the-art diagnostic tools to locate hidden pipe leaks without damaging your walls."
            ]);
            $body3 = $rng->pick([
                "All our plumbing work is fully insured and complies strictly with local safety standards.",
                "Whether it's a minor repair or a complete repiping job, we guarantee a flawless and long-lasting finish.",
                "We ensure your fixtures run perfectly, clean up thoroughly after the job, and offer upfront fixed costing.",
                "Rely on the leading local plumbing experts for punctual visits, honest diagnostics, and flat-rate quotes."
            ]);
            $sec2_text = "{$body1} {$body2} {$body3}";

            $sec2_benefits = [
                ['icon' => '🔧', 'title' => 'Licensed Plumbers', 'desc' => 'Fully certified and background-checked technicians.'],
                ['icon' => '⭐', 'title' => 'Guaranteed Repair', 'desc' => 'We ensure permanent solutions to leaks and blocks.'],
                ['icon' => '💳', 'title' => 'Clear Estimates', 'desc' => 'Transparent upfront pricing with zero hidden fees.'],
                ['icon' => '⏱', 'title' => '24/7 Response', 'desc' => 'Rapid response times for any plumbing emergencies.'],
                ['icon' => '🔍', 'title' => 'Advanced Gear', 'desc' => 'Using thermal cameras and digital pressure tests.'],
                ['icon' => '🛡', 'title' => 'Fully Insured', 'desc' => 'Complete liability protection for your property safety.']
            ];

            $sec4_features = [
                "Master Licensed Plumbers", "Emergency 24/7 Dispatch", "Premium Pipe & Valve Fittings", 
                "100% Leak-Free Guarantee", "Thermal Leak Inspection", "Same-Day Installations", 
                "Eco-Friendly Plumbing Parts"
            ];

            $sec5_cta_text = $rng->pick([
                "We are serving properties across {$city_cap} with expert plumbing and leak repair solutions. Call the best plumber in {$city_cap} now for emergency dispatch.",
                "Get professional plumbing assistance at your {$city_cap} home or office. Click the button to speak with a dispatcher immediately.",
                "Ready to fix your plumbing issues? Contact {$city_cap}'s top-rated plumbing experts now to request service.",
                "Don't let leaks or blocks disrupt your day. Call {$city_cap}'s trusted local plumbers now for same-day service."
            ]);

        } elseif ($is_electrician) {
            $client_type = "Homes and Commercial Spaces";

            // Hero Title Variation
            $t1 = $rng->pick(["Best", "Certified", "Top-Rated", "Expert", "Reliable"]);
            $t2 = $rng->pick(["Electrician", "Electrical Services", "Electrical Contractors", "Emergency Electricians"]);
            $t3 = "in " . $city_cap;
            $t4 = $rng->pick([": Wiring & Panel Upgrades", ": 24/7 Repairs & Installations", ": Safe & Reliable Power Fixes", ": Residential & Commercial Experts"]);
            $sec1_title = "{$t1} {$t2} {$t3}{$t4}";

            // Hero Intro Caption
            $cap1 = $rng->pick([
                "Searching for a certified electrician in {$city_cap} to handle a power issue or upgrade your wiring?",
                "Need professional and safe electrical services in {$city_cap} for your residential or commercial property?",
                "For the most reliable electrical repairs and panel installations in {$city_cap}, trust our master technicians.",
                "If you have a sudden electrical hazard or power failure in {$city_cap}, our team is ready to assist."
            ]);
            $cap2 = $rng->pick([
                "Our licensed local electrical experts in {$city_cap} provide complete rewiring, LED installations, and breaker diagnostics.",
                "We deliver safe, code-compliant troubleshooting, circuit upgrades, and professional outlet fittings.",
                "Our crew handles emergency power recovery, smart home setups, and regular safety inspections.",
                "We serve local properties with premium materials, copper cabling, and upfront flat-rate billing."
            ]);
            $cap3 = $rng->pick([
                "We specialize in emergency electrician near me in {$city_cap} to handle sudden outages and hazardous wiring problems.",
                "Whether you need a simple switch replacement or a full building electrical redesign, we ensure top-tier safety.",
                "Our safety-certified technicians handle EV charger setups, surge protection, and complete safety audits.",
                "From fuse box repairs to industrial panel fittings, our dispatchers are ready to send assistance."
            ]);
            $cap4 = $rng->pick([
                "Hire our certified team for transparent billing, strict safety standards, and guaranteed satisfaction!",
                "Enjoy peace of mind with our lifetime workmanship warranty, clear fixed quotes, and fast support response.",
                "Contact {$city_cap}'s premier electrical team today for a free estimate and same-day scheduling.",
                "Call us now to discuss your electrical project or request an immediate emergency dispatcher."
            ]);
            $sec1_caption = "{$cap1} {$cap2} {$cap3} {$cap4}";

            // Description Body
            $body1 = $rng->pick([
                "Securing high-quality electrical work in {$city_cap} is simple with our professional team.",
                "Our electrical contractors manage residential and commercial projects of all scales in {$city_cap}.",
                "We are dedicated to keeping homes and offices safe across {$city_cap} with premium electrical maintenance.",
                "Our service network covers every neighborhood in {$city_cap}, bringing certified help directly to you."
            ]);
            $body2 = $rng->pick([
                "We specialize in modern switchboard upgrades, diagnostic fault-finding, and indoor lighting layouts.",
                "Our electricians use heavy-duty copper lines, certified switches, and high-efficiency fixtures.",
                "We manage everything from simple home outlet fixes to complex commercial electrical contracting.",
                "Our team uses advanced testing meters to ensure all your circuits are safely loaded and grounded."
            ]);
            $body3 = $rng->pick([
                "We operate strictly under local electrical codes to ensure your property remains safe and compliant.",
                "Every project is backed by a full safety warranty and completed with clean, professional craftsmanship.",
                "We guarantee transparent pricing, honest recommendations, and zero hidden fees on every invoice.",
                "Trust us to keep your systems running efficiently and safely with flat-rate quotes."
            ]);
            $sec2_text = "{$body1} {$body2} {$body3}";

            $sec2_benefits = [
                ['icon' => '⚡', 'title' => 'Safety Certified', 'desc' => 'Fully licensed electricians adhering to strict safety codes.'],
                ['icon' => '⭐', 'title' => 'Premium Wiring', 'desc' => 'Using heavy-duty, long-lasting copper wires and fixtures.'],
                ['icon' => '💳', 'title' => 'Flat-Rate Pricing', 'desc' => 'No surprise fees on diagnostics and electrical setups.'],
                ['icon' => '⏱', 'title' => 'Emergency Service', 'desc' => 'Rapid dispatch for power outages and electrical hazards.'],
                ['icon' => '🛡', 'title' => 'Licensed Crew', 'desc' => 'Expert technicians with complete code compliance.'],
                ['icon' => '🔍', 'title' => 'Diagnostics', 'desc' => 'Thorough scans to find safety faults.']
            ];

            $sec4_features = [
                "Fully Licensed & Insured", "24/7 Hazard Assistance", "Accurate Fault Diagnostics", 
                "Lifetime Workmanship Warranty", "Code Compliance Guaranteed", "Modern Switchboard Upgrades",
                "Certified Home Safety Audits"
            ];

            $sec5_cta_text = $rng->pick([
                "We are keeping homes and commercial offices safe across {$city_cap} with reliable electrical solutions. Contact the best electrician in {$city_cap} today.",
                "Restore safety and power to your electrical systems. Call {$city_cap}'s certified electricians for immediate support.",
                "Ready to upgrade your home wiring or panel? Call the best electricians in {$city_cap} to book your project.",
                "Don't take risks with faulty electrical circuits. Call {$city_cap}'s leading electrical specialists now for safe service."
            ]);

        } elseif ($is_tailor) {
            $client_type = "Men, Women, and Fashion Designers";

            // Hero Title Variation
            $t1 = $rng->pick(["Best", "Premium", "Bespoke", "Top-Rated", "Custom"]);
            $t2 = $rng->pick(["Tailor", "Tailoring Boutique", "Alterations Shop", "Fashion Tailors"]);
            $t3 = "in " . $city_cap;
            $t4 = $rng->pick([": Custom Suits & Alterations", ": Bespoke Gowns & Resizing", ": Perfect Fit Clothing Services", ": Master Dress & Suit Adjustments"]);
            $sec1_title = "{$t1} {$t2} {$t3}{$t4}";

            // Hero Intro Caption
            $cap1 = $rng->pick([
                "Searching for the best tailor in {$city_cap} to customize your wardrobe or alter a favorite outfit?",
                "Looking for precise bespoke tailoring or wedding dress alterations in {$city_cap}?",
                "For master suit alterations and daily clothing repairs in {$city_cap}, visit our professional studio.",
                "Want your clothes to fit your body type perfectly? Our master tailors in {$city_cap} are here to help."
            ]);
            $cap2 = $rng->pick([
                "Our local tailoring boutique in {$city_cap} specializes in custom suits, formal gowns, and daily alterations.",
                "We provide the finest alterations near me in {$city_cap} with detailed fitting sessions and custom stitching.",
                "Our skilled team offers bridal adjustments, suit tapering, custom pocket additions, and lining repairs.",
                "We work with luxury Italian fabrics, fine cottons, pure silks, and heavy denims or leathers."
            ]);
            $cap3 = $rng->pick([
                "We specialize in bridal wear adjustments and bespoke dressmaking, creating flattering silhouettes for your special day.",
                "Whether you need simple trouser hems or a complete redesign of a designer garment, we ensure flawless results.",
                "Our master craftsmen combine traditional sewing techniques with modern patterns for comfort and style.",
                "From custom suit adjustments to daily garment care, we focus on every detail and stitch."
            ]);
            $cap4 = $rng->pick([
                "Get custom clothing tailored to your unique measurements at {$city_cap}'s premier tailoring studio today!",
                "We offer transparent pricing on alterations, quick turnaround times, and a perfect fit guarantee.",
                "Call us or book an appointment online to schedule a custom fitting session with our friendly team.",
                "Bring your fabrics to our studio today for a free design consultation and clear upfront quote."
            ]);
            $sec1_caption = "{$cap1} {$cap2} {$cap3} {$cap4}";

            // Description Body
            $body1 = $rng->pick([
                "Experiencing premium custom dressmaking and resizing in {$city_cap} has never been more convenient.",
                "Our master seamstresses serve clients across {$city_cap} with high-detail clothing repairs.",
                "We are dedicated to providing the highest quality garment adjustments in the {$city_cap} area.",
                "Our boutique alters and designs clothing for men, women, and children throughout {$city_cap}."
            ]);
            $body2 = $rng->pick([
                "We specialize in custom wedding gown adjustments, formal wear alterations, and curtain hemming.",
                "Our tailors use color-matched threads, ultra-thin needles, and heavy-duty sewing machinery.",
                "We handle everything from simple denim repairs to complex lining replacements for coats and blazers.",
                "We focus on retaining the original garment design and stitch pattern during alterations."
            ]);
            $body3 = $rng->pick([
                "Every adjustment is done with precision to ensure your clothes feel comfortable and look stunning.",
                "We guarantee express turnaround times for wedding parties and urgent alterations.",
                "Enjoy fair pricing, high-quality finishes, and helpful consultations on all bespoke designs.",
                "Trust {$city_cap}'s leading tailoring experts to give your favorite wardrobe pieces a new lease on life."
            ]);
            $sec2_text = "{$body1} {$body2} {$body3}";

            $sec2_benefits = [
                ['icon' => '🧵', 'title' => 'Master Tailors', 'desc' => 'Decades of experience in pattern-making and fine sewing.'],
                ['icon' => '⭐', 'title' => 'Perfect Fit', 'desc' => 'Precise custom measurements to ensure flattering silhouettes.'],
                ['icon' => '💳', 'title' => 'Affordable Fittings', 'desc' => 'Transparent prices on alterations, hems, and custom designs.'],
                ['icon' => '⏱', 'title' => 'Fast Turnaround', 'desc' => 'On-time delivery for wedding suits and alterations.'],
                ['icon' => '🎨', 'title' => 'Bespoke Styles', 'desc' => 'Individualized designs styled from scratch to stitch.'],
                ['icon' => '✨', 'title' => 'Luxury Fabrics', 'desc' => 'Access to fine Italian wool blends and pure silk.']
            ];

            $sec4_features = [
                "Bespoke Tailoring Experts", "Premium Threads & Textiles", "Perfect Fit Guarantee", 
                "Alterations for All Garments", "Luxury Fabric Selections", "Bridal Wear Specialists", 
                "Handcrafted Embroidery"
            ];

            $sec5_cta_text = $rng->pick([
                "Bring your fabrics or garments to our boutique studio in {$city_cap} for custom alterations and tailor-made outfits. Call the best tailor in {$city_cap} to schedule.",
                "Make a lasting impression at your next event. Call the finest tailor in {$city_cap} to book your custom fitting appointment.",
                "Give your favorite clothes a new lease of life. Visit {$city_cap}'s alteration experts today or call for details.",
                "Ready to design a suit or dress that fits like a glove? Call the premier {$city_cap} tailoring boutique today."
            ]);

        } elseif ($is_dentist) {
            $client_type = "Patients and Families";

            // Hero Title Variation
            $t1 = $rng->pick(["Best", "Top-Rated", "Modern", "Family", "Premium"]);
            $t2 = $rng->pick(["Dentist", "Dental Clinic", "Dental Care Center", "Cosmetic Dentistry"]);
            $t3 = "in " . $city_cap;
            $t4 = $rng->pick([": Pain-Free Treatments & Whitening", ": Family Dental Checkups & Implants", ": Expert Smile Makeovers & Care", ": Gentle Dentistry & Implants"]);
            $sec1_title = "{$t1} {$t2} {$t3}{$t4}";

            // Hero Intro Caption
            $cap1 = $rng->pick([
                "Looking for the best dentist in {$city_cap} for a regular checkup or a complete smile makeover?",
                "Need a trusted and modern dental clinic in {$city_cap} for your family's oral hygiene and dental care?",
                "For pain-free root canals, implants, and teeth cleaning in {$city_cap}, schedule an appointment today.",
                "Struggling with a toothache or want cosmetic teeth whitening from a certified dentist in {$city_cap}?"
            ]);
            $cap2 = $rng->pick([
                "Our state-of-the-art dental clinic in {$city_cap} offers family checkups, crowns, veneers, and oral surgeries.",
                "We provide professional dental cleaning near me in {$city_cap} using sterile, advanced diagnostic equipment.",
                "Our gentle dentists specialize in cosmetic makeovers, dental implants, and pediatric dental care.",
                "We deliver comfortable procedures with advanced sedation options and clean, modern clinic standards."
            ]);
            $cap3 = $rng->pick([
                "We offer same-day appointments for dental emergencies, ensuring rapid relief from sudden tooth pain.",
                "Whether you need preventive scaling or a custom porcelain crown, we prioritize your comfort and safety.",
                "Our safety-certified dental surgeons use low-radiation digital X-rays and sterile checkup tools.",
                "From gentle teeth cleaning for children to advanced restorative implants, we cover all procedures."
            ]);
            $cap4 = $rng->pick([
                "Contact {$city_cap}'s top dental clinic today for a healthy, radiant smile and flexible payment plans!",
                "We accept major health insurances, offer interest-free EMI options, and ensure a worry-free visit.",
                "Call our friendly reception desk now to book your dental checkup or emergency consultation.",
                "Enjoy pain-free dental care from the most trusted dentists in {$city_cap}. Reserve your slot today!"
            ]);
            $sec1_caption = "{$cap1} {$cap2} {$cap3} {$cap4}";

            // Description Body
            $body1 = $rng->pick([
                "Finding high-quality family dentistry in {$city_cap} is simple at our modern dental center.",
                "Our dental specialists provide comprehensive care for patients of all ages in {$city_cap}.",
                "We are dedicated to maintaining the dental health and smiles of the {$city_cap} community.",
                "Our clinical network brings top-tier cosmetic and general dentistry directly to {$city_cap} residents."
            ]);
            $body2 = $rng->pick([
                "We specialize in custom porcelain veneers, safe tooth extractions, and invisible braces.",
                "Our hygienists use low-radiation digital scans, sterile diagnostic tools, and gentle lasers.",
                "We handle everything from simple teeth cleaning to complex multi-implant surgeries.",
                "We design personalized cosmetic smile makeovers to match your natural facial structure."
            ]);
            $body3 = $rng->pick([
                "All checkups adhere strictly to clinical sanitation standards for a safe and sterile environment.",
                "We strive to create a warm, stress-free waiting lounge and dental suite for kids and adults.",
                "Enjoy transparent upfront billing, direct insurance claims, and flexible financing options.",
                "Rely on {$city_cap}'s certified dental experts for gentle care and guaranteed clinical excellence."
            ]);
            $sec2_text = "{$body1} {$body2} {$body3}";

            $sec2_benefits = [
                ['icon' => '🦷', 'title' => 'Certified Dentists', 'desc' => 'Experienced dental surgeons and hygienists.'],
                ['icon' => '⭐', 'title' => 'Sterile Care', 'desc' => 'Following strict sanitation and clinical safety guidelines.'],
                ['icon' => '💳', 'title' => 'Flexible Billing', 'desc' => 'We accept major health insurances and payment plans.'],
                ['icon' => '⏱', 'title' => 'Pain-Free Sedation', 'desc' => 'Advanced sedation and gentle dental procedures.'],
                ['icon' => '🔍', 'title' => 'Modern Tech', 'desc' => 'Low-radiation digital scans and painless lasers.'],
                ['icon' => '🌟', 'title' => 'Veneer Artistry', 'desc' => 'Bespoke veneers for custom natural color matches.']
            ];

            $sec4_features = [
                "Certified Dental Surgeons", "Sterile & Modern Clinic", "Pain-Free Sedation Options", 
                "Emergency Dental Appointments", "Pediatric Dental Experts", "Digital X-Ray Scans", 
                "Direct Insurance Billing"
            ];

            $sec5_cta_text = $rng->pick([
                "We are providing professional dental checkups and cosmetic smile enhancements in {$city_cap}. Contact the best dental clinic in {$city_cap} to book today.",
                "Get a beautiful, healthy smile. Call {$city_cap}'s leading family dentists to reserve your checkup slot.",
                "Take the first step toward your dream smile. Call the best cosmetic dentists in {$city_cap} to book your smile makeover.",
                "Don't neglect your dental health. Call {$city_cap}'s modern clinic now for a pain-free checkup or teeth cleaning."
            ]);

        } elseif ($is_cleaning) {
            $client_type = "Homes, Offices, and Commercial Spaces";

            // Hero Title Variation
            $t1 = $rng->pick(["Best", "Top-Rated", "Vetted", "Professional", "Reliable"]);
            $t2 = $rng->pick(["Cleaning Services", "House Cleaners", "Maid Service", "Janitorial Services"]);
            $t3 = "in " . $city_cap;
            $t4 = $rng->pick([": Spotless Home & Office Cleaning", ": Vetted Housekeepers & Maids", ": Move-In/Out Deep Cleaning", ": Reliable Commercial & Home Care"]);
            $sec1_title = "{$t1} {$t2} {$t3}{$t4}";

            // Hero Intro Caption
            $cap1 = $rng->pick([
                "Searching for the best cleaning services in {$city_cap} to keep your home or office sparkling clean?",
                "Need reliable, background-checked house cleaners or a regular maid service in {$city_cap}?",
                "For move-in/out deep cleaning or after-hours office sanitization in {$city_cap}, trust our vetted crew.",
                "Struggling to find the time for deep house cleaning? Let {$city_cap}'s top-rated housekeeper team handle it."
            ]);
            $cap2 = $rng->pick([
                "Our trained local cleaners in {$city_cap} provide deep home cleaning, office sanitization, and maid service.",
                "We serve local properties with non-toxic, eco-friendly disinfectants that are safe for kids and pets.",
                "Our corporate cleaning agency provides custom sanitation checklists tailored to your building layout.",
                "We deliver high-detail residential housekeeping, window cleaning, and janitorial operations."
            ]);
            $cap3 = $rng->pick([
                "We specialize in deep cleaning near me in {$city_cap}, using electrostatic sprayers and steam vacuums.",
                "Whether you need a one-off deep house clean or recurring weekly office cleaning, we match your checklist.",
                "Our vetted cleaners are fully background-checked, insured, and follow rigorous sanitation checklists.",
                "From landlord inspections to carpet stain extraction, our crews bring heavy-duty equipment."
            ]);
            $cap4 = $rng->pick([
                "Hire the leading cleaning company in {$city_cap} today for flat-rate quotes and a spotless space!",
                "We guarantee your tenancy deposit back with our real-estate standard move-out cleaning.",
                "Call our friendly office today to request a custom cleaning estimate and book your priority crew.",
                "Enjoy a fresh, clean environment today with {$city_cap}'s most thorough cleaning specialists."
            ]);
            $sec1_caption = "{$cap1} {$cap2} {$cap3} {$cap4}";

            // Description Body
            $body1 = $rng->pick([
                "Maintaining a pristine, hygienic building in {$city_cap} is now simple with our vetted crew.",
                "Our cleaning teams service residential homes and commercial offices of all sizes in {$city_cap}.",
                "We are dedicated to providing the highest standards of cleanliness and disinfection across {$city_cap}.",
                "Our service network covers every neighborhood in {$city_cap}, bringing professional maids to your door."
            ]);
            $body2 = $rng->pick([
                "We specialize in bathroom sanitation, oven grease scrubbing, floor polishing, and window cleaning.",
                "Our staff uses eco-friendly, hypoallergenic cleaning solutions and microfiber cloth sets.",
                "We handle everything from simple dust-and-vacuum visits to heavy post-construction cleanups.",
                "Our overnight crews work quiet, after-hours shifts to ensure your morning office feels fresh."
            ]);
            $body3 = $rng->pick([
                "All cleaning staff are fully insured and bonded to give you complete peace of mind.",
                "We ensure all items on your custom cleaning checklist are completed to 100% satisfaction.",
                "Enjoy simple fixed pricing, easy online bookings, and zero hidden surcharge fees.",
                "Rely on {$city_cap}'s premier cleaning services for punctuality, detail, and honest estimates."
            ]);
            $sec2_text = "{$body1} {$body2} {$body3}";

            $sec2_benefits = [
                ['icon' => '🧹', 'title' => 'Vetted Cleaners', 'desc' => 'Fully background-checked, insured, and trained cleaning staff.'],
                ['icon' => '⭐', 'title' => 'Eco Solutions', 'desc' => 'Using non-toxic, pet-safe, and green cleaning solutions.'],
                ['icon' => '💳', 'title' => 'Fixed Pricing', 'desc' => 'Clear billing based on flat rates or hourly checklists.'],
                ['icon' => '⏱', 'title' => 'On-Time Crew', 'desc' => 'Punctual arrivals and efficient, high-standard cleanups.'],
                ['icon' => '🛡', 'title' => 'Fully Insured', 'desc' => 'Complete coverage for property safety and liability.'],
                ['icon' => '✨', 'title' => 'Detail Focused', 'desc' => 'Cleaning behind appliances, baseboards, and cabinet corners.']
            ];

            $sec4_features = [
                "100% Eco-Friendly Supplies", "Fully Insured Cleaning Crew", "Custom Cleaning Checklists", 
                "Punctual & Thorough Service", "Electrostatic Germ Disinfection", "Flexible Monthly Contracts", 
                "Quiet After-Hours Shifts"
            ];

            $sec5_cta_text = $rng->pick([
                "Restore hygiene and sparkling shine to your home or office space in {$city_cap}. Contact the best cleaning services in {$city_cap} to book our vetted crew.",
                "Request a custom office cleaning estimate. Contact the leading commercial janitors in {$city_cap} for packages.",
                "Ensure your property looks brand new. Call the best move-out cleaners in {$city_cap} to book your express crew today.",
                "Ready for a spotless home? Contact {$city_cap}'s premier housekeeper team now to schedule your appointment."
            ]);

        } elseif ($is_marketing) {
            $client_type = "Businesses and Local Brands";

            // Hero Title Variation
            $t1 = $rng->pick(["Best", "Top-Rated", "Expert", "Premium", "Certified"]);
            $t2 = $rng->pick(["Digital Marketing Agency", "SEO Agency", "Marketing Agency", "SEO & PPC Specialists"]);
            $t3 = "in " . $city_cap;
            $t4 = $rng->pick([": Google Rank Page 1 Specialists", ": Grow Your Local Leads & Sales", ": Expert Search Ads & SEO", ": High-Converting Digital Campaigns"]);
            $sec1_title = "{$t1} {$t2} {$t3}{$t4}";

            // Hero Intro Caption
            $cap1 = $rng->pick([
                "Grow your sales and dominate search engine results with the best digital marketing agency in {$city_cap}!",
                "Looking for a certified SEO agency or PPC ad manager in {$city_cap} to scale your online customer lead flow?",
                "For high-authority organic link building, local citation audits, and Google Ads management in {$city_cap}, partner with us.",
                "Want to rank on page 1 of Google Maps and drive buyer traffic to your {$city_cap} local business?"
            ]);
            $cap2 = $rng->pick([
                "We specialize in expert local SEO services, high-converting PPC campaigns, and organic keyword optimization.",
                "Our Google-certified agency structures custom search schemas, builds local directory listings, and writes ad copies.",
                "Our digital marketing specialists manage your advertising budgets, track visitor conversions, and optimize landing pages.",
                "We provide data-driven campaign auditing, competitor keywords analysis, and social media branding maps."
            ]);
            $cap3 = $rng->pick([
                "We focus on bringing your site into the Google Local 3-Pack, driving phone calls and physical store traffic.",
                "Whether you need monthly organic SEO growth or a fast Google Search ad campaign launch, we ensure high ROI.",
                "Our Meta and Google-certified managers run A/B copy tests and build remarketing lists to lower your CPA.",
                "From local business profile optimization to custom lead generation funnels, our team delivers results."
            ]);
            $cap4 = $rng->pick([
                "Partner with the leading digital marketing experts in {$city_cap} today to double your lead flow and ROI!",
                "Enjoy month-to-month marketing packages with zero lock-in contracts and transparent weekly performance reports.",
                "Call our SEO consultant desk today for a free maps audit and custom search keyword plan.",
                "Dominate {$city_cap}'s local market rankings. Contact our digital agency today to outline your plan."
            ]);
            $sec1_caption = "{$cap1} {$cap2} {$cap3} {$cap4}";

            // Description Body
            $body1 = $rng->pick([
                "Scaling your brand visibility and customer capture in {$city_cap} is simple with our ad agency.",
                "Our local marketing agency manages search optimization and PPC spend for brands of all sizes in {$city_cap}.",
                "We are dedicated to helping {$city_cap} business owners dominate Google rankings and convert online leads.",
                "Our local SEO and ad management services cover every business niche across the {$city_cap} community."
            ]);
            $body2 = $rng->pick([
                "We specialize in Google Maps Pack optimization, custom landing page funnels, and ROI conversion tracking.",
                "Our search consultants audit directory citation consistency and write high-converting, keyword-dense articles.",
                "We manage Meta retargeting ads, localized search intent keywords, and Google Analytics conversion goals.",
                "We write persuasive headlines and structure landing pages to convert raw search clicks into closed sales."
            ]);
            $body3 = $rng->pick([
                "All campaigns are run by certified professionals with transparent, real-time return-on-ad-spend tracking.",
                "We provide detailed monthly ranking and traffic reports, so you see exactly where your budget goes.",
                "Enjoy month-to-month contract terms, regular strategy checkpoints, and dedicated project managers.",
                "Trust {$city_cap}'s premier SEO and PPC experts to build a consistent pipeline of inbound client calls."
            ]);
            $sec2_text = "{$body1} {$body2} {$body3}";

            $sec2_benefits = [
                ['icon' => '📈', 'title' => 'Google Partners', 'desc' => 'Certified agency with proven organic search growth results.'],
                ['icon' => '⭐', 'title' => 'Data-Driven', 'desc' => 'Campaign setups based on competitive search queries analysis.'],
                ['icon' => '💳', 'title' => 'Transparent ROI', 'desc' => 'Detailed monthly performance reports showing clicks and leads.'],
                ['icon' => '⏱', 'title' => 'Direct Managers', 'desc' => 'Dedicated phone line to your marketing project manager.'],
                ['icon' => '🗺', 'title' => 'Maps Domination', 'desc' => 'Securing top rankings in the Google Maps Local 3-Pack.'],
                ['icon' => '🎯', 'title' => 'Conversion Focus', 'desc' => 'Optimizing layouts to turn traffic into phone calls.']
            ];

            $sec4_features = [
                "Google Partner Agency", "Weekly ROI Reporting", "High-Converting Ad Copies", 
                "Organic Search Domination", "Map Pack Dominators", "Local Schema Markups", 
                "Month-to-Month Contracts"
            ];

            $sec5_cta_text = $rng->pick([
                "Dominate search rankings and multiply your customer base in {$city_cap}. Contact the best digital marketing agency in {$city_cap} to plan your campaign.",
                "Increase your local visibility on search engines. Call the best local SEO specialists in {$city_cap} to conduct a maps audit.",
                "Get high-intent leads calling your sales desk. Call the top PPC agency in {$city_cap} to request a landing page audit.",
                "Ready to scale your business? Call {$city_cap}'s certified digital marketing experts today for a strategy call."
            ]);

        } elseif ($is_mechanic) {
            $client_type = "Car Owners and Fleet Operators";

            // Hero Title Variation
            $t1 = $rng->pick(["Best", "Top-Rated", "Certified", "Expert", "Reliable"]);
            $t2 = $rng->pick(["Mechanic", "Auto Repair Shop", "Car Garage", "Automotive Specialists"]);
            $t3 = "in " . $city_cap;
            $t4 = $rng->pick([": Engine Diagnostics & Repairs", ": Car Brake Service & Oil Changes", ": Emergency Towing & Auto Care", ": Dealership Quality Servicing"]);
            $sec1_title = "{$t1} {$t2} {$t3}{$t4}";

            // Hero Intro Caption
            $cap1 = $rng->pick([
                "Searching for the best mechanic in {$city_cap} to handle engine repair or periodic car servicing?",
                "Need a certified auto repair shop or emergency garage in {$city_cap} with transparent pricing?",
                "For professional car diagnostics, brake pad changes, and AC servicing in {$city_cap}, trust our workshop.",
                "Struggling with a warning light on your dashboard? Let {$city_cap}'s top auto mechanics diagnose it."
            ]);
            $cap2 = $rng->pick([
                "Our certified car garage in {$city_cap} offers engine diagnostics, suspension tuning, and scheduled upkeep.",
                "We specialize in auto repair near me in {$city_cap}, utilizing modern computerized fault scanners.",
                "Our mechanics handle transmission repairs, oil changes, battery swaps, and exhaust refittings.",
                "We use manufacturer-approved OEM spare parts to keep your dealership warranty fully intact."
            ]);
            $cap3 = $rng->pick([
                "We provide emergency starter repairs, radiator flushes, and brake surfacing in {$city_cap}.",
                "Whether you need a quick warning scan or a complete engine overhaul, our technicians ensure quality work.",
                "Our ASE-certified mechanics follow strict safety checklists to keep your vehicle running efficiently.",
                "From computerized wheel alignment to emergency flatbed towing, our garage is fully equipped."
            ]);
            $cap4 = $rng->pick([
                "Get transparent diagnostics and upfront flat-rate pricing at {$city_cap}'s premier auto garage today!",
                "We guarantee high-quality workmanship, fast turnaround times, and reliable vehicle components.",
                "Call our service desk now to schedule periodic car maintenance or request flatbed emergency towing.",
                "Keep your car safe on the road. Contact {$city_cap}'s leading automotive repair workshop today."
            ]);
            $sec1_caption = "{$cap1} {$cap2} {$cap3} {$cap4}";

            // Description Body
            $body1 = $rng->pick([
                "Getting reliable auto maintenance and engine servicing in {$city_cap} is now simple.",
                "Our certified mechanics service cars, SUVs, and fleet vehicles of all makes in {$city_cap}.",
                "We are dedicated to keeping vehicle engines running safely and smoothly across {$city_cap}.",
                "Our auto service covers every neighborhood in {$city_cap}, providing dealership quality at fair rates."
            ]);
            $body2 = $rng->pick([
                "We specialize in car brake pad changes, AC recharging, oil filter swaps, and coolant flushes.",
                "Our garage uses premium synthetic lubricants, advanced OBD2 diagnostics, and OEM components.",
                "We handle everything from simple spark plug replacements to complex automatic transmission repairs.",
                "Our mechanics use computerized alignment systems to prevent tire wear and steering pull."
            ]);
            $body3 = $rng->pick([
                "All auto repairs are fully insured and backed by a comprehensive workshop warranty.",
                "We explain all vehicle diagnostics beforehand so you approve the estimate before we start.",
                "Enjoy clean waiting lounges, flat-rate pricing guides, and fast, same-day repairs.",
                "Rely on {$city_cap}'s leading mechanic workshop for honesty, punctuality, and excellent service."
            ]);
            $sec2_text = "{$body1} {$body2} {$body3}";

            $sec2_benefits = [
                ['icon' => '🚗', 'title' => 'Certified Mechanics', 'desc' => 'Experienced ASE-certified car repair technicians.'],
                ['icon' => '⭐', 'title' => 'OEM Auto Parts', 'desc' => 'We use only manufacturer-approved components.'],
                ['icon' => '💳', 'title' => 'Upfront Quotes', 'desc' => 'Transparent diagnostics with detailed estimations.'],
                ['icon' => '⏱', 'title' => 'Quick Turnaround', 'desc' => 'Fast repairs to get you back on the road in no time.'],
                ['icon' => '🛠', 'title' => 'Brake Specialists', 'desc' => 'Precision rotor surfacing and high-quality pad fittings.'],
                ['icon' => '⚙', 'title' => 'OBD2 Diagnostics', 'desc' => 'Computerized scans for instant fault code mapping.']
            ];

            $sec4_features = [
                "Certified OEM Components", "Computerized Fault Scan", "Punctual Maintenance Service", 
                "Affordable Repairs Guarantee", "Emergency Flatbed Towing", "AC Recharging & Care", 
                "ASE Certified Technicians"
            ];

            $sec5_cta_text = $rng->pick([
                "We are keeping drivers safe and vehicle engines healthy across {$city_cap} with top-tier mechanic solutions. Contact the best auto repair shop in {$city_cap} today.",
                "Don't let vehicle issues delay your schedule. Call {$city_cap}'s top auto repair garage for priority diagnostics.",
                "Keep your vehicle running like new. Call the best car maintenance shop in {$city_cap} to schedule your service.",
                "Struggling with a dashboard warning light? Call our {$city_cap} mechanics now for a fast computerized scan."
            ]);

        } else {
            // General Fallback
            $client_type = "Businesses and Local Customers";

            // Hero Title Variation
            $t1 = $rng->pick(["Best", "Top-Rated", "Reliable", "Expert", "Premium"]);
            $t2 = "{$service_cap} Services";
            $t3 = "in " . $city_cap;
            $t4 = $rng->pick([": Top-Rated Local Experts", ": Safe & Professional Care", ": Quality Installations & Repairs", ": Residential & Commercial Specialists"]);
            $sec1_title = "{$t1} {$t2} {$t3}{$t4}";

            // Hero Intro Caption
            $cap1 = $rng->pick([
                "Looking for the best {$service_lower} in {$city_cap} for a residential or commercial project?",
                "Need a professional, trustworthy {$service_lower} specialist in {$city_cap} who arrives on time?",
                "For high-standard {$service_lower} installations, maintenance, and emergency repairs in {$city_cap}, trust us.",
                "When you need dependable, certified {$service_lower} services in {$city_cap}, our team is ready to help."
            ]);
            $cap2 = $rng->pick([
                "Our certified team of local {$service_lower} specialists in {$city_cap} provides complete repairs and care.",
                "We deliver safe, code-compliant diagnostics, routine inspections, and professional setups.",
                "Our crew handles routine maintenance, emergency adjustments, and custom project designs.",
                "We serve local properties with premium materials, state-of-the-art tools, and upfront flat-rate billing."
            ]);
            $cap3 = $rng->pick([
                "We specialize in top-rated {$service_lower} near me in {$city_cap}, ensuring rapid dispatcher support.",
                "Whether you need a minor adjustment or a complete system installation, we ensure quality results.",
                "Our safety-certified technicians handle diagnostics, replacement of worn parts, and system upgrades.",
                "From preventative checks to urgent repairs, our crew is ready to send assistance."
            ]);
            $cap4 = $rng->pick([
                "Partner with the leading local {$service_lower} company for flat-rate quotes and guaranteed work today!",
                "Enjoy peace of mind with our workmanship warranty, transparent invoices, and dedicated managers.",
                "Contact {$city_cap}'s premier {$service_lower} team today for a free estimate and same-day priority booking.",
                "Call us now to discuss your requirements or request immediate assistance from our dispatcher."
            ]);
            $sec1_caption = "{$cap1} {$cap2} {$cap3} {$cap4}";

            // Description Body
            $body1 = $rng->pick([
                "Securing professional {$service_lower} services in {$city_cap} has never been simpler.",
                "Our local team manages residential and commercial {$service_lower} projects of all scales in {$city_cap}.",
                "We are proud to serve homes and office properties across {$city_cap} with high-quality maintenance.",
                "Our service network covers all neighborhoods in {$city_cap}, bringing master specialists to you."
            ]);
            $body2 = $rng->pick([
                "We specialize in modern setups, diagnostic troubleshooting, and code compliance checks.",
                "Our technicians use heavy-duty components, durable elements, and safety-certified gear.",
                "We handle everything from minor repairs to complex, multi-phase systems installations.",
                "We use advanced testing meters to ensure all work adheres to local regulations."
            ]);
            $body3 = $rng->pick([
                "All our work is fully licensed, insured, and complies with local building safety codes.",
                "Whether it's a minor job or a custom project, we guarantee a clean and long-lasting finish.",
                "Enjoy transparent fixed costing, direct support response, and friendly customer care.",
                "Rely on {$city_cap}'s certified experts for punctuality, honest estimates, and flat-rate billing."
            ]);
            $sec2_text = "{$body1} {$body2} {$body3}";

            $sec2_benefits = [
                ['icon' => '✦', 'title' => 'Certified Experts', 'desc' => 'Our team is background-checked and fully certified.'],
                ['icon' => '⭐', 'title' => 'Premium Quality', 'desc' => 'We use state-of-the-art tools and materials.'],
                ['icon' => '💳', 'title' => 'Fair Pricing', 'desc' => 'Upfront quotes with absolutely zero hidden fees.'],
                ['icon' => '⏱', 'title' => 'Rapid Response', 'desc' => 'On-time scheduling and quick project turnaround.'],
                ['icon' => '🛡', 'title' => 'Licensed & Insured', 'desc' => 'Fully licensed and bonded technicians for peace of mind.'],
                ['icon' => '⚙', 'title' => 'Code Compliant', 'desc' => 'Adhering to strict safety regulations and local codes.']
            ];

            $sec4_features = [
                "Over 10+ Years of Experience", "100% Customer Satisfaction", "Licensed & Insured Team", 
                "Local Community Focused", "Accurate Fault Inspections", "Free Project Quotations", 
                "Code Compliant Upkeep"
            ];

            $sec5_cta_text = $rng->pick([
                "We are serving customers across {$city_cap} with top-tier {$service_lower} solutions. Click the button to call our dispatcher or request a callback.",
                "Get dependable support at your {$city_cap} home or office space. Contact the leading {$service_lower} technicians today.",
                "Ready to schedule your inspection? Contact {$city_cap}'s best {$service_lower} specialists to book your priority service.",
                "Don't compromise on quality or safety. Call {$city_cap}'s trusted {$service_lower} experts for same-day service."
            ]);
        }

        return [
            'client_type'   => $client_type,
            'sec1_title'    => $sec1_title,
            'sec1_caption'  => $sec1_caption,
            'sec2_text'     => $sec2_text,
            'sec2_benefits' => $sec2_benefits,
            'sec4_features' => $sec4_features,
            'sec5_cta_text' => $sec5_cta_text
        ];
    }

    private function get_sub_services($service) {
        $service = strtolower($service);
        
        $marketing_services = [
            ['icon' => '📈', 'title' => 'Search Engine Optimization', 'desc' => 'Rank higher on Google and bring organic customers to your website.'],
            ['icon' => '💻', 'title' => 'Pay Per Click Ads', 'desc' => 'High-conversion campaigns on Google Search and Social Media Networks.'],
            ['icon' => '📱', 'title' => 'Social Media Management', 'desc' => 'Manage your brand, post engaging media, and build a local community.'],
            ['icon' => '🎨', 'title' => 'Web Design & Branding', 'desc' => 'Create premium visual identities and ultra-responsive landing pages.'],
            ['icon' => '✍', 'title' => 'Content Marketing', 'desc' => 'Write authoritative blogs, copy, and campaigns that convert visitors.'],
            ['icon' => '📊', 'title' => 'Reporting & Analytics', 'desc' => 'Detailed conversion reports, traffic analytics, and growth planning.']
        ];

        $plumbing_services = [
            ['icon' => '💧', 'title' => 'Leak Detection & Repair', 'desc' => 'State-of-the-art sonic leak detection and pipe repairs for properties.'],
            ['icon' => '🚿', 'title' => 'Drain Cleaning', 'desc' => 'Clearing blocked drains, hydro-jetting, and sewer camera inspections.'],
            ['icon' => '🔥', 'title' => 'Water Heater Service', 'desc' => 'Tankless and standard water heater installations, repairs, and care.'],
            ['icon' => '🛠', 'title' => 'Pipe Installation & Care', 'desc' => 'Complete home repiping, copper line care, and sewer system replacements.'],
            ['icon' => '🚨', 'title' => 'Emergency Plumbing', 'desc' => 'Rapid dispatch team ready 24/7 to solve plumbing emergencies.'],
            ['icon' => '🏢', 'title' => 'Commercial Plumbing', 'desc' => 'Preventative maintenance and plumbing grids for commercial offices.']
        ];

        $electrical_services = [
            ['icon' => '🔌', 'title' => 'Wiring & Repiping', 'desc' => 'Complete residential rewiring, electrical panels upgrades, and inspection.'],
            ['icon' => '💡', 'title' => 'Lighting Installations', 'desc' => 'Interior and exterior LED lighting design, setup, and control grids.'],
            ['icon' => '⚡', 'title' => 'Circuit Breaker Services', 'desc' => 'Fixing overloaded circuits, replacing fuses, and panel main installations.'],
            ['icon' => '🔋', 'title' => 'EV Charging Stations', 'desc' => 'Setting up domestic and commercial level 2 EV charging facilities.'],
            ['icon' => '🚨', 'title' => 'Emergency Outage Repairs', 'desc' => 'Fast electrical repairs for home systems and commercial grids.'],
            ['icon' => '⚙', 'title' => 'Smart Home Setup', 'desc' => 'Connecting smart thermostats, security cameras, and automated hubs.']
        ];

        $general_services = [
            ['icon' => '✦', 'title' => 'Expert Consultation', 'desc' => 'Comprehensive evaluation and customized project estimates.'],
            ['icon' => '🔧', 'title' => 'Systems Installation', 'desc' => 'Professional setups using state-of-the-art tools and premium parts.'],
            ['icon' => '🔍', 'title' => 'Diagnostics & Checkups', 'desc' => 'Thorough inspections to detect failures before they cause issues.'],
            ['icon' => '⚙', 'title' => 'Routine Maintenance', 'desc' => 'Periodic cleaning and checks to extend systems lifetime.'],
            ['icon' => '🛠', 'title' => 'Repairs & Replacements', 'desc' => 'Fast replacement of broken elements with warranty-backed parts.'],
            ['icon' => '🚨', 'title' => 'Emergency Assistance', 'desc' => 'Rapid response dispatcher available 24/7 for critical failures.']
        ];

        if (strpos($service, 'marketing') !== false || strpos($service, 'seo') !== false || strpos($service, 'ads') !== false) {
            return $marketing_services;
        } elseif (strpos($service, 'plumb') !== false || strpos($service, 'drain') !== false || strpos($service, 'water') !== false) {
            return $plumbing_services;
        } elseif (strpos($service, 'electr') !== false || strpos($service, 'wire') !== false || strpos($service, 'light') !== false) {
            return $electrical_services;
        }

        return $general_services;
    }

    /* ---------------------------------------------------------
     * REALISTIC STOCK IMAGES
     * --------------------------------------------------------- */

    private function get_realistic_images($service, $city = '') {
        $service = strtolower($service);

        $auto = [
            'https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1487754180451-c456f719a1fc?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=800&q=80'
        ];
        $electrician = [
            'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1460518451285-97b6ba32ee61?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=800&q=80'
        ];
        $plumber = [
            'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1607472586893-edb5ca08f55d?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1542013936-6936-8848e5740475?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1620626011160-9928f1b9b6d4?auto=format&fit=crop&w=800&q=80'
        ];
        $tailor = [
            'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1598550874175-4d0ef436c909?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1506806732259-39c2d0268443?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1534126511673-b6899657816a?auto=format&fit=crop&w=800&q=80'
        ];
        $dentist = [
            'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1606811971618-4486d14f3f99?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1609840114035-3c981b782dfe?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1559599101-f09722fb4948?auto=format&fit=crop&w=800&q=80'
        ];
        $cleaning = [
            'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1563453392212-326f5e854473?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1603712726230-01584be8377f?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=800&q=80'
        ];
        $marketing = [
            'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1531535934027-68961520d2fc?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1542744094-3a31f103e35f?auto=format&fit=crop&w=800&q=80'
        ];
        $general = [
            'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1521791136368-1a9b9275336d?auto=format&fit=crop&w=800&q=80',
            'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80'
        ];

        if (strpos($service, 'mechanic') !== false || strpos($service, 'auto') !== false || strpos($service, 'car') !== false) {
            return $auto;
        } elseif (strpos($service, 'electr') !== false || strpos($service, 'wire') !== false) {
            return $electrician;
        } elseif (strpos($service, 'plumb') !== false || strpos($service, 'leak') !== false || strpos($service, 'drain') !== false) {
            return $plumber;
        } elseif (strpos($service, 'tailor') !== false || strpos($service, 'sew') !== false || strpos($service, 'cloth') !== false) {
            return $tailor;
        } elseif (strpos($service, 'dentist') !== false || strpos($service, 'dental') !== false) {
            return $dentist;
        } elseif (strpos($service, 'clean') !== false || strpos($service, 'maid') !== false) {
            return $cleaning;
        } elseif (strpos($service, 'marketing') !== false || strpos($service, 'seo') !== false || strpos($service, 'agency') !== false || strpos($service, 'brand') !== false) {
            return $marketing;
        }

        // Clean user input from city names and filler words to search Flickr with high accuracy
        $clean_keyword = strtolower($service);
        if (!empty($city)) {
            $clean_keyword = str_replace(strtolower($city), '', $clean_keyword);
        }
        $fillers = ['best', 'services', 'service', 'in', 'near me', 'at', 'online', 'top', 'professional', 'expert', 'pro'];
        foreach ($fillers as $filler) {
            $clean_keyword = preg_replace('/\b' . preg_quote($filler, '/') . '\b/', '', $clean_keyword);
        }
        $clean_keyword = trim(preg_replace('/\s+/', ' ', $clean_keyword));
        $clean_keyword = str_replace(' ', ',', $clean_keyword);
        if (empty($clean_keyword)) {
            $clean_keyword = 'work';
        }

        // Fetch dynamic images from Flickr search feed API
        $url = 'https://www.flickr.com/services/feeds/photos_public.gne?tags=' . urlencode($clean_keyword) . '&format=json&nojsoncallback=1';
        $response = wp_remote_get($url, [
            'timeout' => 5,
            'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ]);

        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $body = wp_remote_retrieve_body($response);
            $body = str_replace("\\'", "'", $body); // Fix unescaped single quotes
            $json = json_decode($body, true);
            $images = [];

            if ($json && !empty($json['items'])) {
                foreach ($json['items'] as $item) {
                    if (!empty($item['media']['m'])) {
                        // Use higher-res _b.jpg instead of medium _m.jpg
                        $images[] = str_replace('_m.jpg', '_b.jpg', $item['media']['m']);
                    }
                }
            } else {
                // Regex fallback if JSON is malformed
                preg_match_all('/"m"\s*:\s*"([^"]+)"/', $body, $matches);
                if (!empty($matches[1])) {
                    foreach ($matches[1] as $m) {
                        $img_url = str_replace('\\', '', $m);
                        $images[] = str_replace('_m.jpg', '_b.jpg', $img_url);
                    }
                }
            }

            if (count($images) >= 2) {
                return $images; // Return all found images so we have a larger pool
            }
        }

        // Fallback to LoremFlickr if feed is empty or request fails
        return [
            "https://loremflickr.com/800/600/{$clean_keyword},work/all",
            "https://loremflickr.com/800/600/{$clean_keyword},tools/all",
            "https://loremflickr.com/800/600/{$clean_keyword},workspace/all"
        ];
    }

    private function get_realistic_portfolio($service) {
        $service = strtolower($service);

        $tailor = [
            'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1506806732259-39c2d0268443?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1534126511673-b6899657816a?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1508807526345-15e9b7f43f81?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1593032465175-481ac7f401a0?auto=format&fit=crop&w=400&q=80'
        ];
        $plumber = [
            'https://images.unsplash.com/photo-1581094288338-2314dddb7ecc?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1605787020600-b9ebd5df1d07?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1620626011160-9928f1b9b6d4?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1542013936-6936-8848e5740475?auto=format&fit=crop&w=400&q=80'
        ];
        $electrician = [
            'https://images.unsplash.com/photo-1460518451285-97b6ba32ee61?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1565814636199-ae8133055c1c?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=400&q=80'
        ];
        $mechanic = [
            'https://images.unsplash.com/photo-1486006920555-c77dce18193b?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1619642751034-765dfdf7c58e?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1487754180451-c456f719a1fc?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1517524206127-48bbd363f3d7?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1580273916550-e323be2ae537?auto=format&fit=crop&w=400&q=80'
        ];
        $dentist = [
            'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1606811971618-4486d14f3f99?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1609840114035-3c981b782dfe?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1579684389782-64d84b5e905d?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1559599101-f09722fb4948?auto=format&fit=crop&w=400&q=80'
        ];
        $cleaning = [
            'https://images.unsplash.com/photo-1563453392212-326f5e854473?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1603712726230-01584be8377f?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=400&q=80'
        ];
        $marketing = [
            'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1531535934027-68961520d2fc?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1542744094-3a31f103e35f?auto=format&fit=crop&w=400&q=80'
        ];
        $general = [
            'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1521791136368-1a9b9275336d?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=400&q=80',
            'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=400&q=80'
        ];

        if (strpos($service, 'mechanic') !== false || strpos($service, 'auto') !== false || strpos($service, 'car') !== false) {
            return $mechanic;
        } elseif (strpos($service, 'electr') !== false || strpos($service, 'wire') !== false) {
            return $electrician;
        } elseif (strpos($service, 'plumb') !== false || strpos($service, 'leak') !== false || strpos($service, 'drain') !== false) {
            return $plumber;
        } elseif (strpos($service, 'tailor') !== false || strpos($service, 'sew') !== false || strpos($service, 'cloth') !== false) {
            return $tailor;
        } elseif (strpos($service, 'dentist') !== false || strpos($service, 'dental') !== false) {
            return $dentist;
        } elseif (strpos($service, 'clean') !== false || strpos($service, 'maid') !== false) {
            return $cleaning;
        } elseif (strpos($service, 'marketing') !== false || strpos($service, 'seo') !== false || strpos($service, 'agency') !== false || strpos($service, 'brand') !== false) {
            return $marketing;
        }

        return $general;
    }

    /* ---------------------------------------------------------
     * PREVIEW
     * --------------------------------------------------------- */

    public function render_preview($data) {

        if (empty($data)) {

            return '
                <div class="lswg-empty-preview">
                    <div class="empty-icon">✦</div>
                    <h3>Your page preview will appear here</h3>
                    <p>Enter a city and service above and click Generate.</p>
                </div>
            ';
        }

        // Look up active template
        $templates = get_option('lswg_templates', []);
        $active_template = null;
        foreach ($templates as $t) {
            if (!empty($t['active'])) {
                $active_template = $t;
                break;
            }
        }

        // If a custom template is active, parse placeholders and return HTML
        if ($active_template && $active_template['id'] !== 'default' && !empty($active_template['html'])) {
            $html = $active_template['html'];

            $sec3_services_html = '';
            if (!empty($data['sec3_services'])) {
                foreach ($data['sec3_services'] as $s) {
                    $sec3_services_html .= '
                    <div class="sub-service-card">
                        <div class="sub-service-icon">' . $s['icon'] . '</div>
                        <h3>' . esc_html($s['title']) . '</h3>
                        <p>' . esc_html($s['desc']) . '</p>
                    </div>';
                }
            }

            $sec4_features_html = '';
            if (!empty($data['sec4_features'])) {
                foreach ($data['sec4_features'] as $f) {
                    $sec4_features_html .= '
                    <div class="feature-badge">
                        <span class="badge-icon">✓</span>
                        ' . esc_html($f) . '
                    </div>';
                }
            }

            $portfolio_html = '';
            if (!empty($data['portfolio'])) {
                foreach ($data['portfolio'] as $p) {
                    $portfolio_html .= '
                    <div class="portfolio-item-card">
                        <img src="' . esc_url($p) . '" alt="Portfolio Work">
                    </div>';
                }
            }

            $testimonials_html = '';
            if (!empty($data['testimonials'])) {
                foreach ($data['testimonials'] as $t) {
                    $testimonials_html .= '
                    <div class="testimonial-slide">
                        <p class="testimonial-quote">"' . esc_html($t['quote']) . '"</p>
                        <p class="testimonial-author">- ' . esc_html($t['author']) . '</p>
                    </div>';
                }
            }

            $tailored_html = '';
            if (!empty($data['tailored_solutions']) && is_array($data['tailored_solutions'])) {
                foreach ($data['tailored_solutions'] as $ts) {
                    $tailored_html .= '
                    <div class="tailored-solution-item">
                        <div class="tailored-icon">✦</div>
                        <div class="tailored-text">
                            <h4>' . esc_html($ts['title']) . '</h4>
                            <p>' . esc_html($ts['desc']) . '</p>
                        </div>
                    </div>';
                }
            }
            
            $placeholders = [
                '{{service}}'       => esc_html(ucwords($data['service'])),
                '{{city}}'          => esc_html(ucwords($data['city'])),
                '{{business_name}}' => esc_html($data['business_name']),
                '{{address}}'       => esc_html(!empty($data['address']) ? $data['address'] : '314 Complex, Vijay Plot, Rajkot - 360002.'),
                '{{sec1_title}}'    => esc_html($data['sec1_title']),
                '{{sec1_caption}}'  => esc_html($data['sec1_caption']),
                '{{sec2_title}}'    => esc_html($data['sec2_title']),
                '{{sec2_text}}'     => esc_html($data['sec2_text']),
                '{{image_1}}'       => esc_url($data['images'][0]),
                '{{image_2}}'       => esc_url($data['images'][1]),
                '{{image_3}}'       => esc_url($data['images'][2]),
                '{{email}}'         => 'support@' . sanitize_title($data['service']) . '-' . sanitize_title($data['city']) . '.com',
                '{{sec3_title}}'    => esc_html($data['sec3_title']),
                '{{sec3_services}}' => $sec3_services_html,
                '{{sec4_title}}'    => esc_html($data['sec4_title']),
                '{{sec4_features}}' => $sec4_features_html,
                '{{sec5_cta_title}}'=> esc_html($data['sec5_cta_title']),
                '{{sec5_cta_text}}' => esc_html($data['sec5_cta_text']),
                '{{portfolio_grid}}' => $portfolio_html,
                '{{testimonials_slider}}' => $testimonials_html,
                
                // New placeholders
                '{{case_study_title}}' => esc_html(!empty($data['case_study_title']) ? $data['case_study_title'] : ''),
                '{{case_study_challenge}}' => esc_html(!empty($data['case_study_challenge']) ? $data['case_study_challenge'] : ''),
                '{{case_study_solution}}' => esc_html(!empty($data['case_study_solution']) ? $data['case_study_solution'] : ''),
                '{{case_study_results}}' => esc_html(!empty($data['case_study_results']) ? $data['case_study_results'] : ''),
                '{{tailored_solutions_grid}}' => $tailored_html,
                '{{tab_1_title}}' => esc_html(!empty($data['tab_1_title']) ? $data['tab_1_title'] : 'Tailored Solutions'),
                '{{tab_1_desc}}' => esc_html(!empty($data['tab_1_desc']) ? $data['tab_1_desc'] : ''),
                '{{tab_2_title}}' => esc_html(!empty($data['tab_2_title']) ? $data['tab_2_title'] : 'Proven Track Record'),
                '{{tab_2_desc}}' => esc_html(!empty($data['tab_2_desc']) ? $data['tab_2_desc'] : ''),
                '{{tab_3_title}}' => esc_html(!empty($data['tab_3_title']) ? $data['tab_3_title'] : 'Dedicated Support'),
                '{{tab_3_desc}}' => esc_html(!empty($data['tab_3_desc']) ? $data['tab_3_desc'] : ''),
                '{{tab_4_title}}' => esc_html(!empty($data['tab_4_title']) ? $data['tab_4_title'] : 'Data-Driven Results'),
                '{{tab_4_desc}}' => esc_html(!empty($data['tab_4_desc']) ? $data['tab_4_desc'] : '')
            ];
            
            return str_replace(array_keys($placeholders), array_values($placeholders), $html);
        }

        $city = esc_html($data['city']);
        $service = esc_html($data['service']);
        $business = esc_html($data['business_name']);
        $address = !empty($data['address']) ? esc_html($data['address']) : '314 Complex, 15/20-Vijay Plot, Gondal Road, RAJKOT - 360002.';
        
        $sec1_caption = esc_html($data['sec1_caption']);
        $sec2_title = esc_html($data['sec2_title']);
        $sec2_text = esc_html($data['sec2_text']);
        $sec3_title = esc_html($data['sec3_title']);

        $img1 = esc_url($data['images'][0]);
        $img2 = esc_url($data['images'][1]);
        $img3 = esc_url($data['images'][2]);

        // Wrap service name in gradient span for premium layout
        $sec1_title_html = str_replace($service, '<span class="lswg-gradient-text">' . $service . '</span>', esc_html($data['sec1_title']));
        $dynamic_email = 'support@' . sanitize_title($service) . '-' . sanitize_title($city) . '.com';

        ob_start();
        ?>

        <div class="website-frame">

            <!-- TOP CONTACT BAR -->
            <div class="site-topbar">
                <div class="topbar-content">
                    <span>📞 +91 972 400 5500</span>
                    <span class="topbar-separator">|</span>
                    <span>✉ contact@vispansolutions.com</span>
                </div>
            </div>

            <!-- WEBSITE NAV -->
            <header class="site-nav">
                <a href="#" class="site-logo">
                    <span class="logo-mark">V</span>
                    <strong>Vispan<span class="logo-accent">.</span></strong>
                </a>
                <nav class="site-nav-links">
                    <span>Home</span>
                    <span>About Us</span>
                    <span>What We Do</span>
                    <span>Blog</span>
                    <span>Investor</span>
                    <span>Career</span>
                    <span>Contact Us</span>
                </nav>
                <a href="#contact-form-section" class="site-nav-btn-group">
                    <span class="site-nav-button">LET'S TALK</span>
                    <span class="site-nav-arrow-badge"><span>↗</span></span>
                </a>
            </header>

            <!-- SECTION 1: HERO / BANNER -->
            <section class="site-section site-hero">
                <div class="hero-content">
                    <h1 class="hero-heading"><?php echo $sec1_title_html; ?></h1>
                    <p class="hero-subheading"><?php echo $sec1_caption; ?></p>
                    <p class="hero-description"><?php echo $sec2_text; ?></p>
                    
                    <div class="hero-bottom-actions">
                        <!-- LEARN MORE & WHATSAPP BUTTONS -->
                        <div class="hero-btn-wrap">
                            <a href="#about" class="site-nav-btn-group learn-more-btn">
                                <span class="site-nav-button">LEARN MORE</span>
                                <span class="site-nav-arrow-badge"><span>↗</span></span>
                            </a>
                            <a href="https://wa.me/919724005500" target="_blank" class="whatsapp-btn" title="Chat on WhatsApp">
                                <span class="whatsapp-icon">💬</span>
                            </a>
                        </div>
                        
                        <!-- SCROLL TARGET INDICATOR -->
                        <div class="scroll-target-indicator" onclick="document.getElementById('about').scrollIntoView({behavior: 'smooth'});">
                            <div class="scroll-target-dot"></div>
                        </div>
                    </div>
                </div>
                
                <div class="hero-card-wrap" id="contact-form-section">
                    <div class="spg-hero-card vispan-proposal-card">
                        <div class="spg-card-box">
                            <h3>Request A <?php echo ucwords($service); ?> Proposal</h3>
                            <form onsubmit="event.preventDefault(); alert('Proposal request submitted successfully! We will contact you shortly.');">
                                <div class="form-row-two">
                                    <input type="text" placeholder="Full Name*" required class="spg-input">
                                    <input type="email" placeholder="Email Address*" required class="spg-input">
                                </div>
                                <div class="form-row-two phone-row" style="margin-top: 10px;">
                                    <div class="phone-prefix">+91 IND</div>
                                    <input type="tel" placeholder="Contact No.*" required class="spg-input phone-input">
                                </div>
                                <div class="form-row-one" style="margin-top: 10px;">
                                    <select class="spg-input select-input" required>
                                        <option value="" disabled selected>Select Service*</option>
                                        <option><?php echo ucwords($service); ?> Consulting</option>
                                        <option><?php echo ucwords($service); ?> Implementation</option>
                                        <option><?php echo ucwords($service); ?> Maintenance</option>
                                        <option>Other Services</option>
                                    </select>
                                </div>
                                <div class="form-row-two" style="margin-top: 10px;">
                                    <input type="text" placeholder="Company Name*" required class="spg-input">
                                    <input type="text" placeholder="Website/Landing Page*" required class="spg-input">
                                </div>
                                <div class="form-row-one" style="margin-top: 10px;">
                                    <select class="spg-input select-input" required>
                                        <option value="" disabled selected>Budget Spent In Last 30 Days?*</option>
                                        <option>Under $1,000</option>
                                        <option>$1,000 - $5,000</option>
                                        <option>$5,000 - $10,000</option>
                                        <option>$10,000+</option>
                                    </select>
                                </div>
                                <div class="form-row-one" style="margin-top: 10px;">
                                    <textarea placeholder="Additional Details/Purpose of Business" class="spg-input textarea-input" rows="3"></textarea>
                                </div>
                                <button type="submit" class="vispan-submit-btn">
                                    <span>SUBMIT PROPOSAL</span>
                                    <span class="submit-arrow"><span>↗</span></span>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </section>

            <!-- SECTION 2: ONLINE PRESENCE / BENEFITS -->
            <section class="site-section site-presence" id="about">
                <div class="presence-content">
                    <h2><?php echo $sec2_title; ?></h2>
                    <p style="margin-bottom: 30px;"><?php echo $sec2_text; ?></p>
                    <div class="benefits-grid">
                        <?php foreach ($data['sec2_benefits'] as $b): ?>
                            <div class="benefit-item">
                                <div class="benefit-icon"><?php echo $b['icon']; ?></div>
                                <div class="benefit-text">
                                    <h4><?php echo esc_html($b['title']); ?></h4>
                                    <p><?php echo esc_html($b['desc']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="presence-image-wrap">
                    <img src="<?php echo $img2; ?>" alt="Strong Online Presence">
                </div>
            </section>

            <!-- SECTION 3: SERVICES LIST OF 6 SUB-SERVICES -->
            <section class="site-section site-sub-services" id="services">
                <div class="sub-services-header">
                    <h2><?php echo $sec3_title; ?></h2>
                </div>
                <div class="sub-services-grid">
                    <?php foreach ($data['sec3_services'] as $svc): ?>
                        <div class="sub-service-card">
                            <div class="sub-service-icon"><?php echo $svc['icon']; ?></div>
                            <h3><?php echo esc_html($svc['title']); ?></h3>
                            <p><?php echo esc_html($svc['desc']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- SECTION 4: WHY CHOOSE US -->
            <section class="site-section site-why-us" id="why-us">
                <div class="why-us-content">
                    <h2><?php echo esc_html($data['sec4_title']); ?></h2>
                    <div class="features-row">
                        <?php foreach ($data['sec4_features'] as $feat): ?>
                            <span class="feature-badge">✓ <?php echo esc_html($feat); ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>

            <!-- SECTION 5: CTA BANNER -->
            <section class="site-section site-cta-banner">
                <div class="cta-banner-content">
                    <h2><?php echo esc_html($data['sec5_cta_title']); ?></h2>
                    <p><?php echo esc_html($data['sec5_cta_text']); ?></p>
                    <a href="tel:+919876543210" class="primary-btn">Call: +91 98765 43210</a>
                </div>
                <div class="cta-banner-image">
                    <img src="<?php echo $img3; ?>" alt="Ready to get started">
                </div>
            </section>



            <!-- SECTION 7: TESTIMONIALS -->
            <section class="site-section site-testimonials" id="testimonials">
                <div class="testimonials-header">
                    <h2>What Our Clients Say</h2>
                </div>
                <div class="testimonials-slider">
                    <?php foreach ($data['testimonials'] as $test): ?>
                        <div class="testimonial-slide">
                            <p class="testimonial-quote">“<?php echo esc_html($test['quote']); ?>”</p>
                            <p class="testimonial-author">- <?php echo esc_html($test['author']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- SECTION 8: TRUST AWARDS -->
            <section class="site-section site-awards">
                <div class="google-partner-badge-large">
                    <span class="google-g">G</span>
                    <span class="partner-text">Google Partner</span>
                </div>
                <div class="awards-row">
                    <span class="award-medal">🏆 Ranked #1 Agency</span>
                    <span class="award-medal">🎖 100+ Active Clients</span>
                    <span class="award-medal">⭐ 5.0 Google Rating</span>
                    <span class="award-medal">🔒 100% Certified</span>
                    <span class="award-medal">⚡ Fast Local Delivery</span>
                </div>
            </section>

            <!-- SECTION 9: CONSULTATION FORM & GOOGLE MAP -->
            <section class="site-section site-consultation" id="contact" style="display:grid; grid-template-columns:1fr 1fr; gap:40px; align-items:stretch;">
                <div class="consultation-form-card">
                    <h3>Request a Free Consultation</h3>
                    <p>Fill out the form below to receive a customized estimation and strategy plan.</p>
                    <form onsubmit="event.preventDefault(); alert('Thank you! Our expert consultant will contact you shortly.');">
                        <div class="form-row">
                            <input type="text" placeholder="First Name" required class="spg-input">
                            <input type="text" placeholder="Last Name" required class="spg-input">
                        </div>
                        <div class="form-row">
                            <input type="email" placeholder="Email Address" required class="spg-input">
                            <input type="tel" placeholder="Phone Number" required class="spg-input">
                        </div>
                        <textarea placeholder="Tell us about your requirements" class="spg-input" style="height: 120px;"></textarea>
                        <button type="submit" class="primary-btn" style="width: 100%; border:none; cursor:pointer;">Request Free Consultation</button>
                    </form>
                </div>
                <div style="background:#fff; border-radius:var(--lswg-radius-lg); border:1px solid var(--lswg-border); padding:10px; box-shadow:var(--lswg-shadow); display:flex; flex-direction:column;">
                    <div style="padding:15px 20px;">
                        <h3 style="margin:0; font-size:1.3rem; font-weight:800; color:var(--lswg-heading);">Local Coverage Map</h3>
                        <p style="margin:5px 0 0; font-size:0.9rem; color:var(--lswg-text);">Real-time service areas and local client reviews from Google.</p>
                    </div>
                    <div style="flex-grow:1; border-radius:12px; overflow:hidden;">
                        <iframe src="https://maps.google.com/maps?q=<?php echo urlencode($service . ' in ' . $city); ?>&t=&z=13&ie=UTF8&iwloc=&output=embed" width="100%" height="100%" style="border:0; min-height:300px;"></iframe>
                    </div>
                </div>
            </section>

            <!-- VISPAN STYLE FOOTER -->
            <footer class="vispan-footer">
                <div class="footer-grid">
                    <div class="footer-col col-about">
                        <div class="footer-logo">
                            <span class="logo-mark">✦</span>
                            <strong><?php echo ucwords($service); ?></strong>
                        </div>
                        <p>Feel free to reach out if you want to collaborate with us. Drop us a line or start a chat.</p>
                        <div class="footer-socials">
                            <span class="social-icon">f</span>
                            <span class="social-icon">t</span>
                            <span class="social-icon">i</span>
                            <span class="social-icon">l</span>
                            <span class="social-icon">y</span>
                        </div>
                    </div>
                    <div class="footer-col">
                        <h4>Services</h4>
                        <ul>
                            <?php
                            if (!empty($sec3_services)) {
                                foreach ($sec3_services as $sub_serv) {
                                    echo '<li>' . esc_html($sub_serv['title']) . '</li>';
                                }
                            } else {
                                echo '<li>' . esc_html(ucwords($service)) . ' Consultation</li>';
                                echo '<li>Residential ' . esc_html(ucwords($service)) . '</li>';
                                echo '<li>Commercial ' . esc_html(ucwords($service)) . '</li>';
                            }
                            ?>
                        </ul>
                    </div>
                    <div class="footer-col">
                        <h4>Quick Links</h4>
                        <ul>
                            <li data-target="about">About Us</li>
                            <li data-target="services">Services</li>
                            <li data-target="testimonials">Reviews</li>
                            <li data-target="contact">Contact Us</li>
                        </ul>
                    </div>
                    <div class="footer-col col-contact">
                        <h4>Reach Us</h4>
                        <p><?php echo $address; ?></p>
                        <p><strong>Phone:</strong> +91 98765 43210</p>
                        <p><strong>Email:</strong> <?php echo $dynamic_email; ?></p>
                        <div class="google-partner-badge">
                            <span class="google-g">G</span>
                            <span class="partner-text">Google Partner</span>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom">
                    &copy; <?php echo date('Y'); ?> <?php echo $business; ?>. All Rights Reserved.
                </div>
            </footer>

            <!-- FLOATING WIDGET -->
            <a href="https://wa.me/919876543210" class="whatsapp-widget-float" target="_blank">
                <span class="wa-icon">💬</span>
            </a>

        </div>

        <?php

        return ob_get_clean();
    }

    /* ---------------------------------------------------------
     * SHORTCODE
     * --------------------------------------------------------- */

    public function shortcode($atts = []) {
        $atts = shortcode_atts([
            'city' => '',
            'service' => '',
        ], $atts, 'local_service_website');

        $page_id = get_queried_object_id();
        if (empty($page_id)) {
            $page_id = get_the_ID();
        }

        $data = [];

        // 1. Check if attributes are explicitly passed to the shortcode
        if (!empty($atts['city']) && !empty($atts['service'])) {
            $city = sanitize_text_field($atts['city']);
            $service = sanitize_text_field($atts['service']);
            $data = $this->collect_local_data($city, $service);
            $data['city'] = $city;
            $data['service'] = $service;
            $data['business_name'] = 'Professional ' . ucwords($service) . ' in ' . $city;
        } else {
            // 2. Check if the page has metadata from this plugin
            $data = get_post_meta($page_id, '_lswg_data', true);

            // 3. Check if the page has legacy metadata
            if (empty($data)) {
                $csg_city = get_post_meta($page_id, '_csg_city', true);
                $csg_service = get_post_meta($page_id, '_csg_service', true);
                if (!empty($csg_city) && !empty($csg_service)) {
                    $data = $this->collect_local_data($csg_city, $csg_service);
                    $data['city'] = $csg_city;
                    $data['service'] = $csg_service;
                    $data['business_name'] = 'Professional ' . ucwords($csg_service) . ' in ' . $csg_city;
                }
            }

            // 4. Fallback to global options
            if (empty($data)) {
                $data = get_option($this->option_key, []);
            }
        }

        if (empty($data)) {

            return '
                <div style="
                    padding:60px;
                    text-align:center;
                    font-family:Arial,sans-serif;
                    background:#f7f5ff;
                    border-radius:20px;
                ">
                    <h2>Page not generated yet</h2>
                    <p>Go to WordPress → City Service Page Generator and generate your landing page.</p>
                </div>
            ';
        }

        /*
         * Frontend gets the same website design.
         */
        return '<div class="lswg-frontend-wrapper">' .
            $this->render_preview($data) .
            '</div>';
    }

    /* ---------------------------------------------------------
     * PREVIEW AJAX
     * --------------------------------------------------------- */

    public function ajax_preview() {

        check_ajax_referer('lswg_nonce', 'nonce');

        $data = get_option($this->option_key, []);

        wp_send_json_success([
            'html' => $this->render_preview($data)
        ]);
    }

    /* ---------------------------------------------------------
     * ADMIN CSS
     * --------------------------------------------------------- */

    private function admin_css() {

        return <<<'CSS'

/* =========================================================
   FULL SCREEN WORDPRESS PLUGIN APPLICATION
   ========================================================= */

.toplevel_page_local-service-generator #wpcontent,
.city-page-generator_page_lswg-csv-bulk-import #wpcontent,
.city-page-generator_page_lswg-city-database #wpcontent,
.city-page-generator_page_lswg-templates #wpcontent,
.city-page-generator_page_lswg-openai-status #wpcontent,
.city-page-generator_page_lswg-keywords #wpcontent {
    padding: 0 !important;
}

#wpbody-content {
    padding-bottom: 0 !important;
}

#screen-meta,
#screen-meta-links,
#contextual-help-link-wrap,
#screen-options-link-wrap,
.update-nag {
    display: none !important;
}

html,
body {
    margin: 0 !important;
    padding: 0 !important;
}

body.wp-admin {
    background: #f7f7fb !important;
}

.lswg-app,
.lswg-app * {
    box-sizing: border-box;
}

.lswg-app {
    min-height: 100vh;
    width: 100%;
    color: #111525;
    background: #f7f7fb;
    font-family: "DM Sans", sans-serif;
    overflow-x: hidden;
}


/* =========================================================
   TOP BAR
   ========================================================= */

.lswg-topbar {
    height: 76px;
    background: rgba(255,255,255,.92);
    border-bottom: 1px solid #e9e8ef;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 46px;
    position: sticky;
    top: 0;
    z-index: 100;
    backdrop-filter: blur(20px);
}

.lswg-brand {
    display: flex;
    align-items: center;
    gap: 13px;
}

.lswg-brand strong {
    display: block;
    font-family: "Plus Jakarta Sans", sans-serif;
    font-size: 17px;
    font-weight: 800;
    letter-spacing: -.5px;
}

.lswg-brand small {
    color: #8a8d9b;
    font-size: 11px;
    display: block;
    margin-top: 2px;
}

.lswg-logo {
    width: 38px;
    height: 38px;
    border-radius: 11px;
    background: linear-gradient(135deg,#6f35ff,#e63891,#ff7135);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 3px;
    box-shadow: 0 8px 20px rgba(117,53,255,.25);
    transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275), box-shadow 0.4s ease;
}

.lswg-logo:hover {
    transform: rotate(15deg) scale(1.1);
    box-shadow: 0 12px 28px rgba(117,53,255,0.4);
}

.lswg-logo span {
    width: 3px;
    height: 14px;
    background: #fff;
    border-radius: 4px;
}

.lswg-logo span:nth-child(2) {
    height: 21px;
}

.lswg-logo span:nth-child(3) {
    height: 10px;
}

.lswg-top-actions {
    display: flex;
    align-items: center;
    gap: 20px;
}

.lswg-status {
    color: #737786;
    font-size: 12px;
    display: flex;
    gap: 7px;
    align-items: center;
}

.lswg-status i {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #31c875;
    box-shadow: 0 0 0 4px #e8f9f0;
}

.lswg-preview-btn {
    border: 1px solid #e4e2ea;
    background: #fff;
    border-radius: 9px;
    padding: 10px 16px;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    transition: .25s;
}

.lswg-preview-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 22px rgba(0,0,0,.08);
}


/* =========================================================
   HERO
   ========================================================= */

.lswg-hero {
    position: relative;
    min-height: 370px;
    overflow: hidden;
    background:
        radial-gradient(circle at 15% 20%,rgba(121,67,255,.18),transparent 30%),
        radial-gradient(circle at 85% 20%,rgba(255,73,151,.18),transparent 30%),
        linear-gradient(135deg,#f8f5ff,#fff3f7 55%,#fff);
    display: flex;
    align-items: center;
}

.lswg-grid {
    position: absolute;
    inset: 0;
    opacity: .35;
    background-image:
        linear-gradient(rgba(112,80,180,.08) 1px, transparent 1px),
        linear-gradient(90deg,rgba(112,80,180,.08) 1px, transparent 1px);
    background-size: 55px 55px;
    mask-image: linear-gradient(to bottom,black,transparent);
}

.lswg-orb {
    position: absolute;
    border-radius: 50%;
    filter: blur(50px);
    animation: lswgFloat 8s ease-in-out infinite;
}

.orb-one {
    width: 180px;
    height: 180px;
    background: #8a45ff;
    opacity: .15;
    left: -60px;
    top: 100px;
}

.orb-two {
    width: 220px;
    height: 220px;
    background: #ff4d91;
    opacity: .12;
    right: 5%;
    top: -80px;
    animation-delay: -3s;
}

@keyframes lswgFloat {
    50% {
        transform: translate(25px,20px);
    }
}

.lswg-hero-content {
    position: relative;
    z-index: 2;
    width: 1180px;
    max-width: calc(100% - 100px);
    margin: auto;
}

.lswg-pill {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 13px;
    border: 1px solid rgba(105,62,255,.16);
    background: rgba(255,255,255,.65);
    border-radius: 50px;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1.3px;
    color: #6842dc;
    backdrop-filter: blur(15px);
}

.pulse {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: #7c45ff;
    box-shadow: 0 0 0 5px rgba(124,69,255,.12);
}

.lswg-hero h1 {
    max-width: 850px;
    margin: 25px 0 17px;
    font-family: "Plus Jakarta Sans", sans-serif;
    font-size: clamp(42px,5vw,70px);
    line-height: 1.03;
    letter-spacing: -4px;
    font-weight: 800;
}

.lswg-hero h1 span {
    background: linear-gradient(90deg,#7137ff,#c83fc2,#ff5b48);
    -webkit-background-clip: text;
    color: transparent;
}

.lswg-hero p {
    max-width: 650px;
    color: #707382;
    font-size: 16px;
    line-height: 1.8;
    margin: 0;
}


/* =========================================================
   BUILDER
   ========================================================= */

.lswg-builder-wrap {
    padding: 70px 30px;
    background: #f8f8fb;
}

.lswg-builder-card {
    width: 1120px;
    max-width: 100%;
    margin: auto;
    background: #fff;
    border: 1px solid #e9e8ef;
    border-radius: 25px;
    padding: 42px;
    box-shadow:
        0 30px 80px rgba(38,25,80,.07),
        0 5px 20px rgba(0,0,0,.03);
    animation: lswgFadeUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}

@keyframes lswgFadeUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.lswg-builder-heading,
.result-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
}

.lswg-builder-heading > div:first-child,
.result-heading > div:first-child {
    display: flex;
    gap: 18px;
    align-items: flex-start;
}

.section-number {
    color: #7541ff;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1px;
    padding-top: 7px;
}

.lswg-builder-heading h2,
.result-heading h2 {
    margin: 0;
    font-family: "Plus Jakarta Sans", sans-serif;
    font-size: 25px;
    letter-spacing: -1px;
}

.lswg-builder-heading p,
.result-heading p {
    margin: 7px 0 0;
    color: #898c98;
    font-size: 13px;
}

.secure-badge,
.ready-badge {
    border: 1px solid #e8e7ee;
    border-radius: 50px;
    padding: 8px 12px;
    color: #6f7380;
    font-size: 11px;
    font-weight: 700;
}

.secure-badge span,
.ready-badge span {
    color: #2fbe75;
    margin-right: 5px;
}

.lswg-form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 22px;
    margin-top: 38px;
}

.lswg-field label {
    display: flex;
    align-items: center;
    gap: 7px;
    margin-bottom: 10px;
    color: #737685;
    font-size: 10px;
    letter-spacing: 1.3px;
    font-weight: 800;
}

.field-icon {
    color: #7a45ff;
    font-size: 15px;
}

.lswg-input-wrap {
    position: relative;
}

.lswg-input-wrap input {
    width: 100%;
    height: 60px;
    border: 1px solid #dfdee7;
    border-radius: 13px;
    padding: 0 48px 0 18px;
    font-family: "DM Sans",sans-serif;
    font-size: 16px;
    color: #171927;
    background: #fff;
    outline: none;
    transition: border-color 0.3s ease, box-shadow 0.3s ease, transform 0.3s ease;
    box-shadow: inset 0 1px 2px rgba(0,0,0,.02);
}

.lswg-input-wrap input:hover {
    border-color: #bfa3ff;
}

.lswg-input-wrap input:focus {
    border-color: #8050ff;
    box-shadow:
        0 0 0 4px rgba(128,80,255,.09),
        0 8px 20px rgba(50,30,120,.05);
}

.lswg-input-wrap input::placeholder {
    color: #b0b1bb;
}

.input-check {
    position: absolute;
    right: 18px;
    top: 50%;
    transform: translateY(-50%);
    color: #2dc477;
    font-weight: 800;
}

.lswg-field small {
    display: block;
    color: #9a9ca6;
    margin-top: 9px;
    font-size: 11px;
}

.lswg-generate {
    width: 100%;
    margin-top: 30px;
    height: 62px;
    border: 0;
    border-radius: 14px;
    color: #fff;
    cursor: pointer;
    font-family: "DM Sans",sans-serif;
    font-size: 14px;
    font-weight: 800;
    position: relative;
    overflow: hidden;
    background: linear-gradient(100deg,#6c38ff,#a53fe2,#ef4b88,#ff6941);
    background-size: 200% 100%;
    transition: transform 0.3s ease, background-position 0.35s ease, box-shadow 0.3s ease;
    box-shadow: 0 15px 35px rgba(116,57,255,.22);
}

.lswg-generate:hover {
    transform: translateY(-3px);
    background-position: 100% 0;
    box-shadow: 0 20px 45px rgba(116,57,255,.30);
}

.lswg-generate:hover .generate-arrow {
    transform: translateX(5px);
}

.generate-icon {
    margin-right: 9px;
}

.generate-arrow {
    position: absolute;
    right: 22px;
    font-size: 20px;
    transition: transform 0.3s ease;
}

.lswg-loading {
    display: none;
    margin-top: 25px;
    padding: 18px;
    background: #faf9ff;
    border-radius: 13px;
    border: 1px solid #eae5ff;
}

.loading-head {
    display: flex;
    align-items: center;
    gap: 12px;
}

.loading-head strong {
    display: block;
    font-size: 13px;
}

.loading-head span {
    display: block;
    margin-top: 3px;
    color: #858795;
    font-size: 11px;
}

.loading-spinner {
    width: 25px;
    height: 25px;
    border-radius: 50%;
    border: 3px solid #e6dcff;
    border-top-color: #7541ff;
    animation: lswgSpin .8s linear infinite;
}

@keyframes lswgSpin {
    to {
        transform: rotate(360deg);
    }
}

.loading-progress {
    height: 4px;
    margin-top: 15px;
    border-radius: 10px;
    background: #ece8f7;
    overflow: hidden;
}

.loading-progress span {
    display: block;
    height: 100%;
    width: 40%;
    border-radius: inherit;
    background: linear-gradient(90deg,#7137ff,#f05089);
    animation: progress 1.5s infinite;
}

@keyframes progress {
    50% { width: 90%; }
}


/* =========================================================
   RESULT
   ========================================================= */

.lswg-result {
    width: 1240px;
    max-width: calc(100% - 60px);
    margin: 0 auto;
    padding: 70px 0 100px;
}

.lswg-shortcode {
    margin: 28px 0;
    padding: 13px 15px;
    border-radius: 12px;
    border: 1px solid #e6e4ed;
    background: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.lswg-shortcode > div {
    display: flex;
    align-items: center;
    gap: 15px;
}

.code-label {
    color: #9294a0;
    font-size: 9px;
    letter-spacing: 1.2px;
    font-weight: 800;
}

.lswg-shortcode code {
    background: #f4f1ff;
    color: #6539df;
    padding: 8px 12px;
    border-radius: 7px;
    font-size: 12px;
}

#lswg-copy {
    border: 0;
    background: #171a29;
    color: #fff;
    border-radius: 7px;
    padding: 8px 14px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 700;
}

.lswg-empty-preview {
    min-height: 400px;
    background: #fff;
    border: 1px dashed #d9d6e3;
    border-radius: 20px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

.empty-icon {
    width: 65px;
    height: 65px;
    display: grid;
    place-items: center;
    border-radius: 18px;
    background: linear-gradient(135deg,#743eff,#df438f);
    color: #fff;
    font-size: 28px;
    box-shadow: 0 15px 35px rgba(116,62,255,.22);
}

.lswg-empty-preview h3 {
    margin: 20px 0 5px;
    font-family: "Plus Jakarta Sans",sans-serif;
}

.lswg-empty-preview p {
    color: #999ba6;
    font-size: 13px;
}


/* =========================================================
   GENERATED WEBSITE PREVIEW
   ========================================================= */

.website-frame {
    overflow: hidden;
    border-radius: 22px;
    background: #fff;
    border: 1px solid #e4e2e9;
    box-shadow: 0 35px 90px rgba(30,20,70,.12);
}


/* NAV */

.site-nav {
    height: 78px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 42px;
    background: rgba(255,255,255,.96);
    border-bottom: 1px solid #eeeef2;
}

.site-logo {
    display: flex;
    align-items: center;
    gap: 10px;
    max-width: 330px;
}

.site-logo strong {
    font-family: "Plus Jakarta Sans",sans-serif;
    font-size: 13px;
}

.logo-mark {
    width: 32px;
    height: 32px;
    display: grid;
    place-items: center;
    border-radius: 9px;
    color: #fff;
    background: linear-gradient(135deg,#7138ff,#f04c82);
}

.site-nav-links {
    display: flex;
    gap: 30px;
    color: #747682;
    font-size: 12px;
}

.site-nav-button {
    background: #151827;
    border: 0;
    color: #fff;
    border-radius: 8px;
    padding: 11px 15px;
    font-size: 11px;
    font-weight: 700;
}


/* HERO */

.site-hero {
    position: relative;
    min-height: 580px;
    display: grid;
    grid-template-columns: 1.05fr .95fr;
    align-items: center;
    padding: 70px 70px;
    overflow: hidden;
    background:
        radial-gradient(circle at 15% 10%,rgba(117,59,255,.18),transparent 33%),
        radial-gradient(circle at 90% 0%,rgba(255,69,144,.16),transparent 35%),
        linear-gradient(135deg,#fff,#faf4ff 55%,#fff5f7);
}

.hero-glow {
    position: absolute;
    width: 350px;
    height: 350px;
    background: #824cff;
    opacity: .08;
    filter: blur(80px);
    left: 20%;
    bottom: -200px;
    border-radius: 50%;
}

.site-hero-content {
    position: relative;
    z-index: 2;
}

.hero-label,
.mini-label {
    font-size: 9px;
    font-weight: 800;
    letter-spacing: 1.5px;
    color: #7440e8;
}

.hero-label {
    display: inline-flex;
    align-items: center;
    gap: 7px;
}

.hero-label span {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #f05375;
}
.site-hero h1 {
    margin: 20px 0;
    font-family: "Plus Jakarta Sans",sans-serif;
    font-size: clamp(28px, 4.5vw, 42px);
    line-height: 1.15;
    letter-spacing: -1.5px;
    max-width: 650px;
}
.site-hero h1 span {
    display: block;
    background: linear-gradient(90deg,#7138ff,#cf42b8,#fa6149);
    -webkit-background-clip: text;
    color: transparent;
}

.site-hero p {
    color: #777985;
    max-width: 570px;
    font-size: 14px;
    line-height: 1.8;
}

.hero-buttons {
    display: flex;
    gap: 10px;
    margin-top: 28px;
}

.primary-btn,
.secondary-btn {
    padding: 13px 18px;
    border-radius: 9px;
    font-size: 11px;
    font-weight: 800;
    cursor: pointer;
}

.primary-btn {
    color: #fff;
    border: 0;
    background: #151827;
    box-shadow: 0 10px 25px rgba(15,16,28,.15);
}

.secondary-btn {
    color: #313342;
    background: #fff;
    border: 1px solid #e5e3ea;
}

.trust-row {
    display: flex;
    gap: 18px;
    margin-top: 30px;
    color: #8b8d98;
    font-size: 10px;
}

.trust-row strong {
    color: #27bd73;
    margin-right: 5px;
}


/* HERO IMAGE */

.site-hero-image {
    position: relative;
    height: 450px;
    display: flex;
    justify-content: flex-end;
    align-items: center;
}

.site-hero-image img {
    width: 80%;
    height: 430px;
    object-fit: cover;
    border-radius: 30px 30px 80px 30px;
    transform: rotate(2deg);
    box-shadow: 0 35px 70px rgba(20,15,50,.2);
    position: relative;
    z-index: 2;
}

.image-backdrop {
    position: absolute;
    width: 80%;
    height: 430px;
    border-radius: 30px;
    background: linear-gradient(135deg,#6e39ff,#ef4d8c);
    right: 1%;
    top: 6%;
    transform: rotate(-4deg);
    opacity: .65;
}

.floating-card {
    position: absolute;
    z-index: 4;
    background: rgba(255,255,255,.94);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255,255,255,.8);
    box-shadow: 0 20px 45px rgba(30,20,60,.16);
    border-radius: 14px;
    padding: 13px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.floating-card strong {
    display: block;
    font-size: 12px;
}

.floating-card span {
    display: block;
    margin-top: 3px;
    color: #92949e;
    font-size: 9px;
}

.rating-card {
    left: 0;
    top: 90px;
}

.rating-icon {
    width: 32px;
    height: 32px;
    border-radius: 9px;
    display: grid;
    place-items: center;
    color: #fff;
    background: linear-gradient(135deg,#ffae37,#ff5e5e);
}

.verified-card {
    right: -10px;
    bottom: 40px;
}

.verified-check {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    background: #d9fae7;
    color: #1ab86b;
    font-weight: 900;
}


/* STATS */

.site-stats {
    display: grid;
    grid-template-columns: repeat(4,1fr);
    padding: 35px 60px;
    background: #151827;
    color: #fff;
}

.site-stats div {
    text-align: center;
    border-right: 1px solid rgba(255,255,255,.1);
}

.site-stats div:last-child {
    border: 0;
}

.site-stats strong {
    display: block;
    font-family: "Plus Jakarta Sans",sans-serif;
    font-size: 20px;
}

.site-stats span {
    color: #9498a8;
    font-size: 9px;
    margin-top: 5px;
    display: block;
}


/* ABOUT */

.site-about {
    padding: 90px 70px;
    display: grid;
    grid-template-columns: .9fr 1.1fr;
    gap: 80px;
    align-items: center;
}

.about-image {
    position: relative;
}

.about-image img {
    width: 100%;
    height: 390px;
    object-fit: cover;
    border-radius: 24px;
    box-shadow: 0 25px 60px rgba(25,20,50,.13);
}

.experience-badge {
    position: absolute;
    right: -20px;
    bottom: 25px;
    background: #fff;
    padding: 17px 21px;
    border-radius: 14px;
    box-shadow: 0 15px 40px rgba(20,20,50,.15);
}

.experience-badge strong,
.experience-badge span {
    display: block;
}

.experience-badge strong {
    color: #743eff;
    font-size: 14px;
}

.experience-badge span {
    font-size: 8px;
    letter-spacing: 1px;
    color: #999ba5;
    margin-top: 3px;
}

.site-about h2,
.services-heading h2,
.site-cta h2 {
    font-family: "Plus Jakarta Sans",sans-serif;
    font-size: 38px;
    line-height: 1.08;
    letter-spacing: -2px;
    margin: 15px 0;
}

.site-about p {
    color: #7d7f8b;
    line-height: 1.9;
    font-size: 13px;
}

.about-list {
    margin-top: 25px;
    display: grid;
    gap: 12px;
}

.about-list div {
    font-size: 12px;
    font-weight: 700;
}

.about-list span {
    color: #fff;
    background: #713dff;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    display: inline-grid;
    place-items: center;
    margin-right: 8px;
}


/* SERVICES */

.site-services {
    padding: 85px 70px;
    background: #f8f6ff;
}

.services-heading {
    display: flex;
    justify-content: space-between;
    gap: 50px;
    align-items: end;
    margin-bottom: 40px;
}

.services-heading h2 {
    max-width: 550px;
    margin-bottom: 0;
}

.services-heading p {
    color: #8a8b96;
    max-width: 350px;
    font-size: 12px;
    line-height: 1.8;
}

.service-grid {
    display: grid;
    grid-template-columns: repeat(4,1fr);
    gap: 15px;
}

.service-card {
    position: relative;
    min-height: 290px;
    padding: 25px;
    background: #fff;
    border: 1px solid #ebe9f2;
    border-radius: 18px;
    overflow: hidden;
    transition: .35s;
}

.service-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 25px 50px rgba(70,45,140,.13);
    border-color: #d9ccff;
}

.service-number {
    position: absolute;
    top: 20px;
    right: 20px;
    color: #d9d6e5;
    font-size: 10px;
    font-weight: 800;
}

.service-icon {
    width: 47px;
    height: 47px;
    border-radius: 14px;
    display: grid;
    place-items: center;
    color: #fff;
    font-size: 19px;
    background: linear-gradient(135deg,#7138ff,#e64893);
    box-shadow: 0 10px 22px rgba(113,56,255,.2);
}

.service-card h3 {
    font-family: "Plus Jakarta Sans",sans-serif;
    font-size: 16px;
    margin: 23px 0 10px;
}

.service-card p {
    color: #92939e;
    line-height: 1.7;
    font-size: 11px;
    min-height: 65px;
}

.service-card a {
    color: #7138ff;
    font-size: 10px;
    font-weight: 800;
    text-decoration: none;
}


/* CTA */

.site-cta {
    position: relative;
    overflow: hidden;
    margin: 70px;
    padding: 55px 60px;
    border-radius: 25px;
    color: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background:
        radial-gradient(circle at 80% 0%,rgba(255,91,160,.7),transparent 30%),
        linear-gradient(120deg,#5530d9,#8b3bdc 55%,#ed527e);
    box-shadow: 0 30px 70px rgba(105,50,220,.2);
}

.cta-shape {
    position: absolute;
    width: 300px;
    height: 300px;
    border: 1px solid rgba(255,255,255,.15);
    border-radius: 50%;
    right: -100px;
    bottom: -160px;
}

.site-cta .mini-label {
    color: rgba(255,255,255,.7);
}

.site-cta h2 {
    max-width: 600px;
    font-size: 31px;
    margin: 13px 0 7px;
}

.site-cta p {
    color: rgba(255,255,255,.7);
    font-size: 11px;
}

.site-cta button {
    position: relative;
    z-index: 2;
    white-space: nowrap;
    border: 0;
    border-radius: 10px;
    padding: 14px 19px;
    background: #fff;
    color: #6034d7;
    font-weight: 800;
    cursor: pointer;
}


/* FOOTER */

.site-footer {
    min-height: 80px;
    padding: 0 55px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #858793;
    font-size: 10px;
    border-top: 1px solid #eeeef2;
}

.site-footer strong {
    color: #202332;
}


/* FOOTER */

.lswg-footer {
    min-height: 80px;
    padding: 20px 50px;
    border-top: 1px solid #e8e7ed;
    background: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: #8b8d97;
    font-size: 11px;
}

.lswg-footer strong {
    color: #242635;
    margin-right: 10px;
}

.lswg-footer code {
    color: #6e3cff;
}


/* =========================================================
   RESPONSIVE
   ========================================================= */

@media (max-width: 900px) {

    .lswg-topbar {
        padding: 0 20px;
    }

    .lswg-status {
        display: none;
    }

    .lswg-hero-content {
        max-width: calc(100% - 40px);
    }

    .lswg-builder-wrap {
        padding: 35px 15px;
    }

    .lswg-builder-card {
        padding: 25px;
    }

    .lswg-form-grid {
        grid-template-columns: 1fr;
    }

    .lswg-result {
        max-width: calc(100% - 30px);
    }

    .site-hero {
        grid-template-columns: 1fr;
        padding: 50px 35px;
    }

    .site-hero-image {
        margin-top: 30px;
    }

    .site-stats {
        grid-template-columns: 2fr 2fr;
        gap: 25px;
    }

    .site-stats div:nth-child(2) {
        border-right: 0;
    }

    .site-about {
        grid-template-columns: 1fr;
        padding: 60px 35px;
    }

    .site-services {
        padding: 60px 35px;
    }

    .service-grid {
        grid-template-columns: 1fr 1fr;
    }

    .site-cta {
        margin: 35px;
    }

    .site-nav-links {
        display: none;
    }
}

@media (max-width: 600px) {

    .lswg-topbar {
        height: 65px;
    }

    .lswg-preview-btn {
        display: none;
    }

    .lswg-hero {
        min-height: 430px;
    }

    .lswg-hero h1 {
        font-size: 43px;
        letter-spacing: -2.5px;
    }

    .lswg-builder-heading,
    .result-heading {
        display: block;
    }

    .secure-badge,
    .ready-badge {
        display: inline-block;
        margin-top: 15px;
    }

    .lswg-shortcode {
        display: block;
    }

    .lswg-shortcode > div {
        display: block;
    }

    #lswg-copy {
        margin-top: 10px;
    }

    .site-hero {
        padding: 40px 22px;
    }

    .site-hero h1 {
        font-size: 47px;
    }

    .site-hero-image {
        height: 350px;
    }

    .site-hero-image img,
    .image-backdrop {
        height: 330px;
        width: 85%;
    }

    .trust-row {
        flex-wrap: wrap;
    }

    .site-stats {
        padding: 30px 20px;
    }

    .site-about {
        padding: 50px 22px;
        gap: 45px;
    }

    .site-about h2,
    .services-heading h2 {
        font-size: 31px;
    }

    .site-services {
        padding: 50px 22px;
    }

    .services-heading {
        display: block;
    }

    .service-grid {
        grid-template-columns: 1fr;
    }

    .site-cta {
        margin: 22px;
        padding: 35px 25px;
        display: block;
    }

    .site-cta button {
        margin-top: 20px;
    }

    .site-footer {
        padding: 20px;
        display: block;
    }
}

/* KEYWORD TAGS PREVIEW */
.lswg-keyword-capsules {
    margin-top: 12px;
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.lswg-keyword-capsules span {
    background: #ebf8ff;
    color: #2b6cb0;
    border: 1px solid #bee3f8;
    padding: 6px 14px;
    border-radius: 50px;
    font-size: 12px;
    font-weight: 600;
    box-shadow: 0 2px 4px rgba(43, 108, 176, 0.05);
    transition: all 0.2s ease;
}

.lswg-keyword-capsules span:hover {
    transform: translateY(-1px);
    box-shadow: 0 4px 8px rgba(43, 108, 176, 0.1);
}

/* Animated floating image effects */
@keyframes lswgImageFloat {
    0%, 100% {
        transform: translateY(0) rotate(0deg);
    }
    50% {
        transform: translateY(-10px) rotate(1deg);
    }
}

.presence-image-wrap img,
.cta-banner-image img,
.about-image img,
.site-hero-image img {
    animation: lswgImageFloat 6s ease-in-out infinite;
    transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.4s ease, filter 0.4s ease !important;
}

.presence-image-wrap img:hover,
.cta-banner-image img:hover,
.about-image img:hover,
.site-hero-image img:hover {
    animation-play-state: paused;
    transform: scale(1.03) translateY(-12px) !important;
    box-shadow: 0 30px 60px rgba(117, 53, 255, 0.18) !important;
}

/* Vispan Premium Design Overrides */
.website-frame {
    background: radial-gradient(circle at 10% 20%, rgba(117, 53, 255, 0.03) 0%, rgba(255, 255, 255, 0) 50%),
                radial-gradient(circle at 90% 80%, rgba(255, 51, 119, 0.03) 0%, rgba(255, 255, 255, 0) 50%),
                #ffffff !important;
}

.primary-btn,
.site-nav-button {
    background: linear-gradient(135deg, #7535ff 0%, #ff3377 100%) !important;
    border: none !important;
    color: #ffffff !important;
    font-weight: 700 !important;
    letter-spacing: -0.2px !important;
    box-shadow: 0 10px 25px rgba(117, 53, 255, 0.25) !important;
    transition: all 0.35s cubic-bezier(0.16, 1, 0.3, 1) !important;
}

.primary-btn:hover,
.site-nav-button:hover {
    transform: translateY(-3px) scale(1.02) !important;
    box-shadow: 0 15px 35px rgba(117, 53, 255, 0.4) !important;
}

.sub-service-card {
    background: rgba(255, 255, 255, 0.75) !important;
    backdrop-filter: blur(16px);
    border: 1px solid rgba(117, 53, 255, 0.08) !important;
    box-shadow: 0 15px 35px rgba(15, 17, 36, 0.03) !important;
}

.sub-service-card:hover {
    border-color: rgba(117, 53, 255, 0.25) !important;
    box-shadow: 0 25px 50px rgba(117, 53, 255, 0.12) !important;
}

.spg-hero-card {
    background: rgba(255, 255, 255, 0.85) !important;
    backdrop-filter: blur(20px);
    border: 1px solid rgba(117, 53, 255, 0.1) !important;
    box-shadow: 0 35px 80px rgba(15, 17, 36, 0.14) !important;
    border-radius: 12px !important;
}

.spg-input {
    border: 1px solid rgba(117, 53, 255, 0.15) !important;
    transition: all 0.3s ease !important;
}

.spg-input:focus {
    border-color: #7535ff !important;
    box-shadow: 0 0 0 4px rgba(117, 53, 255, 0.1) !important;
}

.testimonial-slide {
    background: rgba(255, 255, 255, 0.7) !important;
    backdrop-filter: blur(12px);
    border: 1px solid rgba(117, 53, 255, 0.06) !important;
    box-shadow: 0 15px 35px rgba(15, 17, 36, 0.02) !important;
}

/* Admin Dashboard Extra Animations */
@keyframes lswgPulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.7; transform: scale(0.97); }
}

.secure-badge {
    animation: lswgPulse 2.5s infinite ease-in-out;
}

@keyframes lswgGradientShift {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.lswg-generate {
    background: linear-gradient(135deg, #7535ff, #cf42b8, #fa6149, #7535ff) !important;
    background-size: 300% 300% !important;
    animation: lswgGradientShift 4s infinite linear !important;
}

.lswg-field {
    transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}

.lswg-field:hover {
    transform: translateY(-2px);
}

/* =========================================================
   CSV BULK IMPORT & SUBMENU STYLES
   ========================================================= */

.lswg-csv-upload-zone {
    margin-top: 25px;
    border: 2px dashed #d1d5db;
    border-radius: 14px;
    padding: 50px 30px;
    text-align: center;
    background: #f8fafc;
    cursor: pointer;
    transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.lswg-csv-upload-zone:hover,
.lswg-csv-upload-zone.dragover {
    border-color: #6c38ff;
    background: #f5f3ff;
    box-shadow: 0 10px 25px rgba(108, 56, 255, 0.04);
}

.lswg-csv-upload-zone .upload-icon {
    font-size: 42px;
    margin-bottom: 12px;
    display: inline-block;
}

.lswg-csv-upload-zone h3 {
    margin: 10px 0 5px;
    font-size: 17px;
    font-weight: 700;
    font-family: "Plus Jakarta Sans", sans-serif;
    color: #1e293b;
}

.lswg-csv-upload-zone p {
    margin: 0;
    font-size: 13px;
    color: #64748b;
}

.lswg-template-link {
    transition: color 0.2s ease;
}

.lswg-template-link:hover {
    color: #4f46e5 !important;
    text-decoration: underline !important;
}

.lswg-preview-table-wrap th {
    font-family: "Plus Jakarta Sans", sans-serif;
}

.lswg-preview-table-wrap td {
    padding: 12px 15px;
    border-bottom: 1px solid #f1f5f9;
    color: #334155;
    white-space: nowrap;
}

.lswg-preview-table-wrap tr:last-child td {
    border-bottom: none;
}

#lswg-bulk-log::-webkit-scrollbar {
    width: 6px;
}
#lswg-bulk-log::-webkit-scrollbar-track {
    background: #1e293b;
}
#lswg-bulk-log::-webkit-scrollbar-thumb {
    background: #475569;
    border-radius: 3px;
}

CSS;
    }

    /* ---------------------------------------------------------
     * ADMIN JS
     * --------------------------------------------------------- */

    private function admin_js() {

        return <<<'JS'

jQuery(function($){

    const generateButton = $('#lswg-generate');
    const loading = $('#lswg-loading');
    const result = $('#lswg-result');



    /*
     * Generate website
     */
    generateButton.on('click', function(){

        const city = $('#lswg-city').val().trim();
        const service = $('#lswg-service').val().trim();

        if(!city || !service){

            alert('Please enter both City and Service.');

            if(!city){
                $('#lswg-city').focus();
            } else {
                $('#lswg-service').focus();
            }

            return;
        }

        generateButton.prop('disabled', true);
        generateButton.css('opacity','.65');

        loading.slideDown(250);

        const messages = [
            'Finding local information...',
            'Creating professional content...',
            'Preparing service sections...',
            'Selecting service imagery...',
            'Designing your website...',
            'Almost ready...'
        ];

        let i = 0;

        const interval = setInterval(function(){

            if(i < messages.length){

                $('#lswg-loading-text').text(messages[i]);

                i++;

            }

        }, 650);
        $.ajax({
            url: LSWG.ajax,
            type: 'POST',
            data: {
                action: 'lswg_generate',
                nonce: LSWG.nonce,
                city: city,
                service: service
            },
            success: function(response){
                clearInterval(interval);

                if(response.success){

                    $('#lswg-preview').html(response.data.html);

                    const badge = $('#lswg-source-badge');
                    if (badge.length) {
                        if (response.data.used_openai) {
                            badge.text('✦ Generated by OpenAI')
                                 .css({
                                     'background': '#f3e8ff',
                                     'color': '#7e22ce',
                                     'border-color': '#d8b4fe'
                                 }).show();
                        } else {
                            badge.text('✦ Local Engine Fallback')
                                 .css({
                                     'background': '#f1f5f9',
                                     'color': '#475569',
                                     'border-color': '#cbd5e1'
                                 }).show();
                        }
                    }

                    result.slideDown(500);

                    setTimeout(function(){

                        $('html,body').animate({
                            scrollTop: result.offset().top - 80
                        }, 700);

                    },300);

                } else {

                    alert(
                        response.data && response.data.message
                            ? response.data.message
                            : 'Something went wrong.'
                    );
                }

            },

            error: function(){

                clearInterval(interval);

                alert(
                    'Unable to generate the website. Please try again.'
                );

            },

            complete: function(){

                loading.slideUp(250);

                generateButton.prop('disabled', false);
                generateButton.css('opacity','1');

            }

        });

    });


    /*
     * Copy shortcode
     */
    $('#lswg-copy').on('click', function(){

        const button = $(this);

        navigator.clipboard.writeText(
            '[local_service_website]'
        );

        button.text('Copied ✓');

        setTimeout(function(){

            button.text('Copy');

        },2000);

    });


    /*
     * Publish WordPress page
     */
    $('#lswg-publish-btn').on('click', function(){
        const button = $(this);
        const city = $('#lswg-city').val().trim();
        const service = $('#lswg-service').val().trim();

        if(!city || !service){
            alert('Please enter both City and Service first.');
            return;
        }

        button.prop('disabled', true).css('opacity', '0.65');
        $('#lswg-publish-loading').css('display', 'flex');
        $('#lswg-publish-result').hide();

        $.ajax({
            url: LSWG.ajax,
            type: 'POST',
            data: {
                action: 'lswg_publish_page',
                nonce: LSWG.nonce,
                city: city,
                service: service
            },
            success: function(response){
                if(response.success){
                    $('#lswg-published-url').attr('href', response.data.url);
                    $('#lswg-publish-result').css('display', 'flex').slideDown(300);
                } else {
                    alert(response.data && response.data.message ? response.data.message : 'Failed to publish page.');
                }
            },
            error: function(){
                alert('Unable to publish page. Please try again.');
            },
            complete: function(){
                $('#lswg-publish-loading').hide();
                button.prop('disabled', false).css('opacity', '1');
            }
        });
    });


    /*
     * Preview scroll
     */
    $('#lswg-scroll-preview').on('click', function(){

        const target = $('#lswg-result');

        if(target.length){

            $('html,body').animate({
                scrollTop: target.offset().top - 80
            },600);

        }

    });


    /*
     * Enter key support
     */
    $('#lswg-city,#lswg-service').on('keypress',function(e){

        if(e.which === 13){

            generateButton.trigger('click');

        }

    });


    /* =========================================================
     * CSV BULK IMPORT FUNCTIONALITY
     * ========================================================= */
    let csvRows = [];
    let importIndex = 0;
    let importSuccess = 0;
    let importFailed = 0;
    let importCancelled = false;
    let isImporting = false;

    // Dropzone drag & drop events
    const dropzone = $('#lswg-csv-dropzone');
    const fileInput = $('#lswg-csv-file-input');

    if (dropzone.length) {
        dropzone.on('click', function(e) {
            if (isImporting) return;
            if (e.target.id === 'lswg-download-template') return;
            if (fileInput.length) {
                fileInput[0].click();
            }
        });

        dropzone.on('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            if (!isImporting) {
                dropzone.addClass('dragover');
            }
        });

        dropzone.on('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            dropzone.removeClass('dragover');
        });

        dropzone.on('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            dropzone.removeClass('dragover');
            if (isImporting) return;

            const files = e.originalEvent.dataTransfer.files;
            if (files.length) {
                handleCSVFile(files[0]);
            }
        });

        fileInput.on('change', function() {
            if (this.files.length) {
                handleCSVFile(this.files[0]);
            }
        });
    }

    // CSV Template Download
    $('#lswg-download-template').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        const csvContent = "data:text/csv;charset=utf-8,city,service,keywords\nRajkot,Plumber,\"best plumber, leak repair\"\nAhmedabad,Electrician,\"certified electrician, home wiring\"\nSurat,Tailor,\"wedding suit alterations\"\nBaroda,Dentist,\"pain-free root canal, dental checkup\"\nMumbai,Cleaning,\"deep house cleaning, maid service\"\nDelhi,Mechanic,\"car diagnostics, engine repair\"";
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "city_service_import_template.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });

    function handleCSVFile(file) {
        if (!file.name.endsWith('.csv')) {
            alert('Please select a valid CSV file.');
            return;
        }

        const reader = new FileReader();
        reader.onload = function(e) {
            const text = e.target.result;
            processCSVData(text, file.name, file.size);
        };
        reader.readAsText(file);
    }

    // RFC-4180 compliant CSV Parser
    function parseCSV(text) {
        let lines = [];
        let row = [""];
        let inQuotes = false;

        for (let i = 0; i < text.length; i++) {
            let c = text[i];
            let next = text[i+1];

            if (c === '"') {
                if (inQuotes && next === '"') {
                    row[row.length - 1] += '"';
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (c === ',' && !inQuotes) {
                row.push('');
            } else if ((c === '\r' || c === '\n') && !inQuotes) {
                if (c === '\r' && next === '\n') {
                    i++;
                }
                lines.push(row);
                row = [''];
            } else {
                row[row.length - 1] += c;
            }
        }
        if (row.length > 1 || row[0] !== '') {
            lines.push(row);
        }
        return lines;
    }

    function processCSVData(text, filename, size) {
        const lines = parseCSV(text);
        if (lines.length < 2) {
            alert('The CSV file is empty or lacks headers.');
            return;
        }

        const headers = lines[0].map(h => h.trim().toLowerCase());
        const cityIndex = headers.indexOf('city');
        const serviceIndex = headers.indexOf('service');
        const keywordsIndex = headers.indexOf('keywords');

        if (cityIndex === -1 || serviceIndex === -1) {
            alert("Error: The CSV file must contain 'city' and 'service' columns.");
            return;
        }

        csvRows = [];
        const previewTbody = $('#lswg-csv-preview-table tbody').empty();

        for (let i = 1; i < lines.length; i++) {
            const line = lines[i];
            if (line.length <= 1 && line[0] === '') continue;

            const city = line[cityIndex] ? line[cityIndex].trim() : '';
            const service = line[serviceIndex] ? line[serviceIndex].trim() : '';
            const keywords = keywordsIndex !== -1 && line[keywordsIndex] ? line[keywordsIndex].trim() : '';

            if (city && service) {
                csvRows.push({ city, service, keywords });

                if (csvRows.length <= 5) {
                    previewTbody.append(`
                        <tr style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding: 10px 15px;">${escapeHtml(city)}</td>
                            <td style="padding: 10px 15px;">${escapeHtml(service)}</td>
                            <td style="padding: 10px 15px; color:#8c8f9c;">${escapeHtml(keywords || '-')}</td>
                        </tr>
                    `);
                }
            }
        }

        if (csvRows.length === 0) {
            alert('No valid rows found in the CSV file.');
            return;
        }

        $('#lswg-file-name').text(filename);
        $('#lswg-file-size').text('(' + Math.round(size / 1024 * 100) / 100 + ' KB)');
        $('#lswg-row-count').text(csvRows.length + ' rows detected');
        $('#lswg-csv-preview-card').slideDown(300);
        $('#lswg-bulk-progress-card').hide();
        $('#lswg-csv-results-card').hide();
        $('#lswg-csv-results-table tbody').empty();
    }

    function escapeHtml(str) {
        return str
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    // Start Bulk Import
    $('#lswg-start-bulk').on('click', function() {
        if (csvRows.length === 0 || isImporting) return;

        isImporting = true;
        importIndex = 0;
        importSuccess = 0;
        importFailed = 0;
        importCancelled = false;

        $('#lswg-start-bulk').prop('disabled', true).css('opacity', '0.65');
        $('#lswg-bulk-progress-card').slideDown(300);
        $('#lswg-bulk-log').empty();

        logBulkMsg('Starting bulk page generation...', 'system');
        logBulkMsg(`Queue size: ${csvRows.length} items.`, 'system');

        updateBulkProgress();
        processNextCSVRow();
    });

    // Cancel Bulk Import
    $('#lswg-cancel-bulk').on('click', function(e) {
        e.preventDefault();
        if (!isImporting) return;
        importCancelled = true;
        logBulkMsg('Cancellation request received. Halting operation after current item...', 'error');
    });

    function logBulkMsg(msg, type = 'info') {
        const log = $('#lswg-bulk-log');
        if (!log.length) return;

        let color = '#f1f5f9';
        if (type === 'success') color = '#4ade80';
        if (type === 'error') color = '#f87171';
        if (type === 'system') color = '#a78bfa';

        const time = new Date().toLocaleTimeString();
        log.append(`<div style="color:${color}; margin-bottom:4px;">[${time}] ${msg}</div>`);
        log.scrollTop(log[0].scrollHeight);
    }

    function updateBulkProgress() {
        const processed = importSuccess + importFailed;
        const total = csvRows.length;
        const percent = Math.round((processed / total) * 100);

        $('#lswg-progress-percent').text(percent + '%');
        $('#lswg-progress-bar').css('width', percent + '%');
        $('#lswg-stat-success').text(importSuccess);
        $('#lswg-stat-failed').text(importFailed);
        $('#lswg-stat-remaining').text(total - processed);
    }

    function processNextCSVRow() {
        if (importCancelled) {
            logBulkMsg('Bulk generation cancelled by user.', 'error');
            completeBulkImport();
            return;
        }

        if (importIndex >= csvRows.length) {
            logBulkMsg('Bulk generation operation completed successfully!', 'success');
            completeBulkImport();
            return;
        }

        const row = csvRows[importIndex];
        logBulkMsg(`Generating page ${importIndex + 1}/${csvRows.length}: ${row.service} in ${row.city}...`, 'info');

        $.ajax({
            url: LSWG.ajax,
            type: 'POST',
            data: {
                action: 'lswg_publish_page',
                nonce: LSWG.nonce,
                city: row.city,
                service: row.service,
                keywords: row.keywords
            },
            success: function(response) {
                if (response.success) {
                    importSuccess++;
                    const sourceText = response.data.used_openai ? 'OpenAI' : 'Local Fallback';
                    logBulkMsg(`[SUCCESS] Published: "Best ${row.service} in ${row.city}" (${sourceText})`, 'success');
                    
                    $('#lswg-csv-results-card').show();
                    $('#lswg-csv-results-table tbody').append(`
                        <tr style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding: 10px 15px; font-weight: 600;">Best ${escapeHtml(row.service)} in ${escapeHtml(row.city)}</td>
                            <td style="padding: 10px 15px; text-align: right;">
                                <a href="${response.data.url}" target="_blank" style="color: #6c38ff; font-weight: 700; text-decoration: none;">View Page &rarr;</a>
                            </td>
                        </tr>
                    `);
                } else {
                    importFailed++;
                    const reason = response.data && response.data.message ? response.data.message : 'Unknown error';
                    logBulkMsg(`[FAILED] ${row.service} in ${row.city}: ${reason}`, 'error');
                }
            },
            error: function() {
                importFailed++;
                logBulkMsg(`[FAILED] ${row.service} in ${row.city}: AJAX communication error.`, 'error');
            },
            complete: function() {
                updateBulkProgress();
                importIndex++;
                setTimeout(processNextCSVRow, 150);
            }
        });
    }

    function completeBulkImport() {
        isImporting = false;
        $('#lswg-start-bulk').prop('disabled', false).css('opacity', '1');
        logBulkMsg(`Session Finished. Success: ${importSuccess}, Failed: ${importFailed}.`, 'system');
    }

    /*
     * Explicit Choose CSV File button click handler
     */
    $('#lswg-csv-select-btn').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        if (isImporting) return;
        const inputNode = $('#lswg-csv-file-input');
        if (inputNode.length) {
            inputNode[0].click();
        }
    });

    /* =========================================================
     * CITY DATABASE AJAX CRUD
     * ========================================================= */
    const cityPanel = $('#lswg-city-form-panel');
    const cityNameInput = $('#lswg-city-name');
    const cityAddressInput = $('#lswg-city-address');
    const cityIdInput = $('#lswg-city-id');

    $('#lswg-add-city-btn').on('click', function() {
        $('#lswg-city-form-title').text('Add New City');
        cityIdInput.val('');
        cityNameInput.val('');
        cityAddressInput.val('');
        cityPanel.slideDown(250);
    });

    $('#lswg-cancel-city-btn').on('click', function(e) {
        e.preventDefault();
        cityPanel.slideUp(250);
    });

    $(document).on('click', '.lswg-edit-city-btn', function() {
        const row = $(this).closest('tr');
        const id = row.data('id');
        const city = row.data('city');
        const address = row.data('address');

        $('#lswg-city-form-title').text('Edit City: ' + city);
        cityIdInput.val(id);
        cityNameInput.val(city);
        cityAddressInput.val(address);
        cityPanel.slideDown(250);
        
        $('html,body').animate({
            scrollTop: cityPanel.offset().top - 80
        }, 300);
    });

    $('#lswg-save-city-btn').on('click', function() {
        const id = cityIdInput.val();
        const city = cityNameInput.val().trim();
        const address = cityAddressInput.val().trim();

        if (!city || !address) {
            alert('Please fill in both City Name and Address.');
            return;
        }

        const button = $(this);
        button.prop('disabled', true).css('opacity', '0.6');

        $.ajax({
            url: LSWG.ajax,
            type: 'POST',
            data: {
                action: 'lswg_save_city',
                nonce: LSWG.nonce,
                id: id,
                city: city,
                address: address
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error saving city.');
                    button.prop('disabled', false).css('opacity', '1');
                }
            },
            error: function() {
                alert('Error saving city. Please try again.');
                button.prop('disabled', false).css('opacity', '1');
            }
        });
    });

    $(document).on('click', '.lswg-delete-city-btn', function() {
        const row = $(this).closest('tr');
        const id = row.data('id');
        const city = row.data('city');

        if (!confirm('Are you sure you want to delete ' + city + ' from the database?')) {
            return;
        }

        $.ajax({
            url: LSWG.ajax,
            type: 'POST',
            data: {
                action: 'lswg_delete_city',
                nonce: LSWG.nonce,
                id: id
            },
            success: function(response) {
                if (response.success) {
                    row.fadeOut(300, function() {
                        row.remove();
                        if ($('#lswg-city-table-body tr').length === 0) {
                            location.reload();
                        }
                    });
                } else {
                    alert(response.data.message || 'Error deleting city.');
                }
            },
            error: function() {
                alert('Error deleting city. Please try again.');
            }
        });
    });

    /* =========================================================
     * TEMPLATES CRUD AJAX
     * ========================================================= */
    const templatePanel = $('#lswg-template-form-panel');
    const templateNameInput = $('#lswg-template-name');
    const templateHtmlInput = $('#lswg-template-html');
    const templateIdInput = $('#lswg-template-id');

    $('#lswg-add-template-btn').on('click', function() {
        $('#lswg-template-form-title').text('Add Custom Template');
        templateIdInput.val('');
        templateNameInput.val('');
        templateHtmlInput.val('');
        templatePanel.slideDown(250);
    });

    $('#lswg-cancel-template-btn').on('click', function(e) {
        e.preventDefault();
        templatePanel.slideUp(250);
    });

    $(document).on('click', '.lswg-edit-template-btn', function() {
        const item = $(this).closest('.lswg-template-item');
        const id = item.data('id');
        const name = item.data('name');
        const html = item.find('.lswg-raw-html').val();

        $('#lswg-template-form-title').text('Edit Template: ' + name);
        templateIdInput.val(id);
        templateNameInput.val(name);
        templateHtmlInput.val(html);
        templatePanel.slideDown(250);
        
        $('html,body').animate({
            scrollTop: templatePanel.offset().top - 80
        }, 300);
    });

    $('#lswg-save-template-btn').on('click', function() {
        const id = templateIdInput.val();
        const name = templateNameInput.val().trim();
        const html = templateHtmlInput.val().trim();

        if (!name || !html) {
            alert('Please fill in both Template Name and HTML Code.');
            return;
        }

        const button = $(this);
        button.prop('disabled', true).css('opacity', '0.6');

        $.ajax({
            url: LSWG.ajax,
            type: 'POST',
            data: {
                action: 'lswg_save_template',
                nonce: LSWG.nonce,
                id: id,
                name: name,
                html: html
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error saving template.');
                    button.prop('disabled', false).css('opacity', '1');
                }
            },
            error: function() {
                alert('Error saving template. Please try again.');
                button.prop('disabled', false).css('opacity', '1');
            }
        });
    });

    $(document).on('click', '.lswg-activate-template-btn', function() {
        const item = $(this).closest('.lswg-template-item');
        const id = item.data('id');
        const name = item.data('name');
        const button = $(this);
        
        button.prop('disabled', true).css('opacity', '0.6');

        $.ajax({
            url: LSWG.ajax,
            type: 'POST',
            data: {
                action: 'lswg_activate_template',
                nonce: LSWG.nonce,
                id: id
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message || 'Error activating template.');
                    button.prop('disabled', false).css('opacity', '1');
                }
            },
            error: function() {
                alert('Error activating template. Please try again.');
                button.prop('disabled', false).css('opacity', '1');
            }
        });
    });

    $(document).on('click', '.lswg-delete-template-btn', function() {
        const item = $(this).closest('.lswg-template-item');
        const id = item.data('id');
        const name = item.data('name');

        if (!confirm('Are you sure you want to delete template "' + name + '"?')) {
            return;
        }

        $.ajax({
            url: LSWG.ajax,
            type: 'POST',
            data: {
                action: 'lswg_delete_template',
                nonce: LSWG.nonce,
                id: id
            },
            success: function(response) {
                if (response.success) {
                    item.fadeOut(300, function() {
                        item.remove();
                        location.reload();
                    });
                } else {
                    alert(response.data.message || 'Error deleting template.');
                }
            },
            error: function() {
                alert('Error deleting template. Please try again.');
            }
        });
    });

    /* =========================================================
     * OPENAI STATUS & DIAGNOSTICS AJAX
     * ========================================================= */
    $('#lswg-save-openai-settings-btn').on('click', function() {
        const apiKey = $('#lswg-openai-key-input').val().trim();
        const button = $(this);

        button.prop('disabled', true).css('opacity', '0.6');

        $.ajax({
            url: LSWG.ajax,
            type: 'POST',
            data: {
                action: 'lswg_save_openai_settings',
                nonce: LSWG.nonce,
                api_key: apiKey
            },
            success: function(response) {
                if (response.success) {
                    alert('OpenAI API settings saved successfully!');
                    location.reload();
                } else {
                    alert(response.data.message || 'Error saving settings.');
                    button.prop('disabled', false).css('opacity', '1');
                }
            },
            error: function() {
                alert('Error saving settings. Please try again.');
                button.prop('disabled', false).css('opacity', '1');
            }
        });
    });

    $('#lswg-test-openai-connection-btn').on('click', function() {
        const apiKey = $('#lswg-openai-key-input').val().trim();
        const button = $(this);

        if (!apiKey) {
            alert('Please enter an OpenAI API Key first.');
            return;
        }

        button.prop('disabled', true).text('Testing Connection...');

        $.ajax({
            url: LSWG.ajax,
            type: 'POST',
            data: {
                action: 'lswg_test_openai_connection',
                nonce: LSWG.nonce,
                api_key: apiKey
            },
            success: function(response) {
                if (response.success) {
                    $('#lswg-diag-status').text('Healthy (Live)').css('color', '#2fbe75');
                    $('#lswg-diag-latency').text(response.data.latency + ' ms');
                    $('#lswg-diag-model').text(response.data.model + ' (Live)');
                    
                    $('#lswg-header-status').css({
                        'background': '#e8f9f0',
                        'color': '#2fbe75',
                        'border-color': '#c2f0d5'
                    });
                    $('#lswg-header-status i').css('background', '#2fbe75');
                    $('#lswg-status-text').text('Engine Operational');
                    $('#lswg-openai-mode-desc').text('Live OpenAI Mode is active. API charges apply to your account.');

                    alert('Connection successful! Latency: ' + response.data.latency + 'ms');
                } else {
                    $('#lswg-diag-status').text('Connection Failed').css('color', '#ef4444');
                    $('#lswg-diag-latency').text('-- ms');
                    
                    $('#lswg-header-status').css({
                        'background': '#fef2f2',
                        'color': '#ef4444',
                        'border-color': '#fca5a5'
                    });
                    $('#lswg-header-status i').css('background', '#ef4444');
                    $('#lswg-status-text').text('Engine Connection Error');

                    alert(response.data.message || 'Connection failed.');
                }
            },
            error: function() {
                alert('Diagnostics run failed. Please try again.');
            },
            complete: function() {
                button.prop('disabled', false).text('Run Connection Diagnostics');
            }
        });
    });

    /* =========================================================
     * TEMPLATE IMPORT FROM JSON FILE
     * ========================================================= */
    $('#lswg-import-json-input').on('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function(evt) {
            try {
                const data = JSON.parse(evt.target.result);
                if (!data.name || !data.html) {
                    alert('Invalid template JSON file. The JSON must contain "name" and "html" keys.');
                    return;
                }

                $.ajax({
                    url: LSWG.ajax,
                    type: 'POST',
                    data: {
                        action: 'lswg_save_template',
                        nonce: LSWG.nonce,
                        id: '', // New template
                        name: data.name,
                        html: data.html
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('Template imported successfully from JSON!');
                            location.reload();
                        } else {
                            alert(response.data.message || 'Error saving template.');
                        }
                    },
                    error: function() {
                        alert('Error saving template. Please check the network connection.');
                    }
                });
            } catch(err) {
                alert('Error parsing JSON file. Please ensure it is a valid JSON file.');
            }
        };
        reader.readAsText(file);
        // Clear input to allow uploading the same file again
        $(this).val('');
    });

});

JS;
    }
}

class LSWG_Seeded_Random {
    private $seed;
    
    public function __construct($seed_string) {
        $this->seed = abs(crc32(strtolower(trim($seed_string))));
    }
    
    public function rand($min, $max) {
        if ($min === $max) return $min;
        $this->seed = ($this->seed * 1103515245 + 12345) & 0x7fffffff;
        return $min + ($this->seed % ($max - $min + 1));
    }
    
    public function pick($array) {
        if (empty($array)) return null;
        $idx = $this->rand(0, count($array) - 1);
        return $array[$idx];
    }
    
    public function shuffle($array) {
        $shuffled = $array;
        $len = count($shuffled);
        for ($i = $len - 1; $i > 0; $i--) {
            $j = $this->rand(0, $i);
            $temp = $shuffled[$i];
            $shuffled[$i] = $shuffled[$j];
            $shuffled[$j] = $temp;
        }
        return $shuffled;
    }
}

LSWG_Local_Service_Generator::get_instance();