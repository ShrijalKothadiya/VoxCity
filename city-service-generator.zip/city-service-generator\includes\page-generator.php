<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once plugin_dir_path( __FILE__ ) . 'template-engine.php';

function csg_handle_page_generation() {
	if ( isset( $_POST['csg_generate_page'] ) && check_admin_referer( 'csg_generate_nonce', 'csg_nonce' ) ) {
		
		$city    = sanitize_text_field( $_POST['csg_city'] );
		$service = sanitize_text_field( $_POST['csg_service'] );

		if ( empty( $city ) || empty( $service ) ) {
			add_action( 'admin_notices', function() {
				echo '<div class="notice notice-error"><p>Please fill in both City and Service fields.</p></div>';
			});
			return;
		}

		$title = ucfirst( $service ) . ' in ' . ucfirst( $city );
		$slug  = sanitize_title( $service . '-' . $city );

		// Render the full landing page content
		$page_content = CSG_Template_Engine::render( $service, $city );

		// Check if page exists already
		$existing_page = get_page_by_path( $slug, OBJECT, 'page' );

		$post_data = array(
			'post_title'   => $title,
			'post_content' => $page_content,
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_name'    => $slug,
		);

		if ( $existing_page ) {
			$post_data['ID'] = $existing_page->ID;
			$page_id = wp_update_post( $post_data );
			$message = 'Page updated successfully!';
		} else {
			$page_id = wp_insert_post( $post_data );
			$message = 'Page generated and published successfully!';
		}

		if ( ! is_wp_error( $page_id ) ) {
			$permalink = get_permalink( $page_id );
			add_action( 'admin_notices', function() use ( $message, $permalink ) {
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . ' <a href="' . esc_url( $permalink ) . '" target="_blank">View Generated Page &rarr;</a></p></div>';
			});
		}
	}
}
add_action( 'admin_init', 'csg_handle_page_generation' );