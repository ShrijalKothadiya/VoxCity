document.addEventListener('DOMContentLoaded', () => {
    // 1. Smooth scroll for menu links
    document.querySelectorAll('.spg-nav a[href^="#"], .site-nav-links span[data-target]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href') || ('#' + this.getAttribute('data-target'));
            const target = document.querySelector(targetId);
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });

    // 2. Testimonial slider functionality
    const initTestimonialSlider = () => {
        const sliders = document.querySelectorAll('.testimonials-slider');
        sliders.forEach(slider => {
            const slides = slider.querySelectorAll('.testimonial-slide');
            if (slides.length <= 1) return;

            let current = 0;
            let slideInterval;

            // Set initial state
            slides.forEach((slide, idx) => {
                slide.style.display = idx === 0 ? 'block' : 'none';
                slide.style.opacity = idx === 0 ? '1' : '0';
                slide.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
                slide.style.transform = idx === 0 ? 'translateY(0)' : 'translateY(15px)';
            });

            // Create dot navigation
            const dotsWrapper = document.createElement('div');
            dotsWrapper.className = 'testimonials-dots';
            dotsWrapper.style.display = 'flex';
            dotsWrapper.style.justifyContent = 'center';
            dotsWrapper.style.gap = '8px';
            dotsWrapper.style.marginTop = '25px';

            slides.forEach((_, idx) => {
                const dot = document.createElement('span');
                dot.className = `testimonial-dot ${idx === 0 ? 'active' : ''}`;
                dot.style.width = idx === 0 ? '24px' : '8px';
                dot.style.height = '8px';
                dot.style.borderRadius = '4px';
                dot.style.background = idx === 0 ? 'var(--lswg-primary)' : '#c0c3d0';
                dot.style.cursor = 'pointer';
                dot.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
                dot.addEventListener('click', () => showSlide(idx));
                dotsWrapper.appendChild(dot);
            });

            slider.appendChild(dotsWrapper);
            const dots = dotsWrapper.querySelectorAll('.testimonial-dot');

            const showSlide = (index) => {
                if (index === current) return;

                // Transition out current slide
                slides[current].style.opacity = '0';
                slides[current].style.transform = 'translateY(-15px)';
                dots[current].style.width = '8px';
                dots[current].style.background = '#c0c3d0';
                dots[current].classList.remove('active');

                const prevIndex = current;
                current = index;

                setTimeout(() => {
                    slides[prevIndex].style.display = 'none';

                    // Prepare next slide
                    slides[current].style.display = 'block';
                    slides[current].style.transform = 'translateY(15px)';

                    setTimeout(() => {
                        slides[current].style.opacity = '1';
                        slides[current].style.transform = 'translateY(0)';
                        dots[current].style.width = '24px';
                        dots[current].style.background = 'var(--lswg-primary)';
                        dots[current].classList.add('active');
                    }, 30);
                }, 400);
            };

            const startAutoplay = () => {
                slideInterval = setInterval(() => {
                    let next = (current + 1) % slides.length;
                    showSlide(next);
                }, 5000);
            };

            const stopAutoplay = () => {
                clearInterval(slideInterval);
            };

            startAutoplay();

            // Pause autoplay on hover
            slider.addEventListener('mouseenter', stopAutoplay);
            slider.addEventListener('mouseleave', startAutoplay);
        });
    };

    // 3. Scroll entry animations using Intersection Observer
    const initScrollAnimations = () => {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.1
        };

        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('lswg-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        const animElements = document.querySelectorAll(
            '.site-hero, .site-presence, .sub-service-card, .benefit-item, .portfolio-item-card, .site-why-us, .site-cta-banner, .site-testimonials, .site-consultation, .site-awards'
        );

        animElements.forEach(el => {
            el.classList.add('lswg-animate');
            observer.observe(el);
        });
    };

    // 4. Mouse follower animation for scroll indicator (circle dot)
    const initMouseFollower = () => {
        // Exit if this is not a generated landing page layout (missing website-frame)
        const frame = document.querySelector('.website-frame');
        if (!frame) return;

        let indicator = document.querySelector('.scroll-target-indicator');
        if (!indicator) {
            indicator = document.createElement('div');
            indicator.className = 'scroll-target-indicator';
            const dot = document.createElement('div');
            dot.className = 'scroll-target-dot';
            indicator.appendChild(dot);
            document.body.appendChild(indicator);
        } else {
            // Move to body to prevent absolute positioning bug inside transformed parents
            document.body.appendChild(indicator);
        }

        let mouseX = 0, mouseY = 0;
        let ballX = 0, ballY = 0;
        let hasMoved = false;

        // Hide default indicator by default until hover inside frame
        indicator.style.display = 'none';

        document.addEventListener('mousemove', (e) => {
            mouseX = e.clientX;
            mouseY = e.clientY;
            
            // Check if mouse is inside the generated website frame
            if (e.target.closest('.website-frame')) {
                indicator.style.display = 'flex';
                if (!hasMoved) {
                    hasMoved = true;
                    indicator.classList.add('cursor-active');
                }
            } else {
                indicator.style.display = 'none';
            }
        });

        const animate = () => {
            if (hasMoved) {
                // Smooth easing lag calculation
                let distX = mouseX - ballX;
                let distY = mouseY - ballY;

                ballX = ballX + (distX * 0.15);
                ballY = ballY + (distY * 0.15);

                indicator.style.left = ballX + 'px';
                indicator.style.top = ballY + 'px';
            }
            requestAnimationFrame(animate);
        };
        animate();

        // Hover effects on links/buttons
        const interactiveElements = document.querySelectorAll('a, button, select, input, textarea, .site-nav-links span, .advantage-tab-btn');
        interactiveElements.forEach(el => {
            el.addEventListener('mouseenter', () => {
                const dot = indicator.querySelector('.scroll-target-dot');
                if (dot) {
                    dot.style.transform = 'scale(1.8)';
                    dot.style.backgroundColor = 'var(--accent)';
                }
                indicator.style.borderColor = 'var(--accent)';
            });
            el.addEventListener('mouseleave', () => {
                const dot = indicator.querySelector('.scroll-target-dot');
                if (dot) {
                    dot.style.transform = 'scale(1)';
                    dot.style.backgroundColor = 'var(--navy)';
                }
                indicator.style.borderColor = 'rgba(2, 66, 106, 0.15)';
            });
        });
    };

    // 5. Advantages Tab Switching functionality
    const initAdvantagesTabs = () => {
        const tabButtons = document.querySelectorAll('.advantage-tab-btn');
        const tabPanels = document.querySelectorAll('.advantage-tab-panel');
        
        tabButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const targetTab = btn.getAttribute('data-tab');
                
                // Toggle active class on buttons
                tabButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                // Toggle active class on panels
                tabPanels.forEach(panel => {
                    if (panel.getAttribute('id') === targetTab) {
                        panel.classList.add('active');
                        panel.style.opacity = '0';
                        panel.style.transform = 'translateY(10px)';
                        setTimeout(() => {
                            panel.style.opacity = '1';
                            panel.style.transform = 'translateY(0)';
                            panel.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
                        }, 50);
                    } else {
                        panel.classList.remove('active');
                    }
                });
            });
        });
    };

    // Run initializations
    initTestimonialSlider();
    initScrollAnimations();
    initMouseFollower();
    initAdvantagesTabs();
});