<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CSG_Template_Engine {

	/**
	 * Render the template with dynamic values.
	 */
	public static function render( $service, $city ) {
		$template_path = plugin_dir_path( __FILE__ ) . '../templates/landing-page.php';

		if ( ! file_exists( $template_path ) ) {
			return '<p>Error: Landing page template not found.</p>';
		}

		// Buffer template file content
		ob_start();
		include $template_path;
		$content = ob_get_clean();

		// Replace placeholders
		$replacements = array(
			'{{service}}'             => esc_html( ucfirst( $service ) ),
			'{{city}}'                => esc_html( ucfirst( $city ) ),
			'{{meta_title}}'          => esc_html( "Best " . ucfirst( $service ) . " in " . ucfirst( $city ) ),
			'{{company_name_first}}'  => 'Vispan',
			'{{company_name_second}}' => 'Pro',
			'{{phone_number}}'        => '+91 98765 43210',
		);

		return str_replace( array_keys( $replacements ), array_values( $replacements ), $content );
	}
}