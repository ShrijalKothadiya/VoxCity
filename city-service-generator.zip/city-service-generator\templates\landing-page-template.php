<?php
/**
 * Template Name: LSWG Generated Landing Page
 * Description: Overrides the page template to load the full-screen landing page.
 */

if (!defined('ABSPATH')) {
    exit;
}

$page_id = get_queried_object_id();
if (empty($page_id)) {
    $page_id = get_the_ID();
}
$data = get_post_meta($page_id, '_lswg_data', true);

if (empty($data)) {
    // If page is loaded but data is missing, check the other meta keys as well
    $csg_city = get_post_meta($page_id, '_csg_city', true);
    $csg_service = get_post_meta($page_id, '_csg_service', true);
    if (!empty($csg_city) && !empty($csg_service)) {
        $generator = LSWG_Local_Service_Generator::get_instance();
        $data = $generator->collect_local_data($csg_city, $csg_service);
        $data['city'] = $csg_city;
        $data['service'] = $csg_service;
        $data['business_name'] = 'Professional ' . ucwords($csg_service) . ' in ' . $csg_city;
    }
}

if (empty($data)) {
    // If data is still missing, fall back to global options
    $data = get_option('lswg_generated_website', []);
}

$city = !empty($data['city']) ? esc_attr($data['city']) : '';
$service = !empty($data['service']) ? esc_attr($data['service']) : '';
$custom_keywords = !empty($data['keywords']) ? esc_attr($data['keywords']) : '';

// Generate SEO meta titles and descriptions dynamically
$seo_title = "Best " . ucfirst($service) . " in " . ucfirst($city) . " | Professional Local " . ucfirst($service) . " Services";
$seo_desc = "Looking for the best local " . esc_attr($service) . " in " . esc_attr($city) . "? Our certified " . esc_attr($service) . " specialists provide rapid response, affordable rates, and quality repairs. Contact us today!";

if (!empty($custom_keywords)) {
    $seo_keywords = $custom_keywords;
} else {
    $seo_keywords = esc_attr($service) . " in " . esc_attr($city) . ", best " . esc_attr($service) . " " . esc_attr($city) . ", local " . esc_attr($service) . " " . esc_attr($city) . ", professional " . esc_attr($service) . " " . esc_attr($city) . ", emergency " . esc_attr($service) . " " . esc_attr($city);
}

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title><?php echo esc_html($seo_title); ?></title>
    <meta name="description" content="<?php echo esc_attr($seo_desc); ?>">
    <meta name="keywords" content="<?php echo esc_attr($seo_keywords); ?>">
    
    <!-- Open Graph for Social Networks -->
    <meta property="og:title" content="<?php echo esc_attr($seo_title); ?>">
    <meta property="og:description" content="<?php echo esc_attr($seo_desc); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo esc_url(get_permalink()); ?>">
    
    <!-- LocalBusiness Schema JSON-LD Markup for Local SEO -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "<?php echo esc_attr(ucwords($service) . ' ' . ucwords($city)); ?>",
      "description": "<?php echo esc_attr($seo_desc); ?>",
      "telephone": "+91 98765 43210",
      "address": {
        "@type": "PostalAddress",
        "addressLocality": "<?php echo esc_attr(ucfirst($city)); ?>",
        "addressCountry": "IN"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": "22.3039",
        "longitude": "70.8022"
      },
      "url": "<?php echo esc_url(get_permalink()); ?>",
      "image": "<?php echo !empty($data['images'][0]) ? esc_url($data['images'][0]) : ''; ?>"
    }
    </script>
    
    <?php wp_head(); ?>
</head>
<body <?php body_class('lswg-landing-page-body'); ?>>

    <div id="lswg-frontend-root">
        <?php
        if (!empty($data)) {
            $generator = LSWG_Local_Service_Generator::get_instance();
            echo $generator->render_preview($data);
        } else {
            while (have_posts()) :
                the_post();
                the_content();
            endwhile;
        }
        ?>
    </div>

    <?php wp_footer(); ?>
</body>
</html>
