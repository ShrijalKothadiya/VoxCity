<?php
/**
 * Ultra Premium Service Landing Page Template
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$page_id = get_the_ID();
$city    = ucfirst( get_post_meta( $page_id, '_csg_city', true ) );
$service = ucfirst( get_post_meta( $page_id, '_csg_service', true ) );

if ( empty( $city ) ) { $city = 'Rajkot'; }
if ( empty( $service ) ) { $service = 'Plumber'; }

// Load assets
$css_url = plugin_dir_url( __FILE__ ) . '../assets/css/landing-page.css';
$js_url  = plugin_dir_url( __FILE__ ) . '../assets/js/landing-page.js';

// Get dynamic data
$generator = LSWG_Local_Service_Generator::get_instance();
$data = $generator->collect_local_data($city, $service);
$data['city'] = $city;
$data['service'] = $service;
$data['business_name'] = 'Professional ' . ucwords($service) . ' in ' . $city;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Best <?php echo esc_html( $service ); ?> in <?php echo esc_html( $city ); ?> | Verified Experts</title>
	<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>?v=<?php echo filemtime(plugin_dir_path( __FILE__ ) . '../assets/css/landing-page.css'); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700&display=swap">
</head>
<body class="spg-body">

    <?php echo $generator->render_preview($data); ?>

    <script src="<?php echo esc_url( $js_url ); ?>?v=<?php echo filemtime(plugin_dir_path( __FILE__ ) . '../assets/js/landing-page.js'); ?>"></script>
</body>
</html>